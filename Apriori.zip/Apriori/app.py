import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from src.data.loader import DataLoader
from src.analysis.apriori import AprioriAnalyzer

st.set_page_config(
    page_title="Banking Service Pattern Analysis",
    page_icon="🏦",
    layout="wide"
)

def create_example_data():
    """Create example data in basket format"""
    example_data = pd.DataFrame({
        'services': [
            "bill_payment,fund_transfer,balance_inquiry",
            "mobile_topup,fund_transfer",
            "qr_payment,balance_inquiry",
            "bill_payment,mobile_topup",
            "fund_transfer,balance_inquiry,qr_payment"
        ]
    })
    return example_data

def plot_service_frequency(transactions):
    """Create a bar chart of service frequencies"""
    # Count service frequencies
    service_counts = {}
    for transaction in transactions:
        for service in transaction:
            service_counts[service] = service_counts.get(service, 0) + 1
    
    # Create DataFrame for plotting
    df = pd.DataFrame(list(service_counts.items()), columns=['Service', 'Count'])
    df = df.sort_values('Count', ascending=True)
    
    # Create bar chart
    fig = go.Figure(go.Bar(
        x=df['Count'],
        y=df['Service'],
        orientation='h'
    ))
    
    fig.update_layout(
        title="Service Usage Frequency",
        xaxis_title="Number of Times Used",
        yaxis_title="Service Name",
        height=400
    )
    
    return fig

def plot_combination_network(rules):
    """Create a network graph of service combinations"""
    if len(rules) == 0:
        return None
        
    # Create network graph
    fig = go.Figure()
    
    # Add edges (connections between services)
    for _, rule in rules.iterrows():
        antecedents = list(rule['antecedents'])[0]  # Get first item from frozenset
        consequents = list(rule['consequents'])[0]
        
        # Add line connecting services
        fig.add_trace(go.Scatter(
            x=[0, 1],
            y=[antecedents, consequents],
            mode='lines+text',
            line=dict(width=2 * rule['confidence']),
            text=[f"{rule['confidence']:.2f}"],
            textposition='middle center',
            showlegend=False
        ))
    
    fig.update_layout(
        title="Service Relationship Network",
        xaxis_title="Services Used Together",
        height=600,
        showlegend=False
    )
    
    return fig

def show_example_data():
    """Display and provide example data for download"""
    st.markdown("### 📋 Example Data Format")
    example_df = create_example_data()
    
    st.markdown("""
    Your data should be in CSV format with a single column named 'services'.
    Each row represents one customer session with the services they used, separated by commas.
    
    For example:
    - Row 1 shows a customer who used bill payment, fund transfer, and checked their balance
    - Row 2 shows a customer who did mobile top-up and fund transfer
    """)
    
    st.dataframe(example_df, use_container_width=True)
    
    # Create download button for example data
    csv = example_df.to_csv(index=False)
    st.download_button(
        label="📥 Download Example Data",
        data=csv,
        file_name="example_banking_data.csv",
        mime="text/csv"
    )

def explain_results(frequent_itemsets, rules):
    """Explain the analysis results in simple terms"""
    st.markdown("### 🎯 What the Results Mean")
    
    # Explain frequent combinations
    st.markdown("""
    #### Common Service Combinations
    These are groups of services that customers often use together in one session:
    - **Support** shows how common this combination is (higher = more common)
    - For example, if Support = 0.20, it means 20% of customers use this combination
    """)
    
    # Format frequent itemsets for display
    if len(frequent_itemsets) > 0:
        display_itemsets = frequent_itemsets.copy()
        display_itemsets['itemsets'] = display_itemsets['itemsets'].apply(lambda x: ', '.join(list(x)))
        display_itemsets['support'] = display_itemsets['support'].apply(lambda x: f"{x:.1%}")
        display_itemsets.columns = ['Services Used Together', 'How Common']
        st.dataframe(display_itemsets, use_container_width=True)
    
    # Explain rules
    st.markdown("""
    #### Service Relationships
    These show how one service leads to using another:
    - **If Used** shows the first service(s)
    - **Then Likely Uses** shows what other service they're likely to use
    - **Confidence** shows how strong this pattern is (higher = stronger connection)
    - **Lift** shows how much more likely this connection is than by chance
    """)
    
    # Format rules for display
    if len(rules) > 0:
        display_rules = rules.copy()
        display_rules['antecedents'] = display_rules['antecedents'].apply(lambda x: ', '.join(list(x)))
        display_rules['consequents'] = display_rules['consequents'].apply(lambda x: ', '.join(list(x)))
        display_rules['confidence'] = display_rules['confidence'].apply(lambda x: f"{x:.1%}")
        display_rules['lift'] = display_rules['lift'].apply(lambda x: f"{x:.1f}x")
        display_rules = display_rules[['antecedents', 'consequents', 'confidence', 'lift']]
        display_rules.columns = ['If Used', 'Then Likely Uses', 'How Often', 'Strength']
        st.dataframe(display_rules, use_container_width=True)

def main():
    st.title("🏦 Banking Service Pattern Analysis")
    st.markdown("Discover how customers use your banking services together")
    st.markdown("---")

    # Show instructions
    with st.expander("📖 How to Use This Tool", expanded=True):
        st.markdown("""
        ### Simple Steps to Analyze Your Data
        
        1. **Prepare Your Data** 📝
           - Create a CSV file with one column named 'services'
           - Each row shows services used in one customer session
           - Separate services with commas
           - Download our example below to see the format
        
        2. **Upload Your File** 📤
           - Click 'Browse files' below
           - Select your CSV file
           - We'll check if it's in the right format
        
        3. **Set Analysis Options** ⚙️
           - Usage Frequency: How common should a pattern be?
           - Connection Strength: How strong should relationships be?
        
        4. **View Results** 📊
           - See which services are used together
           - Find strong service relationships
           - View helpful visualizations
           - Download detailed results
        """)

    # Show example data
    show_example_data()
    st.markdown("---")

    # File upload
    st.markdown("### 📤 Upload Your Data")
    uploaded_file = st.file_uploader("Choose your CSV file", type=['csv'])

    if uploaded_file:
        try:
            # Read and validate data
            df = pd.read_csv(uploaded_file)
            
            if 'services' not in df.columns:
                st.error("❌ Your file needs a column named 'services'")
                return
            
            if df.empty:
                st.error("❌ Your file appears to be empty")
                return

            st.success("✅ Data loaded successfully!")
            st.markdown("### 👀 Preview of Your Data")
            st.dataframe(df.head(), use_container_width=True)

            # Analysis parameters
            st.markdown("### ⚙️ Analysis Settings")
            col1, col2 = st.columns(2)
            with col1:
                min_support = st.slider(
                    "Usage Frequency (How Common)",
                    min_value=1,
                    max_value=100,
                    value=10,
                    help="Higher = show only more common patterns"
                )
            with col2:
                min_confidence = st.slider(
                    "Connection Strength",
                    min_value=1,
                    max_value=100,
                    value=50,
                    help="Higher = show only stronger relationships"
                )

            if st.button("🔍 Analyze Patterns"):
                with st.spinner("Analyzing your data..."):
                    # Process data
                    analyzer = AprioriAnalyzer(
                        min_support=min_support/100,
                        min_confidence=min_confidence/100
                    )
                    
                    # Convert to list format for analysis
                    transactions = df['services'].str.split(',').apply(
                        lambda x: [s.strip().strip('"\'') for s in x]
                    ).tolist()
                    
                    # Run analysis
                    frequent_itemsets, rules = analyzer.analyze(transactions)
                    
                    # Display results with explanations
                    st.markdown("## 📊 Analysis Results")
                    
                    # Show visualizations
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.plotly_chart(
                            plot_service_frequency(transactions),
                            use_container_width=True
                        )
                    
                    with col2:
                        network_fig = plot_combination_network(rules)
                        if network_fig:
                            st.plotly_chart(network_fig, use_container_width=True)
                    
                    # Explain results in simple terms
                    explain_results(frequent_itemsets, rules)
                    
                    # Download buttons
                    st.markdown("### 📥 Download Detailed Results")
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        if len(frequent_itemsets) > 0:
                            csv_frequent = frequent_itemsets.to_csv(index=False)
                            st.download_button(
                                label="📥 Download Service Combinations",
                                data=csv_frequent,
                                file_name="service_combinations.csv",
                                mime="text/csv"
                            )
                    
                    with col2:
                        if len(rules) > 0:
                            csv_rules = rules.to_csv(index=False)
                            st.download_button(
                                label="📥 Download Service Relationships",
                                data=csv_rules,
                                file_name="service_relationships.csv",
                                mime="text/csv"
                            )

        except Exception as e:
            st.error(f"❌ There was a problem: {str(e)}")
            st.markdown("""
            **Quick Fix Tips:**
            1. Make sure your file is a CSV
            2. Check that it has a column named 'services'
            3. Each row should have services separated by commas
            4. Download our example above to see the correct format
            """)

if __name__ == "__main__":
    main() 