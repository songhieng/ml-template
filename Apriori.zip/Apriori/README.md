# Banking Service Pattern Analysis

A sophisticated analysis tool for discovering patterns in digital banking service usage. This tool helps banks understand customer behavior, optimize their digital banking platforms, and improve service recommendations.

## Features

- **Service Usage Pattern Discovery**: Identify frequently combined banking services
- **Association Rule Generation**: Understand which services lead to the usage of others
- **Interactive Analysis**: Web interface for easy data exploration and visualization
- **Flexible Data Input**: Support for various transaction data formats
- **Rich Visualizations**: Multiple views of service usage patterns and relationships
- **Export Capabilities**: Download analysis results for further processing

## Key Metrics

- **Usage Rate**: Percentage of sessions where services appear together
- **Association Strength**: Probability of subsequent service usage
- **Correlation Score**: Strength of relationship between services

## Installation

1. Clone this repository:
```bash
git clone https://github.com/yourusername/banking-pattern-analysis.git
cd banking-pattern-analysis
```

2. Create a virtual environment:
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Linux/Mac
python -m venv venv
source venv/bin/activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

## Data Format Requirements

### Option 1: Session Log Format (Long Format)
```csv
session_id,service
1,bill_payment
1,fund_transfer
1,balance_inquiry
2,mobile_topup
2,fund_transfer
```

### Option 2: Basket Format
```csv
services
"bill_payment,fund_transfer,balance_inquiry"
"mobile_topup,fund_transfer,qr_payment"
```

## Running the Analysis

1. Start the application:
```bash
streamlit run app.py
```

2. Access the web interface (typically http://localhost:8501)

3. Upload your data and select the format:
   - Session Log Format: Choose session_id and service columns
   - Basket Format: One row per session with comma-separated services

4. Configure analysis parameters:
   - Minimum Usage Rate (0.01-1.0): How common service combinations should be
   - Minimum Association Strength (0.0-1.0): Confidence in service relationships
   - Minimum Correlation Score (0.0+): Strength of service associations

## Understanding the Results

### 1. Service Combinations
- Shows frequently used service combinations
- Higher usage rates indicate more common combinations
- Useful for:
  - Service placement optimization
  - App interface design
  - Feature bundling

### 2. Service Patterns
- Reveals sequential service usage patterns
- Helps understand customer journeys
- Applications:
  - Predictive service suggestions
  - UX flow optimization
  - Cross-selling opportunities

### 3. Visualization Types
- **Service Combination Chart**: Most common service groupings
- **Pattern Matrix**: Service relationships and strengths
- **Correlation Network**: Visual map of service connections
- **Usage Distribution**: Service popularity patterns

## Example Use Cases

1. **UX Optimization**
   - Identify commonly paired services
   - Optimize menu structure and navigation
   - Create smart quick-access shortcuts

2. **Service Recommendations**
   - Suggest next likely services
   - Personalize user dashboard
   - Improve service discovery

3. **Marketing Insights**
   - Target service promotion
   - Bundle complementary services
   - Identify cross-selling opportunities

4. **Customer Journey Analysis**
   - Map typical service usage flows
   - Identify potential friction points
   - Optimize service placement

## Sample Analysis Parameters

### For General Pattern Discovery
```python
analyzer = BankingPatternAnalysis(
    min_usage_rate=0.15,          # 15% of sessions
    min_association_strength=0.4,  # 40% confidence
    min_correlation_score=1.2      # Positive correlation
)
```

### For Specific Use Cases

1. **Finding Strong Service Relationships**
```python
analyzer = BankingPatternAnalysis(
    min_usage_rate=0.1,
    min_association_strength=0.6,
    min_correlation_score=2.0
)
```

2. **Discovering Rare but Important Patterns**
```python
analyzer = BankingPatternAnalysis(
    min_usage_rate=0.05,
    min_association_strength=0.7,
    min_correlation_score=3.0
)
```

## Best Practices

1. **Data Preparation**
   - Clean and standardize service names
   - Remove test/maintenance sessions
   - Consider time windows for analysis

2. **Parameter Selection**
   - Start with conservative thresholds
   - Adjust based on data volume
   - Consider business objectives

3. **Result Interpretation**
   - Focus on actionable insights
   - Consider customer segments
   - Validate patterns with domain knowledge

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions, please open an issue in the GitHub repository or contact the development team. 