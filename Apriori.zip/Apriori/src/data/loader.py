from typing import List, Union
import pandas as pd
import numpy as np
from pathlib import Path


class DataLoader:
    """
    A flexible data loader for banking service usage data in various formats.
    """
    
    @staticmethod
    def validate_csv(df: pd.DataFrame, basket_format: bool = False) -> bool:
        """
        Validate the structure of the uploaded CSV file.
        
        Args:
            df: DataFrame to validate
            basket_format: Whether the data is in basket format
            
        Returns:
            bool: True if valid, raises ValueError if invalid
        """
        if df.empty:
            raise ValueError("The uploaded file is empty. Please check your data.")
            
        if basket_format:
            if 'services' not in df.columns:
                raise ValueError(
                    "For basket format, the CSV must have a 'services' column. "
                    "Example format:\n"
                    "services\n"
                    "\"bill_payment,fund_transfer,balance_inquiry\"\n"
                    "\"mobile_topup,fund_transfer,qr_payment\""
                )
            # Validate that services column contains string data
            if not all(isinstance(x, str) for x in df['services'].dropna()):
                raise ValueError(
                    "The 'services' column must contain comma-separated text values. "
                    "Example: 'bill_payment,fund_transfer,balance_inquiry'"
                )
        return True

    @staticmethod
    def load_csv(file_path, basket_format=True):
        """
        Load data from a CSV file
        
        Parameters:
        -----------
        file_path : str or file object
            Path to the CSV file or file object
        basket_format : bool
            Whether the file is in basket format
            
        Returns:
        --------
        DataFrame
            Loaded data
        """
        try:
            df = pd.read_csv(file_path)
            
            if df.empty:
                raise ValueError("The CSV file is empty")
                
            if basket_format and 'services' not in df.columns:
                raise ValueError("CSV must have a 'services' column for basket format")
                
            return df
            
        except Exception as e:
            raise ValueError(f"Error loading CSV file: {str(e)}")
    
    @staticmethod
    def transform_to_basket(
        df: pd.DataFrame,
        transaction_id_col: str,
        item_col: str
    ) -> List[List]:
        """
        Transform transaction data from long format to basket format with validation.
        
        Args:
            df: DataFrame containing transaction data
            transaction_id_col: Name of the transaction ID column
            item_col: Name of the item column
            
        Returns:
            List of transactions, where each transaction is a list of items
        """
        if df.empty:
            raise ValueError("No data to transform. The DataFrame is empty.")
            
        if not all(col in df.columns for col in [transaction_id_col, item_col]):
            raise ValueError(
                f"Required columns not found. Need '{transaction_id_col}' and '{item_col}'. "
                f"Available columns: {', '.join(df.columns)}"
            )
        
        # Group by transaction_id and convert to list format
        try:
            transactions = (
                df.groupby(transaction_id_col)[item_col]
                .agg(list)
                .tolist()
            )
            
            # Validate that we got some transactions
            if not transactions:
                raise ValueError("No valid transactions found after transformation.")
                
            return transactions
            
        except Exception as e:
            raise ValueError(f"Error transforming data to basket format: {str(e)}")
    
    @staticmethod
    def parse_basket_format(df):
        """
        Parse basket format data into list of transactions
        
        Parameters:
        -----------
        df : DataFrame
            DataFrame with 'services' column
            
        Returns:
        --------
        list
            List of lists, where each inner list contains services from one transaction
        """
        if 'services' not in df.columns:
            raise ValueError("DataFrame must have a 'services' column")
            
        try:
            # Split comma-separated services and convert to list
            transactions = df['services'].str.split(',').tolist()
            
            # Clean the data (remove whitespace and quotes)
            transactions = [[service.strip().strip('"\'') for service in transaction]
                          for transaction in transactions]
            
            return transactions
            
        except Exception as e:
            raise ValueError(f"Error parsing basket format: {str(e)}")
    
    @staticmethod
    def save_results(
        frequent_itemsets: pd.DataFrame,
        rules: pd.DataFrame,
        output_dir: Union[str, Path]
    ) -> None:
        """
        Save the mining results to CSV files with error handling.
        
        Args:
            frequent_itemsets: DataFrame containing frequent itemsets
            rules: DataFrame containing association rules
            output_dir: Directory to save the results
        """
        try:
            output_dir = Path(output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
            
            frequent_itemsets.to_csv(
                output_dir / "frequent_itemsets.csv",
                index=False
            )
            rules.to_csv(
                output_dir / "association_rules.csv",
                index=False
            )
        except Exception as e:
            raise ValueError(f"Error saving results: {str(e)}") 