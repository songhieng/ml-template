import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from typing import List, Dict


def plot_service_combinations(combinations_df: pd.DataFrame, top_n: int = 20) -> go.Figure:
    """
    Create a bar plot of the most frequent service combinations.
    
    Args:
        combinations_df: DataFrame containing service combinations and their usage rates
        top_n: Number of top combinations to display
        
    Returns:
        Plotly figure object
    """
    plot_df = combinations_df.copy()
    plot_df['service_str'] = plot_df['service_combination'].apply(lambda x: ', '.join(sorted(x)))
    
    plot_df = plot_df.nlargest(top_n, 'usage_rate')
    
    fig = px.bar(
        plot_df,
        x='usage_rate',
        y='service_str',
        orientation='h',
        title=f'Top {top_n} Service Combinations by Usage Rate',
        labels={'usage_rate': 'Usage Rate', 'service_str': 'Service Combination'}
    )
    
    return fig


def plot_pattern_metrics(patterns: pd.DataFrame) -> go.Figure:
    """
    Create a scatter plot of pattern metrics (usage rate vs association strength, colored by correlation).
    
    Args:
        patterns: DataFrame containing service patterns and their metrics
        
    Returns:
        Plotly figure object
    """
    fig = px.scatter(
        patterns,
        x='usage_rate',
        y='association_strength',
        color='correlation_score',
        title='Service Patterns: Usage Rate vs Association Strength',
        labels={
            'usage_rate': 'Usage Rate',
            'association_strength': 'Association Strength',
            'correlation_score': 'Correlation Score'
        }
    )
    
    return fig


def plot_correlation_distribution(patterns: pd.DataFrame) -> go.Figure:
    """
    Create a histogram of correlation scores for the patterns.
    
    Args:
        patterns: DataFrame containing service patterns and their metrics
        
    Returns:
        Plotly figure object
    """
    fig = px.histogram(
        patterns,
        x='correlation_score',
        title='Distribution of Service Correlation Scores',
        labels={'correlation_score': 'Correlation Score'},
        nbins=30
    )
    
    return fig


def create_service_network(patterns: pd.DataFrame, min_correlation: float = 1.0) -> go.Figure:
    """
    Create a network visualization of service relationships.
    
    Args:
        patterns: DataFrame containing service patterns and their metrics
        min_correlation: Minimum correlation score for relationships to include
        
    Returns:
        Plotly figure object
    """
    patterns_filtered = patterns[patterns['correlation_score'] >= min_correlation]
    
    nodes = set()
    edges = []
    
    for _, pattern in patterns_filtered.iterrows():
        for service in pattern['precursor_services']:
            nodes.add(service)
        for service in pattern['subsequent_services']:
            nodes.add(service)
            
        for precursor in pattern['precursor_services']:
            for subsequent in pattern['subsequent_services']:
                edges.append((precursor, subsequent, pattern['correlation_score']))
    
    import math
    
    nodes = list(nodes)
    node_positions = {}
    n_nodes = len(nodes)
    
    for i, node in enumerate(nodes):
        angle = 2 * math.pi * i / n_nodes
        node_positions[node] = (math.cos(angle), math.sin(angle))
    
    edge_x = []
    edge_y = []
    edge_colors = []
    
    for edge in edges:
        x0, y0 = node_positions[edge[0]]
        x1, y1 = node_positions[edge[1]]
        edge_x.extend([x0, x1, None])
        edge_y.extend([y0, y1, None])
        edge_colors.extend([edge[2]] * 3)
    
    node_x = [pos[0] for pos in node_positions.values()]
    node_y = [pos[1] for pos in node_positions.values()]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=edge_x,
        y=edge_y,
        line=dict(width=0.5, color=edge_colors),
        hoverinfo='none',
        mode='lines'
    ))
    
    fig.add_trace(go.Scatter(
        x=node_x,
        y=node_y,
        mode='markers+text',
        hoverinfo='text',
        text=nodes,
        textposition='top center',
        marker=dict(
            size=10,
            line_width=2
        )
    ))
    
    fig.update_layout(
        title='Digital Banking Service Relationship Network',
        showlegend=False,
        hovermode='closest',
        margin=dict(b=20, l=5, r=5, t=40),
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False)
    )
    
    return fig 