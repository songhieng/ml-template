from collections import defaultdict
from itertools import combinations
from typing import Dict, List, Set, Tuple, Union
import pandas as pd
import numpy as np
from tqdm import tqdm


class Apriori:
    """
    A flexible and dynamic implementation of the Apriori algorithm for mining frequent itemsets
    and generating association rules.
    """
    
    def __init__(
        self,
        min_support: float = 0.1,
        min_confidence: float = 0.5,
        min_lift: float = 1.0,
        max_length: int = None
    ):
        """
        Initialize the Apriori algorithm with customizable parameters.
        
        Args:
            min_support (float): Minimum support threshold (0 to 1)
            min_confidence (float): Minimum confidence threshold (0 to 1)
            min_lift (float): Minimum lift threshold
            max_length (int): Maximum length of itemsets to consider
        """
        self.min_support = min_support
        self.min_confidence = min_confidence
        self.min_lift = min_lift
        self.max_length = max_length
        self.frequent_itemsets = {}
        self.rules = []
        self.item_counts = None
        self.n_transactions = None
        
    def _create_candidates(self, prev_frequent: List[frozenset], k: int) -> List[frozenset]:
        """
        Generate candidate itemsets of size k from frequent itemsets of size k-1.
        
        Args:
            prev_frequent: List of frequent itemsets from previous iteration
            k: Size of itemsets to generate
            
        Returns:
            List of candidate itemsets
        """
        candidates = []
        for i in range(len(prev_frequent)):
            for j in range(i + 1, len(prev_frequent)):
                items1 = list(prev_frequent[i])
                items2 = list(prev_frequent[j])
                items1.sort()
                items2.sort()
                
                if items1[:k-2] == items2[:k-2]:
                    # Merge items to create new candidate
                    candidate = frozenset(items1) | frozenset(items2)
                    if len(candidate) == k:
                        valid = True
                        # Check if all subsets are frequent
                        for subset in combinations(candidate, k-1):
                            if frozenset(subset) not in prev_frequent:
                                valid = False
                                break
                        if valid:
                            candidates.append(candidate)
        return candidates
    
    def _calculate_support(self, itemset: frozenset, transactions: List[frozenset]) -> float:
        """
        Calculate support for an itemset.
        
        Args:
            itemset: Set of items to calculate support for
            transactions: List of transactions
            
        Returns:
            Support value
        """
        count = sum(1 for transaction in transactions if itemset.issubset(transaction))
        return count / self.n_transactions
    
    def fit(self, transactions: Union[List[List], pd.DataFrame]) -> 'Apriori':
        """
        Fit the Apriori algorithm to find frequent itemsets.
        
        Args:
            transactions: List of transactions or DataFrame with transactions
            
        Returns:
            self
        """
        # Convert transactions to list of sets if DataFrame
        if isinstance(transactions, pd.DataFrame):
            transactions = transactions.values.tolist()
        
        # Convert transactions to sets
        transactions = [frozenset(transaction) for transaction in transactions]
        self.n_transactions = len(transactions)
        
        # Get unique items
        unique_items = set().union(*transactions)
        self.item_counts = defaultdict(int)
        
        # Generate frequent 1-itemsets
        L1 = []
        for item in unique_items:
            itemset = frozenset([item])
            support = self._calculate_support(itemset, transactions)
            if support >= self.min_support:
                L1.append(itemset)
                self.frequent_itemsets[itemset] = support
        
        current_L = L1
        k = 2
        
        # Generate frequent itemsets of size k
        while current_L and (self.max_length is None or k <= self.max_length):
            candidates = self._create_candidates(current_L, k)
            current_L = []
            
            for candidate in tqdm(candidates, desc=f"Finding {k}-itemsets"):
                support = self._calculate_support(candidate, transactions)
                if support >= self.min_support:
                    current_L.append(candidate)
                    self.frequent_itemsets[candidate] = support
            
            k += 1
        
        return self
    
    def generate_rules(self) -> List[Dict]:
        """
        Generate association rules from frequent itemsets.
        
        Returns:
            List of dictionaries containing rules and their metrics
        """
        self.rules = []
        
        for itemset in self.frequent_itemsets:
            if len(itemset) < 2:
                continue
                
            for i in range(1, len(itemset)):
                for antecedent in combinations(itemset, i):
                    antecedent = frozenset(antecedent)
                    consequent = itemset - antecedent
                    
                    confidence = (
                        self.frequent_itemsets[itemset] /
                        self.frequent_itemsets[antecedent]
                    )
                    
                    if confidence >= self.min_confidence:
                        lift = confidence / self.frequent_itemsets[consequent]
                        
                        if lift >= self.min_lift:
                            self.rules.append({
                                'antecedent': list(antecedent),
                                'consequent': list(consequent),
                                'support': self.frequent_itemsets[itemset],
                                'confidence': confidence,
                                'lift': lift
                            })
        
        return self.rules
    
    def get_frequent_itemsets(self, as_dataframe: bool = True) -> Union[Dict, pd.DataFrame]:
        """
        Get the frequent itemsets and their support values.
        
        Args:
            as_dataframe: Whether to return results as a DataFrame
            
        Returns:
            Dictionary or DataFrame of frequent itemsets and their support values
        """
        if not as_dataframe:
            return self.frequent_itemsets
        
        itemsets_df = pd.DataFrame([
            {'itemset': list(k), 'support': v}
            for k, v in self.frequent_itemsets.items()
        ])
        return itemsets_df.sort_values('support', ascending=False)
    
    def get_rules(self, as_dataframe: bool = True) -> Union[List[Dict], pd.DataFrame]:
        """
        Get the generated association rules.
        
        Args:
            as_dataframe: Whether to return results as a DataFrame
            
        Returns:
            List of dictionaries or DataFrame containing the rules
        """
        if not as_dataframe:
            return self.rules
        
        return pd.DataFrame(self.rules).sort_values('lift', ascending=False) 