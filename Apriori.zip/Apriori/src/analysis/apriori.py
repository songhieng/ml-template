from mlxtend.frequent_patterns import apriori
from mlxtend.frequent_patterns import association_rules
import pandas as pd

class AprioriAnalyzer:
    def __init__(self, min_support=0.1, min_confidence=0.5):
        self.min_support = min_support
        self.min_confidence = min_confidence

    def _create_one_hot_encoded(self, transactions):
        """Convert transactions to one-hot encoded DataFrame"""
        # Get unique items
        unique_items = set()
        for transaction in transactions:
            unique_items.update(transaction)
        
        # Create one-hot encoded DataFrame
        encoded_data = pd.DataFrame([[1 if item in transaction else 0 
                                    for item in unique_items] 
                                   for transaction in transactions],
                                  columns=list(unique_items))
        return encoded_data

    def analyze(self, transactions):
        """
        Analyze transactions using Apriori algorithm
        
        Parameters:
        -----------
        transactions : list of lists
            Each inner list contains items in a transaction
            
        Returns:
        --------
        tuple (frequent_itemsets, rules)
            frequent_itemsets : DataFrame with frequent itemsets
            rules : DataFrame with association rules
        """
        # Convert transactions to one-hot encoded format
        encoded_data = self._create_one_hot_encoded(transactions)
        
        # Find frequent itemsets
        frequent_itemsets = apriori(encoded_data, 
                                  min_support=self.min_support,
                                  use_colnames=True)
        
        # Generate rules if frequent itemsets exist
        if len(frequent_itemsets) > 0:
            rules = association_rules(frequent_itemsets, 
                                   metric="confidence",
                                   min_threshold=self.min_confidence)
            
            # Sort rules by confidence
            if len(rules) > 0:
                rules = rules.sort_values('confidence', ascending=False)
        else:
            rules = pd.DataFrame()
            
        return frequent_itemsets, rules 