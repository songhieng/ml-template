import os
from PIL import Image, ImageChops

def perform_ela(image_path, quality=30):
    original = Image.open(image_path).convert('RGB')
    temp_path = "temp_ela.jpg"
    original.save(temp_path, 'JPEG', quality=quality)
    resaved = Image.open(temp_path)
    ela_image = ImageChops.difference(original, resaved)
    ela_image = ela_image.point(lambda x: x * 10)
    return ela_image

def process_images(input_folder, output_folder):
    os.makedirs(output_folder, exist_ok=True)

    supported_formats = ('.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.webp')

    for filename in os.listdir(input_folder):
        if filename.lower().endswith(supported_formats):
            input_path = os.path.join(input_folder, filename)
            temp_jpeg_path = os.path.splitext(input_path)[0] + '_converted.jpg'

            try:
                # Convert any format to JPEG
                Image.open(input_path).convert('RGB').save(temp_jpeg_path, 'JPEG', quality=100)

                # Perform ELA
                ela_result = perform_ela(temp_jpeg_path)

                # Save ELA image
                output_name = f'ELA_{os.path.splitext(filename)[0]}.jpg'
                output_path = os.path.join(output_folder, output_name)
                ela_result.save(output_path)

                print(f'Processed: {filename}')
            except Exception as e:
                print(f'Failed to process {filename}: {e}')
            finally:
                # Clean up temp JPEG if it exists
                if os.path.exists(temp_jpeg_path):
                    os.remove(temp_jpeg_path)

# Example usage
input_dir = 'data'
output_dir = 'data_ela'
process_images(input_dir, output_dir)
