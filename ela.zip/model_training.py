#!/usr/bin/env python3
import os
import argparse
import random
import shutil

import numpy as np
from PIL import Image
from tqdm import tqdm

import torch
import torch.nn.functional as F
from torchvision import models, transforms

from sklearn.covariance import LedoitWolf
import joblib

# ----------------------------
# Globals & utils
# ----------------------------
IMG_SIZE = 224
VALID_EXT = ('.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff')
FEATURES = {}
LAYER_NAMES = ['layer2', 'layer3', 'layer4']  # semantic layers


def list_images(d):
    if not os.path.isdir(d):
        return []
    return sorted([
        os.path.join(d, f) for f in os.listdir(d)
        if f.lower().endswith(VALID_EXT)
    ])


def get_device(name):
    if name == 'auto':
        return torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    return torch.device(name)


def get_hook(name):
    def hook(module, input, output):
        FEATURES[name] = output.detach()
    return hook


def build_backbone(device):
    try:
        weights = models.ResNet101_Weights.DEFAULT
        net = models.resnet101(weights=weights).to(device).eval()
    except Exception:
        net = models.resnet101(pretrained=True).to(device).eval()
    for p in net.parameters():
        p.requires_grad = False
    for name, module in net.named_children():
        if name in LAYER_NAMES:
            module.register_forward_hook(get_hook(name))
    return net


def build_transforms(train=False):
    if train:
        return transforms.Compose([
            transforms.Resize((IMG_SIZE, IMG_SIZE)),
            transforms.RandomApply([transforms.GaussianBlur(3)], p=0.2),
            transforms.RandomAffine(degrees=3, translate=(0.02, 0.02), scale=(0.97, 1.03)),
            transforms.ColorJitter(brightness=0.08, contrast=0.08),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
        ])
    else:
        return transforms.Compose([
            transforms.Resize((IMG_SIZE, IMG_SIZE)),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
        ])

# ----------------------------
# Feature extraction
# ----------------------------
@torch.no_grad()
def extract_concat_feats(model, device, img_pil, tf):
    FEATURES.clear()
    x = tf(img_pil).unsqueeze(0).to(device)
    _ = model(x)

    f2 = FEATURES['layer2']  # [1, C2, H2, W2]
    _, _, H2, W2 = f2.shape
    f3 = FEATURES['layer3']
    f4 = FEATURES['layer4']

    f3_up = F.interpolate(f3, size=(H2, W2), mode='bilinear', align_corners=False)
    f4_up = F.interpolate(f4, size=(H2, W2), mode='bilinear', align_corners=False)

    feat = torch.cat([f2, f3_up, f4_up], dim=1).squeeze(0)
    feat = feat.permute(1, 2, 0).reshape(-1, feat.shape[0])
    return feat.cpu().numpy(), (H2, W2)

# ----------------------------
# Train (per-location Gaussians)
# ----------------------------
def train(args):
    print(f"[INFO] Starting TRAIN", flush=True)
    device = get_device(args.device)
    print(f"[INFO] Device: {device}", flush=True)

    train_files = list_images(args.train_dir)
    print(f"[INFO] Found {len(train_files)} real images in {args.train_dir}", flush=True)
    if len(train_files) == 0:
        print("[ERROR] No training images found. Check path and extensions.")
        return

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    model = build_backbone(device)
    TF_TRN = build_transforms(train=True)
    TF_INF = build_transforms(train=False)

    # sample one
    sample_img = Image.open(train_files[0]).convert('RGB')
    base_feat, (H, W) = extract_concat_feats(model, device, sample_img, TF_INF)
    P, Ctot = base_feat.shape

    rng = np.random.RandomState(0)
    ch_idx = rng.choice(Ctot, size=args.D, replace=False)
    print(f"[TRAIN] Using channels: {args.D}/{Ctot}, grid {H}x{W} (P={P})", flush=True)

    # build X [N, P, D]
    X_list = []
    for f in tqdm(train_files, desc="Extract feats (train)"):
        img = Image.open(f).convert('RGB')
        feats0, _ = extract_concat_feats(model, device, img, TF_INF)
        X_list.append(feats0[:, ch_idx])
        for _ in range(args.aug_times):
            FEATURES.clear()
            x = TF_TRN(img).unsqueeze(0).to(device)
            _ = model(x)
            f2 = FEATURES['layer2']
            _, _, H2, W2 = f2.shape
            f3 = FEATURES['layer3']
            f4 = FEATURES['layer4']
            f3_up = F.interpolate(f3, size=(H2, W2), mode='bilinear', align_corners=False)
            f4_up = F.interpolate(f4, size=(H2, W2), mode='bilinear', align_corners=False)
            feat = torch.cat([f2, f3_up, f4_up], dim=1).squeeze(0)
            feat = feat.permute(1, 2, 0).reshape(-1, feat.shape[0]).cpu().numpy()
            X_list.append(feat[:, ch_idx])

    X = np.stack(X_list, axis=0)
    print(f"[TRAIN] Training tensor X shape: {X.shape}", flush=True)

    mus = np.empty((P, args.D), dtype=np.float32)
    cov_invs = np.empty((P, args.D, args.D), dtype=np.float32)

    for p in tqdm(range(P), desc="Fit Gaussians per location"):
        Xp = X[:, p, :]
        lw = LedoitWolf().fit(Xp)
        mu = lw.location_
        cov = lw.covariance_
        cov_inv = np.linalg.inv(cov)
        mus[p] = mu.astype(np.float32)
        cov_invs[p] = cov_inv.astype(np.float32)

    # threshold calibration
    top_k = max(10, int(0.02 * P))
    def score_image(feats_PD):
        delta = feats_PD - mus
        d2 = np.einsum('pd,pde,pd->p', delta, cov_invs, delta)
        d = np.sqrt(np.clip(d2, 0, None))
        k = min(top_k, d.size)
        return float(np.mean(np.partition(d, -k)[-k:]))

    train_scores = []
    for f in tqdm(train_files, desc="Calibrate on train"):
        img = Image.open(f).convert('RGB')
        feats, _ = extract_concat_feats(model, device, img, TF_INF)
        train_scores.append(score_image(feats[:, ch_idx]))

    thr = float(np.quantile(np.array(train_scores), 1.0 - args.target_fpr))
    print(f"[TRAIN] Threshold @ FPR={args.target_fpr*100:.2f}% -> {thr:.6f}", flush=True)

    np.savez_compressed(args.out,
                        mus=mus, cov_invs=cov_invs,
                        H=H, W=W, D=args.D, ch_idx=ch_idx,
                        thresh=thr, top_k=top_k)
    print(f"[TRAIN] Saved model -> {args.out}", flush=True)

# ----------------------------
# Inference
# ----------------------------
@torch.no_grad()
def infer(args):
    print(f"[INFO] Starting INFER", flush=True)
    device = get_device(args.device)
    print(f"[INFO] Device: {device}", flush=True)

    if not os.path.isfile(args.model):
        print(f"[ERROR] Model not found: {args.model}")
        return

    test_files = list_images(args.test_dir)
    print(f"[INFO] Found {len(test_files)} test images in {args.test_dir}", flush=True)
    if len(test_files) == 0:
        print("[WARN] No test images found.")
        return

    # prepare output dirs
    out_dir = args.out_dir
    norm_dir = os.path.join(out_dir, "normal")
    anom_dir = os.path.join(out_dir, "anomaly")
    os.makedirs(norm_dir, exist_ok=True)
    os.makedirs(anom_dir, exist_ok=True)
    print(f"[INFO] Writing outputs to {norm_dir} and {anom_dir}", flush=True)

    blob = np.load(args.model)
    mus = blob['mus']; cov_invs = blob['cov_invs']
    H = int(blob['H']); W = int(blob['W'])
    D = int(blob['D']); ch_idx = blob['ch_idx']
    thr = float(blob['thresh']); top_k = int(blob['top_k'])
    P = H * W

    model = build_backbone(device)
    TF_INF = build_transforms(train=False)

    for f in test_files:
        img = Image.open(f).convert('RGB')
        feats, (H2, W2) = extract_concat_feats(model, device, img, TF_INF)
        if H2 != H or W2 != W:
            print(f"[ERROR] Grid mismatch for {os.path.basename(f)}. Is IMG_SIZE changed?", flush=True)
            continue
        feats = feats[:, ch_idx]
        delta = feats - mus
        d2 = np.einsum('pd,pde,pd->p', delta, cov_invs, delta)
        d = np.sqrt(np.clip(d2, 0, None))
        k = min(top_k, d.size)
        img_score = float(np.mean(np.partition(d, -k)[-k:]))
        label = 'anomaly' if img_score > thr else 'normal'
        print(f"{os.path.basename(f)} -> score:{img_score:.6f}  label:{label}", flush=True)
        dst = anom_dir if label=='anomaly' else norm_dir
        shutil.copy(f, dst)

# ----------------------------
# CLI
# ----------------------------
def parse_args():
    p = argparse.ArgumentParser("PaDiM (per-location) for Fake NID")
    sub = p.add_subparsers(dest="cmd", required=True)

    pt = sub.add_parser("train")
    pt.add_argument("--train_dir", required=True)
    pt.add_argument("--out", default="padim_model_r101.npz")
    pt.add_argument("--device", default="auto")
    pt.add_argument("--D", type=int, default=100)
    pt.add_argument("--aug_times", type=int, default=2)
    pt.add_argument("--target_fpr", type=float, default=0.01)
    pt.add_argument("--seed", type=int, default=0)

    pi = sub.add_parser("infer")
    pi.add_argument("--model", required=True)
    pi.add_argument("--test_dir", required=True)
    pi.add_argument("--device", default="auto")
    pi.add_argument("--out_dir", default="infer_outputs",
                     help="root folder to write normal/ and anomaly/ images")

    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    if args.cmd == "train":
        train(args)
    elif args.cmd == "infer":
        infer(args)
