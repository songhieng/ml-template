# RFM Analysis Dashboard

A comprehensive RFM (Recency, Frequency, Monetary) Analysis tool with a Streamlit-based dashboard for customer segmentation and analysis.

## Project Structure

```
project/
├── data/
│   ├── raw/                # Original customer and transaction data
│   └── processed/          # Cleaned data and intermediate RFM metrics
├── notebooks/              # Jupyter notebooks for exploration
├── src/
│   ├── config/            # Configuration files
│   │   └── config.yaml    # RFM analysis parameters
│   ├── data/              # Data handling modules
│   │   ├── loader.py      # Data loading utilities
│   │   └── preprocess.py  # Data preprocessing
│   ├── models/            # RFM analysis logic
│   │   └── rfm_segmentation.py
│   └── utils/             # Utility functions
│       ├── logger.py      # Logging utilities
│       └── visualization.py # Plotting functions
├── tests/                 # Unit tests
├── app.py                 # Main Streamlit application
├── requirements.txt       # Project dependencies
└── README.md             # Project documentation
```

## Features

- **Data Input**:
  - Upload CSV files
  - Generate sample data
  - Flexible column mapping

- **RFM Analysis**:
  - Calculate Recency, Frequency, and Monetary metrics
  - Customizable scoring weights
  - Customer segmentation
  - Detailed customer analysis

- **Visualization**:
  - Interactive plots using Plotly
  - RFM score distributions
  - Customer segment analysis
  - Transaction history
  - RFM radar charts

- **Export**:
  - Download analysis results as CSV
  - Share insights with stakeholders

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd rfm-analysis
```

2. Create a virtual environment (recommended):
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

## Usage

1. Run the Streamlit application:
```bash
streamlit run app.py
```

2. Access the dashboard in your web browser (typically at http://localhost:8501)

3. Choose your data source:
   - Upload a CSV file
   - Use sample data

4. Map your columns to the required fields:
   - Customer ID
   - Transaction Date
   - Transaction Amount

5. Adjust analysis parameters:
   - RFM weights
   - Segment thresholds
   - Quantile cutoffs

6. Explore the results through the interactive dashboard

## Input Data Format

Your CSV file should contain the following columns:
- Customer ID (unique identifier)
- Transaction Date (datetime format)
- Transaction Amount (numeric values)

Example:
```csv
customer_id,transaction_date,amount
CUST_001,2023-01-01,100.00
CUST_001,2023-02-15,150.00
CUST_002,2023-03-20,200.00
```

## Configuration

The RFM analysis parameters can be customized in `src/config/config.yaml`:
- RFM weights
- Quantile thresholds
- Segment definitions
- Visualization settings

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Built with Streamlit
- Visualizations powered by Plotly
- Data processing with Pandas 