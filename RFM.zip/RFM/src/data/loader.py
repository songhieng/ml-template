import pandas as pd
import yaml
from pathlib import Path
import logging

logger = logging.getLogger(__name__)

def load_config(config_path: str = 'src/config/config.yaml') -> dict:
    """Load configuration from YAML file."""
    try:
        with open(config_path, 'r') as file:
            config = yaml.safe_load(file)
        return config
    except Exception as e:
        logger.error(f"Error loading config file: {e}")
        raise

def load_data(file_path: str, file_type: str = 'csv') -> pd.DataFrame:
    """
    Load data from various file formats.
    
    Parameters
    ----------
    file_path : str
        Path to the data file
    file_type : str
        Type of file ('csv', 'excel', 'parquet')
        
    Returns
    -------
    pd.DataFrame
        Loaded data
    """
    try:
        if file_type.lower() == 'csv':
            df = pd.read_csv(file_path)
        elif file_type.lower() == 'excel':
            df = pd.read_excel(file_path)
        elif file_type.lower() == 'parquet':
            df = pd.read_parquet(file_path)
        else:
            raise ValueError(f"Unsupported file type: {file_type}")
        
        logger.info(f"Successfully loaded data from {file_path}")
        return df
    except Exception as e:
        logger.error(f"Error loading data from {file_path}: {e}")
        raise

def generate_sample_data(n_customers: int = 1000, n_transactions: int = 5000) -> pd.DataFrame:
    """
    Generate sample transaction data for testing.
    
    Parameters
    ----------
    n_customers : int
        Number of customers to generate
    n_transactions : int
        Number of transactions to generate
        
    Returns
    -------
    pd.DataFrame
        Generated sample data
    """
    import numpy as np
    from datetime import datetime, timedelta
    
    customer_ids = [f'CUST_{i:04d}' for i in range(n_customers)]
    end_date = datetime.now()
    start_date = end_date - timedelta(days=365)
    
    data = {
        'customer_id': np.random.choice(customer_ids, n_transactions),
        'transaction_date': np.random.choice(pd.date_range(start_date, end_date), n_transactions),
        'amount': np.random.uniform(10, 1000, n_transactions)
    }
    
    df = pd.DataFrame(data)
    logger.info(f"Generated sample data with {n_customers} customers and {n_transactions} transactions")
    return df 