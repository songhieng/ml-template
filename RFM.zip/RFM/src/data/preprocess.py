import pandas as pd
import numpy as np
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

def prepare_data(df: pd.DataFrame, 
                customer_id_col: str,
                date_col: str,
                amount_col: str) -> pd.DataFrame:
    """
    Prepare data for RFM analysis.
    
    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame
    customer_id_col : str
        Name of the customer ID column
    date_col : str
        Name of the date column
    amount_col : str
        Name of the amount column
        
    Returns
    -------
    pd.DataFrame
        Prepared DataFrame
    """
    try:
        # Create a copy to avoid modifying the original
        df = df.copy()
        
        # Convert date column to datetime
        df[date_col] = pd.to_datetime(df[date_col])
        
        # Ensure amount column is numeric
        df[amount_col] = pd.to_numeric(df[amount_col], errors='coerce')
        
        # Remove rows with missing values
        df = df.dropna(subset=[customer_id_col, date_col, amount_col])
        
        # Remove duplicate transactions
        df = df.drop_duplicates()
        
        # Sort by date
        df = df.sort_values(date_col)
        
        logger.info(f"Data preparation completed. Shape: {df.shape}")
        return df
        
    except Exception as e:
        logger.error(f"Error in data preparation: {e}")
        raise

def validate_data(df: pd.DataFrame,
                 customer_id_col: str,
                 date_col: str,
                 amount_col: str) -> bool:
    """
    Validate the input data for RFM analysis.
    
    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame
    customer_id_col : str
        Name of the customer ID column
    date_col : str
        Name of the date column
    amount_col : str
        Name of the amount column
        
    Returns
    -------
    bool
        True if data is valid, False otherwise
    """
    try:
        # Check if required columns exist
        required_cols = [customer_id_col, date_col, amount_col]
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            logger.error(f"Missing required columns: {missing_cols}")
            return False
            
        # Check for empty DataFrame
        if df.empty:
            logger.error("Empty DataFrame provided")
            return False
            
        # Ensure data types are correct
        try:
            df[date_col] = pd.to_datetime(df[date_col])
            df[amount_col] = pd.to_numeric(df[amount_col], errors='coerce')
        except Exception as e:
            logger.error(f"Error converting data types: {e}")
            return False
            
        # Check for negative amounts
        if (df[amount_col] < 0).any():
            logger.warning("Found negative transaction amounts")
            
        # Check for future dates
        future_dates = df[df[date_col] > datetime.now()]
        if not future_dates.empty:
            logger.warning(f"Found {len(future_dates)} transactions with future dates")
            
        return True
        
    except Exception as e:
        logger.error(f"Error in data validation: {e}")
        return False 