import pandas as pd
import numpy as np
from datetime import datetime
import logging
from typing import Dict, Tuple, List, Optional

logger = logging.getLogger(__name__)

class RFMAnalyzer:
    """
    A comprehensive RFM (Recency, Frequency, Monetary) Analysis tool.
    
    This class provides methods to perform RFM analysis on customer transaction data,
    including scoring, segmentation, and visualization capabilities.
    """
    
    def __init__(self, 
                 data: pd.DataFrame,
                 customer_id_col: str,
                 date_col: str,
                 amount_col: str,
                 config: Optional[Dict] = None):
        """
        Initialize the RFM Analyzer.
        
        Parameters
        ----------
        data : pd.DataFrame
            Input DataFrame containing transaction data
        customer_id_col : str
            Name of the column containing customer IDs
        date_col : str
            Name of the column containing transaction dates
        amount_col : str
            Name of the column containing transaction amounts
        config : dict, optional
            Configuration dictionary containing RFM parameters
        """
        self.data = data.copy()
        self.customer_id_col = customer_id_col
        self.date_col = date_col
        self.amount_col = amount_col
        self.config = config or {}
        self.rfm_data = None
        self.rfm_scores = None
        self.segments = None
        
        # Set default configuration if not provided
        self.rfm_config = self.config.get('rfm', {
            'weights': {'recency': 0.4, 'frequency': 0.3, 'monetary': 0.3},
            'quantiles': [0.2, 0.4, 0.6, 0.8],
            'segments': {
                'Champions': [4.5, 5.0],
                'Loyal': [4.0, 4.4],
                'At Risk': [3.0, 3.9],
                'Lost': [0.0, 2.9]
            }
        })
    
    def calculate_rfm_metrics(self, analysis_date: Optional[datetime] = None) -> pd.DataFrame:
        """
        Calculate Recency, Frequency, and Monetary metrics for each customer.
        
        Parameters
        ----------
        analysis_date : datetime, optional
            The date to use as reference for recency calculation
            
        Returns
        -------
        pd.DataFrame
            DataFrame containing RFM metrics
        """
        try:
            if analysis_date is None:
                analysis_date = datetime.now()
                
            # Group by customer and calculate metrics
            rfm = self.data.groupby(self.customer_id_col).agg({
                self.date_col: lambda x: (analysis_date - x.max()).days,  # Recency
                self.customer_id_col: 'count',  # Frequency
                self.amount_col: 'sum'  # Monetary
            }).rename(columns={
                self.date_col: 'Recency',
                self.customer_id_col: 'Frequency',
                self.amount_col: 'Monetary'
            })
            
            self.rfm_data = rfm
            logger.info("RFM metrics calculated successfully")
            return rfm
            
        except Exception as e:
            logger.error(f"Error calculating RFM metrics: {e}")
            raise
    
    def score_rfm(self, 
                  r_weights: Optional[Tuple[float, float, float]] = None,
                  quantiles: Optional[List[float]] = None) -> pd.DataFrame:
        """
        Score RFM metrics using quantile-based scoring.
        
        Parameters
        ----------
        r_weights : tuple, optional
            Weights for Recency, Frequency, and Monetary scores
        quantiles : list, optional
            Quantile thresholds for scoring
            
        Returns
        -------
        pd.DataFrame
            DataFrame containing RFM scores
        """
        try:
            if self.rfm_data is None:
                self.calculate_rfm_metrics()
                
            # Use provided weights or default from config
            weights = r_weights or tuple(self.rfm_config['weights'].values())
            quantiles = quantiles or self.rfm_config['quantiles']
            
            # Create scoring functions
            def score_recency(x):
                if x <= self.rfm_data['Recency'].quantile(quantiles[0]):
                    return 5
                elif x <= self.rfm_data['Recency'].quantile(quantiles[1]):
                    return 4
                elif x <= self.rfm_data['Recency'].quantile(quantiles[2]):
                    return 3
                elif x <= self.rfm_data['Recency'].quantile(quantiles[3]):
                    return 2
                else:
                    return 1
                    
            def score_frequency(x):
                if x >= self.rfm_data['Frequency'].quantile(quantiles[3]):
                    return 5
                elif x >= self.rfm_data['Frequency'].quantile(quantiles[2]):
                    return 4
                elif x >= self.rfm_data['Frequency'].quantile(quantiles[1]):
                    return 3
                elif x >= self.rfm_data['Frequency'].quantile(quantiles[0]):
                    return 2
                else:
                    return 1
                    
            def score_monetary(x):
                if x >= self.rfm_data['Monetary'].quantile(quantiles[3]):
                    return 5
                elif x >= self.rfm_data['Monetary'].quantile(quantiles[2]):
                    return 4
                elif x >= self.rfm_data['Monetary'].quantile(quantiles[1]):
                    return 3
                elif x >= self.rfm_data['Monetary'].quantile(quantiles[0]):
                    return 2
                else:
                    return 1
            
            # Calculate scores
            self.rfm_data['R_Score'] = self.rfm_data['Recency'].apply(score_recency)
            self.rfm_data['F_Score'] = self.rfm_data['Frequency'].apply(score_frequency)
            self.rfm_data['M_Score'] = self.rfm_data['Monetary'].apply(score_monetary)
            
            # Calculate RFM Score
            self.rfm_data['RFM_Score'] = (
                self.rfm_data['R_Score'] * weights[0] +
                self.rfm_data['F_Score'] * weights[1] +
                self.rfm_data['M_Score'] * weights[2]
            )
            
            self.rfm_scores = self.rfm_data
            logger.info("RFM scores calculated successfully")
            return self.rfm_data
            
        except Exception as e:
            logger.error(f"Error calculating RFM scores: {e}")
            raise
    
    def segment_customers(self, segment_thresholds: Optional[Dict] = None) -> pd.DataFrame:
        """
        Segment customers based on their RFM scores.
        
        Parameters
        ----------
        segment_thresholds : dict, optional
            Custom thresholds for customer segmentation
            
        Returns
        -------
        pd.DataFrame
            DataFrame containing customer segments
        """
        try:
            if self.rfm_scores is None:
                self.score_rfm()
                
            # Use provided thresholds or default from config
            thresholds = segment_thresholds or self.rfm_config['segments']
            
            def assign_segment(score):
                for segment, (lower, upper) in thresholds.items():
                    if lower <= score <= upper:
                        return segment
                return 'Unknown'
                
            self.rfm_scores['Segment'] = self.rfm_scores['RFM_Score'].apply(assign_segment)
            self.segments = self.rfm_scores
            
            logger.info("Customer segmentation completed successfully")
            return self.rfm_scores
            
        except Exception as e:
            logger.error(f"Error in customer segmentation: {e}")
            raise
    
    def get_customer_summary(self, customer_id: str) -> Dict:
        """
        Get detailed RFM metrics for a specific customer.
        
        Parameters
        ----------
        customer_id : str
            The ID of the customer to analyze
            
        Returns
        -------
        dict
            Dictionary containing customer's RFM metrics and segment
        """
        try:
            if self.segments is None:
                self.segment_customers()
                
            customer_data = self.segments.loc[customer_id]
            return {
                'Recency': customer_data['Recency'],
                'Frequency': customer_data['Frequency'],
                'Monetary': customer_data['Monetary'],
                'R_Score': customer_data['R_Score'],
                'F_Score': customer_data['F_Score'],
                'M_Score': customer_data['M_Score'],
                'RFM_Score': customer_data['RFM_Score'],
                'Segment': customer_data['Segment']
            }
            
        except Exception as e:
            logger.error(f"Error getting customer summary: {e}")
            raise 