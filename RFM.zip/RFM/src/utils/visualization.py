import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import logging
from typing import Dict, Optional

logger = logging.getLogger(__name__)

def plot_rfm_distribution(rfm_data: pd.DataFrame,
                         metric: str = 'RFM_Score',
                         title: Optional[str] = None) -> go.Figure:
    """
    Plot the distribution of RFM metrics or scores.
    
    Parameters
    ----------
    rfm_data : pd.DataFrame
        DataFrame containing RFM metrics and scores
    metric : str
        The metric to plot ('Recency', 'Frequency', 'Monetary', 'RFM_Score')
    title : str, optional
        Custom title for the plot
        
    Returns
    -------
    go.Figure
        Plotly figure object
    """
    try:
        fig = px.histogram(rfm_data, x=metric, nbins=30,
                          title=title or f"Distribution of {metric}")
        return fig
    except Exception as e:
        logger.error(f"Error creating RFM distribution plot: {e}")
        raise

def plot_rfm_correlation(rfm_data: pd.DataFrame,
                        title: Optional[str] = None) -> go.Figure:
    """
    Plot correlation matrix of RFM metrics.
    
    Parameters
    ----------
    rfm_data : pd.DataFrame
        DataFrame containing RFM metrics
    title : str, optional
        Custom title for the plot
        
    Returns
    -------
    go.Figure
        Plotly figure object
    """
    try:
        fig = px.scatter_matrix(rfm_data,
                              dimensions=['Recency', 'Frequency', 'Monetary'],
                              title=title or "RFM Metrics Correlation")
        return fig
    except Exception as e:
        logger.error(f"Error creating RFM correlation plot: {e}")
        raise

def plot_segment_distribution(segments: pd.DataFrame,
                            title: Optional[str] = None) -> go.Figure:
    """
    Plot the distribution of customer segments.
    
    Parameters
    ----------
    segments : pd.DataFrame
        DataFrame containing customer segments
    title : str, optional
        Custom title for the plot
        
    Returns
    -------
    go.Figure
        Plotly figure object
    """
    try:
        fig = px.pie(segments, names='Segment',
                    title=title or "Customer Segment Distribution")
        return fig
    except Exception as e:
        logger.error(f"Error creating segment distribution plot: {e}")
        raise

def plot_segment_rfm_scores(segments: pd.DataFrame,
                          title: Optional[str] = None) -> go.Figure:
    """
    Plot RFM score distribution by segment.
    
    Parameters
    ----------
    segments : pd.DataFrame
        DataFrame containing customer segments and RFM scores
    title : str, optional
        Custom title for the plot
        
    Returns
    -------
    go.Figure
        Plotly figure object
    """
    try:
        fig = px.box(segments, x='Segment', y='RFM_Score',
                    title=title or "RFM Score Distribution by Segment")
        return fig
    except Exception as e:
        logger.error(f"Error creating segment RFM scores plot: {e}")
        raise

def plot_customer_transactions(transactions: pd.DataFrame,
                             date_col: str,
                             amount_col: str,
                             customer_id: str,
                             title: Optional[str] = None) -> go.Figure:
    """
    Plot transaction history for a specific customer.
    
    Parameters
    ----------
    transactions : pd.DataFrame
        DataFrame containing customer transactions
    date_col : str
        Name of the date column
    amount_col : str
        Name of the amount column
    customer_id : str
        Customer ID to plot
    title : str, optional
        Custom title for the plot
        
    Returns
    -------
    go.Figure
        Plotly figure object
    """
    try:
        fig = px.line(transactions, x=date_col, y=amount_col,
                     title=title or f"Transaction History for {customer_id}")
        return fig
    except Exception as e:
        logger.error(f"Error creating customer transaction plot: {e}")
        raise

def create_rfm_radar_chart(customer_summary: Dict,
                          title: Optional[str] = None) -> go.Figure:
    """
    Create a radar chart for customer RFM scores.
    
    Parameters
    ----------
    customer_summary : dict
        Dictionary containing customer's RFM metrics and scores
    title : str, optional
        Custom title for the plot
        
    Returns
    -------
    go.Figure
        Plotly figure object
    """
    try:
        metrics = ['R_Score', 'F_Score', 'M_Score']
        values = [customer_summary[metric] for metric in metrics]
        
        fig = go.Figure()
        
        fig.add_trace(go.Scatterpolar(
            r=values,
            theta=metrics,
            fill='toself',
            name='RFM Scores'
        ))
        
        fig.update_layout(
            polar=dict(
                radialaxis=dict(
                    visible=True,
                    range=[0, 5]
                )),
            showlegend=False,
            title=title or "Customer RFM Score Profile"
        )
        
        return fig
    except Exception as e:
        logger.error(f"Error creating RFM radar chart: {e}")
        raise 