import streamlit as st
import pandas as pd
from pathlib import Path
import yaml

from src.data.loader import load_data, load_config, generate_sample_data
from src.data.preprocess import prepare_data, validate_data
from src.models.rfm_segmentation import RFMAnalyzer
from src.utils.visualization import (
    plot_rfm_distribution,
    plot_rfm_correlation,
    plot_segment_distribution,
    plot_segment_rfm_scores,
    plot_customer_transactions,
    create_rfm_radar_chart
)
from src.utils.logger import setup_logger

# Set up logging
logger = setup_logger('rfm_app', 'logs/rfm_app.log')

# Set page config
st.set_page_config(
    page_title="RFM Analysis Dashboard",
    page_icon="📊",
    layout="wide"
)

# Custom CSS
st.markdown("""
    <style>
    .main {
        padding: 2rem;
    }
    .stButton>button {
        width: 100%;
    }
    </style>
""", unsafe_allow_html=True)

def main():
    st.title("📊 RFM Analysis Dashboard")
    
    try:
        # Load configuration
        config = load_config()
        
        # Sidebar
        st.sidebar.header("Data Input")
        data_source = st.sidebar.radio(
            "Choose Data Source",
            ["Upload CSV", "Use Sample Data"]
        )
        
        if data_source == "Upload CSV":
            uploaded_file = st.sidebar.file_uploader("Upload your CSV file", type=['csv'])
            if uploaded_file is not None:
                df = load_data(uploaded_file)
                st.sidebar.success("Data loaded successfully!")
            else:
                st.sidebar.info("Please upload a CSV file or use sample data")
                return
        else:
            n_customers = st.sidebar.slider("Number of Customers", 100, 5000, 1000)
            n_transactions = st.sidebar.slider("Number of Transactions", 500, 10000, 5000)
            df = generate_sample_data(n_customers, n_transactions)
            st.sidebar.success("Sample data generated!")
        
        # Column selection
        st.sidebar.header("Column Mapping")
        customer_id_col = st.sidebar.selectbox("Select Customer ID Column", df.columns)
        date_col = st.sidebar.selectbox("Select Date Column", df.columns)
        amount_col = st.sidebar.selectbox("Select Amount Column", df.columns)
        
        # Validate data
        if not validate_data(df, customer_id_col, date_col, amount_col):
            st.error("Invalid data format. Please check your data and column selections.")
            return
        
        # Prepare data
        df = prepare_data(df, customer_id_col, date_col, amount_col)
        
        # Analysis parameters
        st.sidebar.header("Analysis Parameters")
        r_weight = st.sidebar.slider("Recency Weight", 0.0, 1.0, 
                                   config['rfm']['weights']['recency'], 0.1)
        f_weight = st.sidebar.slider("Frequency Weight", 0.0, 1.0, 
                                   config['rfm']['weights']['frequency'], 0.1)
        m_weight = st.sidebar.slider("Monetary Weight", 0.0, 1.0, 
                                   config['rfm']['weights']['monetary'], 0.1)
        
        # Initialize RFM Analyzer
        rfm = RFMAnalyzer(
            data=df,
            customer_id_col=customer_id_col,
            date_col=date_col,
            amount_col=amount_col,
            config=config
        )
        
        # Main content
        tab1, tab2, tab3 = st.tabs(["Overview", "Customer Segments", "Detailed Analysis"])
        
        with tab1:
            st.header("RFM Analysis Overview")
            
            # Calculate metrics
            rfm_metrics = rfm.calculate_rfm_metrics()
            rfm_scores = rfm.score_rfm(r_weights=(r_weight, f_weight, m_weight))
            
            # Display metrics summary
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Total Customers", len(rfm_metrics))
            with col2:
                st.metric("Average Transaction Value", f"${rfm_metrics['Monetary'].mean():.2f}")
            with col3:
                st.metric("Average Frequency", f"{rfm_metrics['Frequency'].mean():.1f}")
            
            # RFM Score Distribution
            fig = plot_rfm_distribution(rfm_scores)
            st.plotly_chart(fig, use_container_width=True)
            
            # RFM Metrics Correlation
            fig = plot_rfm_correlation(rfm_metrics)
            st.plotly_chart(fig, use_container_width=True)
        
        with tab2:
            st.header("Customer Segmentation")
            
            # Segment customers
            segments = rfm.segment_customers()
            
            # Segment distribution
            fig = plot_segment_distribution(segments)
            st.plotly_chart(fig, use_container_width=True)
            
            # Segment metrics
            segment_metrics = segments.groupby('Segment').agg({
                'Recency': 'mean',
                'Frequency': 'mean',
                'Monetary': 'mean'
            }).round(2)
            
            st.subheader("Segment Metrics")
            st.dataframe(segment_metrics)
            
            # Segment RFM Score distribution
            fig = plot_segment_rfm_scores(segments)
            st.plotly_chart(fig, use_container_width=True)
        
        with tab3:
            st.header("Detailed Customer Analysis")
            
            # Customer search
            customer_id = st.selectbox("Select Customer ID", segments.index)
            
            if customer_id:
                customer_summary = rfm.get_customer_summary(customer_id)
                
                # Display customer metrics
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Recency", f"{customer_summary['Recency']:.0f} days")
                with col2:
                    st.metric("Frequency", f"{customer_summary['Frequency']:.0f}")
                with col3:
                    st.metric("Monetary", f"${customer_summary['Monetary']:.2f}")
                
                # Display customer scores
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("R Score", customer_summary['R_Score'])
                with col2:
                    st.metric("F Score", customer_summary['F_Score'])
                with col3:
                    st.metric("M Score", customer_summary['M_Score'])
                
                st.metric("RFM Score", f"{customer_summary['RFM_Score']:.2f}")
                st.metric("Segment", customer_summary['Segment'])
                
                # Customer transaction history
                customer_transactions = df[df[customer_id_col] == customer_id].sort_values(date_col)
                fig = plot_customer_transactions(
                    customer_transactions,
                    date_col,
                    amount_col,
                    customer_id
                )
                st.plotly_chart(fig, use_container_width=True)
                
                # RFM Radar Chart
                fig = create_rfm_radar_chart(customer_summary)
                st.plotly_chart(fig, use_container_width=True)
        
        # Export functionality
        st.sidebar.header("Export Results")
        if st.sidebar.button("Export Analysis Results"):
            output = segments.to_csv(index=True)
            st.sidebar.download_button(
                label="Download CSV",
                data=output,
                file_name="rfm_analysis_results.csv",
                mime="text/csv"
            )
            
    except Exception as e:
        logger.error(f"Error in main application: {e}")
        st.error(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    main() 