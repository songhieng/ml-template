"""
Anomaly detection models
""" 