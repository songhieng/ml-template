"""
Model evaluation module for fraud detection.
This module provides functions to evaluate and compare different fraud detection models.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, average_precision_score, 
    confusion_matrix, classification_report,
    precision_recall_curve, roc_curve
)
import logging
import os
from datetime import datetime

# Set up logger
logger = logging.getLogger("fraud_detection.model_evaluation")

def calculate_metrics(y_true, y_pred, y_proba=None):
    """
    Calculate evaluation metrics for a binary classification model.
    
    Parameters:
    -----------
    y_true : array-like
        True binary labels
    y_pred : array-like
        Predicted binary labels
    y_proba : array-like, optional
        Predicted probabilities for the positive class
        
    Returns:
    --------
    dict
        Dictionary containing evaluation metrics
    """
    # Basic metrics
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, zero_division=0)
    recall = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    
    # Confusion matrix
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    
    # Advanced metrics if probabilities are provided
    metrics = {
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1': f1,
        'true_positives': tp,
        'false_positives': fp,
        'true_negatives': tn,
        'false_negatives': fn
    }
    
    if y_proba is not None:
        auc = roc_auc_score(y_true, y_proba)
        avg_precision = average_precision_score(y_true, y_proba)
        metrics.update({
            'auc': auc,
            'average_precision': avg_precision
        })
    
    return metrics

def evaluate_model(model, X_test, y_test, model_name="Model", threshold=0.5):
    """
    Evaluate a trained model on test data.
    
    Parameters:
    -----------
    model : object
        Trained classifier with predict and predict_proba methods
    X_test : numpy.ndarray or pandas.DataFrame
        Test feature matrix
    y_test : numpy.ndarray or pandas.Series
        Test target vector
    model_name : str, optional
        Name of the model for logging purposes
    threshold : float, optional
        Decision threshold for binary classification
        
    Returns:
    --------
    dict
        Dictionary containing evaluation results
    """
    logger.info(f"Evaluating {model_name}...")
    
    # Get predictions
    y_pred = model.predict(X_test)
    
    # Get probability predictions if available
    y_proba = None
    if hasattr(model, 'predict_proba'):
        try:
            y_proba = model.predict_proba(X_test)[:, 1]
            
            # Apply custom threshold if needed
            if threshold != 0.5:
                y_pred = (y_proba >= threshold).astype(int)
                logger.info(f"Applied custom threshold: {threshold}")
        except:
            logger.warning(f"Could not get probability predictions for {model_name}")
    
    # Calculate metrics
    metrics = calculate_metrics(y_test, y_pred, y_proba)
    metrics['model_name'] = model_name
    metrics['y_pred'] = y_pred
    metrics['y_proba'] = y_proba
    metrics['y_test'] = y_test
    
    # Print results
    logger.info(f"\nEvaluation Results for {model_name}:")
    logger.info(f"Accuracy: {metrics['accuracy']:.4f}")
    logger.info(f"Precision: {metrics['precision']:.4f}")
    logger.info(f"Recall: {metrics['recall']:.4f}")
    logger.info(f"F1-Score: {metrics['f1']:.4f}")
    
    if 'auc' in metrics:
        logger.info(f"ROC AUC: {metrics['auc']:.4f}")
        logger.info(f"Average Precision: {metrics['average_precision']:.4f}")
    
    logger.info(f"Confusion Matrix:")
    logger.info(f"TN: {metrics['true_negatives']}, FP: {metrics['false_positives']}")
    logger.info(f"FN: {metrics['false_negatives']}, TP: {metrics['true_positives']}")
    
    return metrics

def compare_models(model_results_list):
    """
    Compare multiple models based on their evaluation metrics.
    
    Parameters:
    -----------
    model_results_list : list of dict
        List of dictionaries containing model evaluation results
        
    Returns:
    --------
    pandas.DataFrame
        DataFrame with model comparison
    """
    logger.info("Comparing model performances...")
    
    # Extract metrics for comparison
    comparison_data = []
    for results in model_results_list:
        comparison_data.append({
            'Model': results['model_name'],
            'Accuracy': results.get('accuracy', float('nan')),
            'Precision': results.get('precision', float('nan')),
            'Recall': results.get('recall', float('nan')),
            'F1-Score': results.get('f1', float('nan')),
            'ROC AUC': results.get('auc', float('nan')),
            'Avg Precision': results.get('average_precision', float('nan')),
            'TP': results.get('true_positives', float('nan')),
            'FP': results.get('false_positives', float('nan')),
            'TN': results.get('true_negatives', float('nan')),
            'FN': results.get('false_negatives', float('nan'))
        })
    
    # Create comparison DataFrame
    comparison_df = pd.DataFrame(comparison_data)
    
    # Sort by ROC AUC or F1-Score
    if 'ROC AUC' in comparison_df.columns and not comparison_df['ROC AUC'].isna().all():
        comparison_df = comparison_df.sort_values('ROC AUC', ascending=False)
    elif 'F1-Score' in comparison_df.columns:
        comparison_df = comparison_df.sort_values('F1-Score', ascending=False)
    
    logger.info(f"\nModel Comparison Summary:\n{comparison_df}")
    return comparison_df

def plot_roc_curves(model_results_list, figsize=(10, 8), save_path=None):
    """
    Plot ROC curves for multiple models.
    
    Parameters:
    -----------
    model_results_list : list of dict
        List of dictionaries containing model evaluation results
    figsize : tuple, optional
        Figure size (width, height)
    save_path : str, optional
        Path to save the figure
        
    Returns:
    --------
    matplotlib.figure.Figure
        The created figure
    """
    plt.figure(figsize=figsize)
    
    for results in model_results_list:
        model_name = results['model_name']
        y_test = results.get('y_test', None)
        y_proba = results.get('y_proba', None)
        
        if y_test is None or y_proba is None:
            logger.warning(f"Missing test data or probabilities for {model_name}")
            continue
        
        # Calculate ROC curve
        fpr, tpr, _ = roc_curve(y_test, y_proba)
        auc = results.get('auc', roc_auc_score(y_test, y_proba))
        
        # Plot ROC curve
        plt.plot(fpr, tpr, label=f'{model_name} (AUC = {auc:.3f})')
    
    # Add random classifier reference line
    plt.plot([0, 1], [0, 1], 'k--', label='Random')
    
    # Add labels and legend
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic (ROC) Curves')
    plt.legend(loc='lower right')
    
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    
    # Save figure if path is provided
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        logger.info(f"ROC curves saved to {save_path}")
    
    return plt.gcf()

def plot_precision_recall_curves(model_results_list, figsize=(10, 8), save_path=None):
    """
    Plot Precision-Recall curves for multiple models.
    
    Parameters:
    -----------
    model_results_list : list of dict
        List of dictionaries containing model evaluation results
    figsize : tuple, optional
        Figure size (width, height)
    save_path : str, optional
        Path to save the figure
        
    Returns:
    --------
    matplotlib.figure.Figure
        The created figure
    """
    plt.figure(figsize=figsize)
    
    # Get the first available y_test for the no-skill classifier
    y_test = None
    for results in model_results_list:
        if 'y_test' in results:
            y_test = results['y_test']
            break
    
    for results in model_results_list:
        model_name = results['model_name']
        y_test = results.get('y_test', None)
        y_proba = results.get('y_proba', None)
        
        if y_test is None or y_proba is None:
            logger.warning(f"Missing test data or probabilities for {model_name}")
            continue
        
        # Calculate Precision-Recall curve
        precision, recall, _ = precision_recall_curve(y_test, y_proba)
        ap = results.get('average_precision', average_precision_score(y_test, y_proba))
        
        # Plot Precision-Recall curve
        plt.plot(recall, precision, label=f'{model_name} (AP = {ap:.3f})')
    
    # Add no-skill classifier reference line (if we have y_test)
    if y_test is not None:
        no_skill = np.sum(y_test) / len(y_test)
        plt.plot([0, 1], [no_skill, no_skill], 'k--', label=f'No Skill (AP = {no_skill:.3f})')
    
    # Add labels and legend
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('Precision-Recall Curves')
    plt.legend(loc='best')
    
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    
    # Save figure if path is provided
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        logger.info(f"Precision-Recall curves saved to {save_path}")
    
    return plt.gcf()

def plot_confusion_matrices(model_results_list, figsize=(15, 10), save_path=None):
    """
    Plot confusion matrices for multiple models.
    
    Parameters:
    -----------
    model_results_list : list of dict
        List of dictionaries containing model evaluation results
    figsize : tuple, optional
        Figure size (width, height)
    save_path : str, optional
        Path to save the figure
        
    Returns:
    --------
    matplotlib.figure.Figure
        The created figure
    """
    n_models = len(model_results_list)
    n_cols = min(n_models, 3)
    n_rows = (n_models + n_cols - 1) // n_cols
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=figsize)
    if n_rows == 1 and n_cols == 1:
        axes = np.array([axes])
    axes = axes.flatten()
    
    for i, results in enumerate(model_results_list):
        if i >= len(axes):
            logger.warning(f"Not enough subplots for all models")
            break
            
        model_name = results['model_name']
        y_test = results.get('y_test', None)
        y_pred = results.get('y_pred', None)
        
        if y_test is None or y_pred is None:
            logger.warning(f"Missing test data or predictions for {model_name}")
            continue
        
        # Calculate confusion matrix
        cm = confusion_matrix(y_test, y_pred)
        
        # Plot confusion matrix
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=axes[i])
        axes[i].set_title(f'{model_name}')
        axes[i].set_xlabel('Predicted')
        axes[i].set_ylabel('Actual')
        axes[i].set_xticklabels(['Not Fraud', 'Fraud'])
        axes[i].set_yticklabels(['Not Fraud', 'Fraud'])
    
    # Hide empty subplots
    for i in range(len(model_results_list), len(axes)):
        axes[i].axis('off')
    
    plt.tight_layout()
    
    # Save figure if path is provided
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        logger.info(f"Confusion matrices saved to {save_path}")
    
    return fig

def generate_evaluation_report(model_results_list, output_dir=None):
    """
    Generate comprehensive evaluation report for multiple models.
    
    Parameters:
    -----------
    model_results_list : list of dict
        List of dictionaries containing model evaluation results
    output_dir : str, optional
        Directory to save the report and figures
        
    Returns:
    --------
    pandas.DataFrame
        DataFrame with model comparison
    """
    # Create output directory if provided
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Compare models
    comparison_df = compare_models(model_results_list)
    
    # Generate plots
    if output_dir:
        # Save model comparison to CSV
        comparison_csv = os.path.join(output_dir, f'model_comparison_{timestamp}.csv')
        comparison_df.to_csv(comparison_csv, index=False)
        logger.info(f"Model comparison saved to {comparison_csv}")
        
        # Save ROC curves
        roc_path = os.path.join(output_dir, f'roc_curves_{timestamp}.png')
        plot_roc_curves(model_results_list, save_path=roc_path)
        
        # Save Precision-Recall curves
        pr_path = os.path.join(output_dir, f'precision_recall_curves_{timestamp}.png')
        plot_precision_recall_curves(model_results_list, save_path=pr_path)
        
        # Save Confusion matrices
        cm_path = os.path.join(output_dir, f'confusion_matrices_{timestamp}.png')
        plot_confusion_matrices(model_results_list, save_path=cm_path)
        
        # Generate HTML report if possible
        try:
            import base64
            from io import BytesIO
            
            html_content = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Fraud Detection Model Evaluation Report</title>
                <style>
                    body {{ font-family: Arial, sans-serif; margin: 20px; }}
                    table {{ border-collapse: collapse; width: 100%; }}
                    th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                    th {{ background-color: #f2f2f2; }}
                    tr:nth-child(even) {{ background-color: #f9f9f9; }}
                    h1, h2 {{ color: #333; }}
                    .container {{ margin-bottom: 30px; }}
                    img {{ max-width: 100%; height: auto; margin: 10px 0; }}
                </style>
            </head>
            <body>
                <h1>Fraud Detection Model Evaluation Report</h1>
                <p>Generated on: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
                
                <div class="container">
                    <h2>Model Comparison</h2>
                    {comparison_df.to_html(index=False)}
                </div>
                
                <div class="container">
                    <h2>ROC Curves</h2>
                    <img src="roc_curves_{timestamp}.png" alt="ROC Curves">
                </div>
                
                <div class="container">
                    <h2>Precision-Recall Curves</h2>
                    <img src="precision_recall_curves_{timestamp}.png" alt="Precision-Recall Curves">
                </div>
                
                <div class="container">
                    <h2>Confusion Matrices</h2>
                    <img src="confusion_matrices_{timestamp}.png" alt="Confusion Matrices">
                </div>
            </body>
            </html>
            """
            
            html_path = os.path.join(output_dir, f'evaluation_report_{timestamp}.html')
            with open(html_path, 'w') as f:
                f.write(html_content)
            
            logger.info(f"HTML report saved to {html_path}")
        except Exception as e:
            logger.warning(f"Could not generate HTML report: {str(e)}")
    
    return comparison_df

def plot_threshold_impact(model_results, metric='f1', thresholds=None, figsize=(10, 6), save_path=None):
    """
    Plot the impact of different decision thresholds on model performance.
    
    Parameters:
    -----------
    model_results : dict
        Dictionary containing model evaluation results
    metric : str, optional
        Metric to optimize ('accuracy', 'precision', 'recall', 'f1')
    thresholds : array-like, optional
        Array of thresholds to evaluate
    figsize : tuple, optional
        Figure size (width, height)
    save_path : str, optional
        Path to save the figure
        
    Returns:
    --------
    tuple
        (best_threshold, best_score, figure)
    """
    y_test = model_results.get('y_test', None)
    y_proba = model_results.get('y_proba', None)
    model_name = model_results.get('model_name', 'Model')
    
    if y_test is None or y_proba is None:
        logger.warning(f"Missing test data or probabilities for {model_name}")
        return None, None, None
    
    # Define thresholds if not provided
    if thresholds is None:
        thresholds = np.linspace(0.1, 0.9, 9)
    
    # Calculate metrics for each threshold
    threshold_metrics = []
    for threshold in thresholds:
        y_pred = (y_proba >= threshold).astype(int)
        
        # Calculate metrics
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred, zero_division=0)
        recall = recall_score(y_test, y_pred, zero_division=0)
        f1 = f1_score(y_test, y_pred, zero_division=0)
        
        threshold_metrics.append({
            'threshold': threshold,
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1': f1
        })
    
    # Convert to DataFrame
    metrics_df = pd.DataFrame(threshold_metrics)
    
    # Find best threshold for the selected metric
    best_index = metrics_df[metric].idxmax()
    best_threshold = metrics_df.loc[best_index, 'threshold']
    best_score = metrics_df.loc[best_index, metric]
    
    # Create figure
    plt.figure(figsize=figsize)
    
    # Plot metrics
    for m in ['accuracy', 'precision', 'recall', 'f1']:
        plt.plot(metrics_df['threshold'], metrics_df[m], marker='o', label=m.capitalize())
    
    # Mark the best threshold
    plt.axvline(x=best_threshold, color='gray', linestyle='--')
    plt.text(best_threshold, 0.5, f' Best {metric}: {best_threshold:.2f}', 
             ha='left', va='center', rotation=0, color='black')
    
    plt.xlabel('Threshold')
    plt.ylabel('Score')
    plt.title(f'Impact of Decision Threshold on Metrics - {model_name}')
    plt.legend(loc='best')
    plt.grid(True, alpha=0.3)
    
    # Save figure if path is provided
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        logger.info(f"Threshold impact plot saved to {save_path}")
    
    logger.info(f"Best {metric.capitalize()} score of {best_score:.4f} at threshold {best_threshold:.2f}")
    
    return best_threshold, best_score, plt.gcf()

def analyze_feature_importance(model, feature_names, top_n=20, figsize=(12, 8), save_path=None):
    """
    Analyze and plot feature importance for a model.
    
    Parameters:
    -----------
    model : object
        Trained model with feature_importances_ attribute
    feature_names : list
        List of feature names
    top_n : int, optional
        Number of top features to display
    figsize : tuple, optional
        Figure size (width, height)
    save_path : str, optional
        Path to save the figure
        
    Returns:
    --------
    tuple
        (feature_importance_df, figure)
    """
    if not hasattr(model, 'feature_importances_'):
        logger.warning("Model does not have feature_importances_ attribute")
        if hasattr(model, 'coef_'):
            # For linear models use coefficient magnitudes
            logger.info("Using coefficient magnitudes for feature importance")
            importances = np.abs(model.coef_[0])
        else:
            return None, None
    else:
        importances = model.feature_importances_
    
    # Create DataFrame of feature importances
    importance_df = pd.DataFrame({
        'feature': feature_names,
        'importance': importances
    })
    
    # Sort by importance
    importance_df = importance_df.sort_values('importance', ascending=False)
    
    # Show top N features
    top_features = importance_df.head(top_n)
    
    # Create figure
    plt.figure(figsize=figsize)
    
    # Plot horizontal bar chart
    sns.barplot(x='importance', y='feature', data=top_features)
    plt.title(f'Top {top_n} Feature Importances')
    plt.xlabel('Importance')
    plt.ylabel('Feature')
    plt.tight_layout()
    
    # Save figure if path is provided
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        logger.info(f"Feature importance plot saved to {save_path}")
    
    return importance_df, plt.gcf()

def analyze_cost_benefit(model_results, cost_matrix=None, thresholds=None, figsize=(10, 6), save_path=None):
    """
    Analyze the cost-benefit of the model at different thresholds.
    
    Parameters:
    -----------
    model_results : dict
        Dictionary containing model evaluation results
    cost_matrix : dict, optional
        Dictionary specifying costs/benefits: {'tp': benefit, 'fp': cost, 'tn': benefit, 'fn': cost}
    thresholds : array-like, optional
        Array of thresholds to evaluate
    figsize : tuple, optional
        Figure size (width, height)
    save_path : str, optional
        Path to save the figure
        
    Returns:
    --------
    tuple
        (best_threshold, best_profit, figure)
    """
    y_test = model_results.get('y_test', None)
    y_proba = model_results.get('y_proba', None)
    model_name = model_results.get('model_name', 'Model')
    
    if y_test is None or y_proba is None:
        logger.warning(f"Missing test data or probabilities for {model_name}")
        return None, None, None
    
    # Define default cost matrix if not provided
    if cost_matrix is None:
        # Default: TP: +1000 (caught fraud), FP: -100 (false alarm), TN: +10 (normal operation), FN: -500 (missed fraud)
        cost_matrix = {'tp': 1000, 'fp': -100, 'tn': 10, 'fn': -500}
    
    # Define thresholds if not provided
    if thresholds is None:
        thresholds = np.linspace(0.01, 0.99, 99)
    
    # Calculate profit for each threshold
    threshold_results = []
    for threshold in thresholds:
        y_pred = (y_proba >= threshold).astype(int)
        
        # Calculate confusion matrix
        tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()
        
        # Calculate profit
        profit = (tp * cost_matrix['tp'] + 
                 fp * cost_matrix['fp'] + 
                 tn * cost_matrix['tn'] + 
                 fn * cost_matrix['fn'])
        
        threshold_results.append({
            'threshold': threshold,
            'profit': profit,
            'tp': tp,
            'fp': fp,
            'tn': tn,
            'fn': fn
        })
    
    # Convert to DataFrame
    results_df = pd.DataFrame(threshold_results)
    
    # Find best threshold
    best_index = results_df['profit'].idxmax()
    best_threshold = results_df.loc[best_index, 'threshold']
    best_profit = results_df.loc[best_index, 'profit']
    
    # Create figure
    plt.figure(figsize=figsize)
    
    # Plot profit
    plt.plot(results_df['threshold'], results_df['profit'], 'b-', linewidth=2)
    
    # Mark the best threshold
    plt.axvline(x=best_threshold, color='red', linestyle='--')
    plt.text(best_threshold, results_df['profit'].min(), 
             f' Best threshold: {best_threshold:.2f}\n Profit: {best_profit:.0f}', 
             ha='left', va='bottom', color='red')
    
    plt.xlabel('Decision Threshold')
    plt.ylabel('Profit')
    plt.title(f'Cost-Benefit Analysis - {model_name}')
    plt.grid(True, alpha=0.3)
    
    # Save figure if path is provided
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        logger.info(f"Cost-benefit analysis plot saved to {save_path}")
    
    logger.info(f"Best profit {best_profit:.0f} at threshold {best_threshold:.2f}")
    
    return best_threshold, best_profit, plt.gcf()

if __name__ == "__main__":
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Example usage
    logger.info("This module provides functions for model evaluation in fraud detection.")
    logger.info("Import and use these functions in your main script.") 