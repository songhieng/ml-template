"""
Supervised learning module for fraud detection in financial transactions.
This module implements various algorithms for detecting fraudulent transactions.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.metrics import confusion_matrix, classification_report, roc_curve, roc_auc_score, precision_recall_curve, average_precision_score
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier
import logging

# Set up logger
logger = logging.getLogger("fraud_detection.supervised_learning")

def prepare_train_test_split(X, y, test_size=0.3, random_state=42):
    """
    Split the dataset into training and testing sets.
    
    Parameters:
    -----------
    X : numpy.ndarray or pandas.DataFrame
        Feature matrix
    y : numpy.ndarray or pandas.Series
        Target vector
    test_size : float, optional
        Proportion of the dataset to include in the test split
    random_state : int, optional
        Seed for random number generator
    
    Returns:
    --------
    X_train : numpy.ndarray or pandas.DataFrame
        Training feature matrix
    X_test : numpy.ndarray or pandas.DataFrame
        Testing feature matrix
    y_train : numpy.ndarray or pandas.Series
        Training target vector
    y_test : numpy.ndarray or pandas.Series
        Testing target vector
    """
    logger.info(f"Splitting data into training and testing sets (test size: {test_size})...")
    return train_test_split(X, y, test_size=test_size, random_state=random_state, stratify=y)

def train_logistic_regression(X_train, y_train, class_weight='balanced', C=1.0):
    """
    Train a logistic regression model.
    
    Parameters:
    -----------
    X_train : numpy.ndarray or pandas.DataFrame
        Training feature matrix
    y_train : numpy.ndarray or pandas.Series
        Training target vector
    class_weight : str or dict, optional
        Weights associated with classes (use 'balanced' for imbalanced datasets)
    C : float, optional
        Inverse of regularization strength
        
    Returns:
    --------
    model : LogisticRegression
        Trained logistic regression model
    """
    logger.info("Training Logistic Regression model...")
    
    model = LogisticRegression(
        class_weight=class_weight, 
        C=C, 
        max_iter=1000, 
        random_state=42
    )
    model.fit(X_train, y_train)
    
    logger.info("Logistic Regression model training complete")
    return model

def train_random_forest(X_train, y_train, n_estimators=100, max_depth=None, class_weight='balanced'):
    """
    Train a random forest classifier.
    
    Parameters:
    -----------
    X_train : numpy.ndarray or pandas.DataFrame
        Training feature matrix
    y_train : numpy.ndarray or pandas.Series
        Training target vector
    n_estimators : int, optional
        Number of trees in the forest
    max_depth : int or None, optional
        Maximum depth of the trees
    class_weight : str or dict, optional
        Weights associated with classes (use 'balanced' for imbalanced datasets)
        
    Returns:
    --------
    model : RandomForestClassifier
        Trained random forest model
    """
    logger.info(f"Training Random Forest with {n_estimators} estimators...")
    
    model = RandomForestClassifier(
        n_estimators=n_estimators, 
        max_depth=max_depth, 
        class_weight=class_weight, 
        random_state=42,
        n_jobs=-1
    )
    model.fit(X_train, y_train)
    
    logger.info("Random Forest model training complete")
    return model

def train_gradient_boosting(X_train, y_train, n_estimators=100, learning_rate=0.1, max_depth=3):
    """
    Train a gradient boosting classifier.
    
    Parameters:
    -----------
    X_train : numpy.ndarray or pandas.DataFrame
        Training feature matrix
    y_train : numpy.ndarray or pandas.Series
        Training target vector
    n_estimators : int, optional
        Number of boosting stages
    learning_rate : float, optional
        Shrinks the contribution of each tree
    max_depth : int, optional
        Maximum depth of the individual trees
        
    Returns:
    --------
    model : GradientBoostingClassifier
        Trained gradient boosting model
    """
    logger.info(f"Training Gradient Boosting Classifier with {n_estimators} estimators...")
    
    model = GradientBoostingClassifier(
        n_estimators=n_estimators, 
        learning_rate=learning_rate, 
        max_depth=max_depth, 
        random_state=42
    )
    model.fit(X_train, y_train)
    
    logger.info("Gradient Boosting model training complete")
    return model

def train_xgboost(X_train, y_train, n_estimators=100, learning_rate=0.1, max_depth=3, scale_pos_weight=None):
    """
    Train an XGBoost classifier.
    
    Parameters:
    -----------
    X_train : numpy.ndarray or pandas.DataFrame
        Training feature matrix
    y_train : numpy.ndarray or pandas.Series
        Training target vector
    n_estimators : int, optional
        Number of boosting rounds
    learning_rate : float, optional
        Step size shrinkage used to prevent overfitting
    max_depth : int, optional
        Maximum depth of the individual trees
    scale_pos_weight : float or None, optional
        Control the balance of positive and negative weights
        
    Returns:
    --------
    model : XGBClassifier
        Trained XGBoost model
    """
    logger.info(f"Training XGBoost Classifier with {n_estimators} estimators...")
    
    # Calculate scale_pos_weight if not provided
    if scale_pos_weight is None:
        scale_pos_weight = sum(y_train == 0) / sum(y_train == 1) if sum(y_train == 1) > 0 else 1.0
    
    model = XGBClassifier(
        n_estimators=n_estimators, 
        learning_rate=learning_rate, 
        max_depth=max_depth, 
        scale_pos_weight=scale_pos_weight,
        random_state=42,
        n_jobs=-1
    )
    model.fit(X_train, y_train)
    
    logger.info("XGBoost model training complete")
    return model

def train_svm(X_train, y_train, kernel='rbf', C=1.0, class_weight='balanced'):
    """
    Train a Support Vector Machine classifier.
    
    Parameters:
    -----------
    X_train : numpy.ndarray or pandas.DataFrame
        Training feature matrix
    y_train : numpy.ndarray or pandas.Series
        Training target vector
    kernel : str, optional
        Kernel type ('linear', 'poly', 'rbf', 'sigmoid')
    C : float, optional
        Regularization parameter
    class_weight : str or dict, optional
        Weights associated with classes (use 'balanced' for imbalanced datasets)
        
    Returns:
    --------
    model : SVC
        Trained SVM model
    """
    logger.info(f"Training SVM with {kernel} kernel...")
    
    model = SVC(
        kernel=kernel, 
        C=C, 
        class_weight=class_weight, 
        probability=True, 
        random_state=42
    )
    model.fit(X_train, y_train)
    
    logger.info("SVM model training complete")
    return model

def train_neural_network(X_train, y_train, hidden_layers=(100, 50), activation='relu', solver='adam', alpha=0.0001):
    """
    Train a neural network classifier.
    
    Parameters:
    -----------
    X_train : numpy.ndarray or pandas.DataFrame
        Training feature matrix
    y_train : numpy.ndarray or pandas.Series
        Training target vector
    hidden_layers : tuple, optional
        Number of neurons in each hidden layer
    activation : str, optional
        Activation function ('identity', 'logistic', 'tanh', 'relu')
    solver : str, optional
        Solver for weight optimization ('lbfgs', 'sgd', 'adam')
    alpha : float, optional
        L2 regularization term
        
    Returns:
    --------
    model : MLPClassifier
        Trained neural network model
    """
    logger.info(f"Training Neural Network with architecture {hidden_layers}...")
    
    model = MLPClassifier(
        hidden_layer_sizes=hidden_layers, 
        activation=activation, 
        solver=solver, 
        alpha=alpha, 
        max_iter=1000, 
        random_state=42
    )
    model.fit(X_train, y_train)
    
    logger.info("Neural Network model training complete")
    return model

def evaluate_model(model, X_test, y_test, model_name="Model"):
    """
    Evaluate a trained model on test data.
    
    Parameters:
    -----------
    model : object
        Trained classifier with predict and predict_proba methods
    X_test : numpy.ndarray or pandas.DataFrame
        Testing feature matrix
    y_test : numpy.ndarray or pandas.Series
        Testing target vector
    model_name : str, optional
        Name of the model for logging purposes
    
    Returns:
    --------
    dict
        Dictionary containing evaluation metrics
    """
    logger.info(f"Evaluating {model_name}...")
    
    # Make predictions
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]
    
    # Calculate confusion matrix
    tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()
    
    # Calculate metrics
    accuracy = (tp + tn) / (tp + tn + fp + fn)
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
    
    # Calculate ROC AUC
    auc = roc_auc_score(y_test, y_proba)
    
    # Calculate average precision score (AP)
    ap = average_precision_score(y_test, y_proba)
    
    # Print report
    logger.info(f"\nEvaluation Results for {model_name}:")
    logger.info(f"Accuracy: {accuracy:.4f}")
    logger.info(f"Precision: {precision:.4f}")
    logger.info(f"Recall: {recall:.4f}")
    logger.info(f"F1-Score: {f1:.4f}")
    logger.info(f"ROC AUC: {auc:.4f}")
    logger.info(f"Average Precision: {ap:.4f}")
    
    # Detailed classification report
    report = classification_report(y_test, y_pred)
    logger.info(f"\nClassification Report:\n{report}")
    
    # Return metrics
    return {
        'model_name': model_name,
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1': f1,
        'auc': auc,
        'average_precision': ap,
        'true_negatives': tn,
        'false_positives': fp,
        'false_negatives': fn,
        'true_positives': tp,
        'y_pred': y_pred,
        'y_proba': y_proba
    }

def cross_validate_model(model, X, y, cv=5, scoring='roc_auc', model_name="Model"):
    """
    Perform cross-validation on a model.
    
    Parameters:
    -----------
    model : object
        Classifier object
    X : numpy.ndarray or pandas.DataFrame
        Feature matrix
    y : numpy.ndarray or pandas.Series
        Target vector
    cv : int, optional
        Number of folds in cross-validation
    scoring : str, optional
        Scoring metric for cross-validation
    model_name : str, optional
        Name of the model for logging purposes
    
    Returns:
    --------
    dict
        Dictionary containing cross-validation results
    """
    logger.info(f"Performing {cv}-fold cross-validation for {model_name}...")
    
    # Create stratified k-fold for imbalanced classification
    skf = StratifiedKFold(n_splits=cv, shuffle=True, random_state=42)
    
    # Perform cross-validation
    scores = cross_val_score(model, X, y, cv=skf, scoring=scoring, n_jobs=-1)
    
    logger.info(f"Cross-validation {scoring} scores: {scores}")
    logger.info(f"Mean {scoring}: {np.mean(scores):.4f}, Std: {np.std(scores):.4f}")
    
    return {
        'model_name': model_name,
        'mean_score': np.mean(scores),
        'std_score': np.std(scores),
        'all_scores': scores,
        'scoring_metric': scoring,
        'n_folds': cv
    }

def plot_roc_curve(model_results_list, figsize=(10, 8)):
    """
    Plot ROC curves for multiple models.
    
    Parameters:
    -----------
    model_results_list : list of dict
        List of model evaluation result dictionaries
    figsize : tuple, optional
        Size of the figure
    
    Returns:
    --------
    matplotlib.figure.Figure
        The created figure
    """
    plt.figure(figsize=figsize)
    
    for results in model_results_list:
        model_name = results['model_name']
        y_test = results.get('y_test', None)
        y_proba = results.get('y_proba', None)
        
        if y_test is None or y_proba is None:
            logger.warning(f"Missing test data or probabilities for {model_name}")
            continue
        
        # Calculate ROC curve
        fpr, tpr, _ = roc_curve(y_test, y_proba)
        auc = results.get('auc', roc_auc_score(y_test, y_proba))
        
        # Plot ROC curve
        plt.plot(fpr, tpr, label=f'{model_name} (AUC = {auc:.3f})')
    
    # Add random classifier reference line
    plt.plot([0, 1], [0, 1], 'k--', label='Random')
    
    # Add labels and legend
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic (ROC) Curves')
    plt.legend(loc='lower right')
    
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    
    return plt.gcf()

def plot_precision_recall_curve(model_results_list, figsize=(10, 8)):
    """
    Plot Precision-Recall curves for multiple models.
    
    Parameters:
    -----------
    model_results_list : list of dict
        List of model evaluation result dictionaries
    figsize : tuple, optional
        Size of the figure
    
    Returns:
    --------
    matplotlib.figure.Figure
        The created figure
    """
    plt.figure(figsize=figsize)
    
    for results in model_results_list:
        model_name = results['model_name']
        y_test = results.get('y_test', None)
        y_proba = results.get('y_proba', None)
        
        if y_test is None or y_proba is None:
            logger.warning(f"Missing test data or probabilities for {model_name}")
            continue
        
        # Calculate Precision-Recall curve
        precision, recall, _ = precision_recall_curve(y_test, y_proba)
        ap = results.get('average_precision', average_precision_score(y_test, y_proba))
        
        # Plot Precision-Recall curve
        plt.plot(recall, precision, label=f'{model_name} (AP = {ap:.3f})')
    
    # Add random classifier reference line
    no_skill = np.sum(y_test) / len(y_test)
    plt.plot([0, 1], [no_skill, no_skill], 'k--', label=f'Random (AP = {no_skill:.3f})')
    
    # Add labels and legend
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('Precision-Recall Curves')
    plt.legend(loc='lower left')
    
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    
    return plt.gcf()

def feature_importance(model, feature_names, model_name="Model", top_n=20, figsize=(12, 8)):
    """
    Plot feature importance for a trained model.
    
    Parameters:
    -----------
    model : object
        Trained model with feature_importances_ attribute
    feature_names : list
        List of feature names
    model_name : str, optional
        Name of the model for plot title
    top_n : int, optional
        Number of top features to display
    figsize : tuple, optional
        Size of the figure
    
    Returns:
    --------
    matplotlib.figure.Figure
        The created figure
    """
    # Check if model has feature_importances_ attribute
    if not hasattr(model, 'feature_importances_'):
        logger.warning(f"{model_name} does not have feature_importances_ attribute")
        return None
    
    # Get feature importances
    importances = model.feature_importances_
    
    # Sort features by importance
    indices = np.argsort(importances)[-top_n:]
    
    # Create figure
    plt.figure(figsize=figsize)
    
    # Plot horizontal bar chart
    plt.barh(range(len(indices)), importances[indices])
    plt.yticks(range(len(indices)), [feature_names[i] for i in indices])
    plt.xlabel('Feature Importance')
    plt.title(f'Top {top_n} Feature Importances - {model_name}')
    plt.tight_layout()
    
    return plt.gcf()

def compare_models(model_results_list):
    """
    Compare multiple models based on their evaluation metrics.
    
    Parameters:
    -----------
    model_results_list : list of dict
        List of model evaluation result dictionaries
    
    Returns:
    --------
    pandas.DataFrame
        DataFrame with model comparison
    """
    logger.info("Comparing model performances...")
    
    # Extract relevant metrics for comparison
    comparison_data = []
    for results in model_results_list:
        comparison_data.append({
            'Model': results['model_name'],
            'Accuracy': results.get('accuracy', float('nan')),
            'Precision': results.get('precision', float('nan')),
            'Recall': results.get('recall', float('nan')),
            'F1-Score': results.get('f1', float('nan')),
            'ROC AUC': results.get('auc', float('nan')),
            'Avg Precision': results.get('average_precision', float('nan')),
            'TP': results.get('true_positives', float('nan')),
            'FP': results.get('false_positives', float('nan')),
            'TN': results.get('true_negatives', float('nan')),
            'FN': results.get('false_negatives', float('nan'))
        })
    
    # Create comparison DataFrame
    comparison_df = pd.DataFrame(comparison_data)
    
    # Sort by ROC AUC (or F1-Score if AUC not available)
    if 'ROC AUC' in comparison_df.columns and not comparison_df['ROC AUC'].isna().all():
        comparison_df = comparison_df.sort_values('ROC AUC', ascending=False)
    elif 'F1-Score' in comparison_df.columns:
        comparison_df = comparison_df.sort_values('F1-Score', ascending=False)
    
    return comparison_df

def save_model(model, model_path, feature_names=None, scaler=None):
    """
    Save a trained model and associated metadata.
    
    Parameters:
    -----------
    model : object
        Trained model to save
    model_path : str
        Path where the model should be saved
    feature_names : list, optional
        List of feature names used for training
    scaler : object, optional
        Fitted scaler used to preprocess the data
    
    Returns:
    --------
    bool
        True if successful, False otherwise
    """
    import joblib
    import os
    
    try:
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(model_path), exist_ok=True)
        
        # Prepare model metadata
        model_data = {
            'model': model,
            'feature_names': feature_names,
            'scaler': scaler,
            'timestamp': pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        # Save model with metadata
        joblib.dump(model_data, model_path)
        
        logger.info(f"Model saved to {model_path}")
        return True
    
    except Exception as e:
        logger.error(f"Error saving model: {str(e)}")
        return False

def load_model(model_path):
    """
    Load a saved model with its metadata.
    
    Parameters:
    -----------
    model_path : str
        Path to the saved model file
    
    Returns:
    --------
    dict
        Dictionary containing the model and associated metadata
    """
    import joblib
    
    try:
        # Load model data
        model_data = joblib.load(model_path)
        
        logger.info(f"Model loaded from {model_path}")
        return model_data
    
    except Exception as e:
        logger.error(f"Error loading model: {str(e)}")
        return None

if __name__ == "__main__":
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Example usage
    logger.info("This module provides supervised learning functions for fraud detection.")
    logger.info("Import and use these functions in your main script.") 