"""
Anomaly detection module for fraud detection in financial transactions.
This module implements various algorithms for detecting anomalies in transaction data.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import KMeans, DBSCAN
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.metrics import confusion_matrix, classification_report
import logging

# Set up logger
logger = logging.getLogger("fraud_detection.anomaly_detection")

def apply_kmeans(X, data, feature_names, n_clusters=3, threshold_percentile=95):
    """
    Apply K-means clustering for anomaly detection.
    
    Parameters:
    -----------
    X : numpy.ndarray
        Scaled feature matrix
    data : pandas.DataFrame
        Original DataFrame
    feature_names : list
        List of feature names used
    n_clusters : int, optional
        Number of clusters to form
    threshold_percentile : float, optional
        Percentile threshold for anomaly detection based on distance to centroid
    
    Returns:
    --------
    data : pandas.DataFrame
        DataFrame with added columns for K-means results
    potential_frauds : pandas.DataFrame
        Subset of data containing potential fraudulent transactions
    """
    logger.info(f"Applying K-means clustering with {n_clusters} clusters...")
    
    # Apply K-means
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    kmeans.fit(X)
    
    # Get cluster assignments
    data['KMeans_Cluster'] = kmeans.labels_
    
    # Calculate distance to centroids
    distances = []
    for i, sample in enumerate(X):
        cluster = kmeans.labels_[i]
        centroid = kmeans.cluster_centers_[cluster]
        distance = np.linalg.norm(sample - centroid)
        distances.append(distance)
    
    data['DistanceToCentroid'] = distances
    
    # Determine threshold for anomalies
    threshold = np.percentile(distances, threshold_percentile)
    data['KMeans_IsAnomaly'] = (data['DistanceToCentroid'] > threshold).astype(int)
    data['KMeans_AnomalyLabel'] = data['KMeans_IsAnomaly'].map({0: 'Normal', 1: 'Potential Fraud'})
    
    # Identify potential frauds
    potential_frauds = data[data['KMeans_IsAnomaly'] == 1].copy()
    
    logger.info(f"K-means detected {len(potential_frauds)} potential frauds ({len(potential_frauds)/len(data):.2%} of transactions)")
    
    return data, potential_frauds

def apply_dbscan(X, data, feature_names, eps=0.5, min_samples=5):
    """
    Apply DBSCAN clustering for anomaly detection.
    
    Parameters:
    -----------
    X : numpy.ndarray
        Scaled feature matrix
    data : pandas.DataFrame
        Original DataFrame
    feature_names : list
        List of feature names used
    eps : float, optional
        The maximum distance between two samples for one to be considered 
        as in the neighborhood of the other
    min_samples : int, optional
        The number of samples in a neighborhood for a point to be considered as a core point
    
    Returns:
    --------
    data : pandas.DataFrame
        DataFrame with added columns for DBSCAN results
    potential_frauds : pandas.DataFrame
        Subset of data containing potential fraudulent transactions
    """
    logger.info(f"Applying DBSCAN with eps={eps}, min_samples={min_samples}...")
    
    # Apply DBSCAN
    dbscan = DBSCAN(eps=eps, min_samples=min_samples)
    dbscan.fit(X)
    
    # Get cluster assignments (cluster -1 represents outliers)
    data['DBSCAN_Cluster'] = dbscan.labels_
    
    # Identify anomalies (outliers)
    data['DBSCAN_IsAnomaly'] = (data['DBSCAN_Cluster'] == -1).astype(int)
    data['DBSCAN_AnomalyLabel'] = data['DBSCAN_IsAnomaly'].map({0: 'Normal', 1: 'Potential Fraud'})
    
    # Identify potential frauds
    potential_frauds = data[data['DBSCAN_IsAnomaly'] == 1].copy()
    
    logger.info(f"DBSCAN detected {len(potential_frauds)} potential frauds ({len(potential_frauds)/len(data):.2%} of transactions)")
    
    return data, potential_frauds

def apply_isolation_forest(X, data, feature_names, contamination=0.05, n_estimators=100):
    """
    Apply Isolation Forest for anomaly detection.
    
    Parameters:
    -----------
    X : numpy.ndarray
        Scaled feature matrix
    data : pandas.DataFrame
        Original DataFrame
    feature_names : list
        List of feature names used
    contamination : float, optional
        The expected proportion of outliers in the data
    n_estimators : int, optional
        The number of base estimators in the ensemble
    
    Returns:
    --------
    data : pandas.DataFrame
        DataFrame with added columns for anomaly score and prediction
    potential_frauds : pandas.DataFrame
        Subset of data containing potential fraudulent transactions
    """
    logger.info(f"Applying Isolation Forest with contamination={contamination}...")
    
    # Define outlier mapping
    outlier_mapping = {1: 'Normal', -1: 'Potential Fraud'}
    
    # Apply Isolation Forest
    iso_forest = IsolationForest(
        n_estimators=n_estimators, 
        contamination=contamination,
        random_state=42
    )
    iso_forest.fit(X)
    
    # Add results to DataFrame
    data['IF_AnomalyScore'] = iso_forest.decision_function(X)
    data['IF_IsAnomaly'] = iso_forest.predict(X)
    data['IF_AnomalyLabel'] = data['IF_IsAnomaly'].map(outlier_mapping)
    
    # Identify potential frauds
    potential_frauds = data[data['IF_IsAnomaly'] == -1].copy()
    
    logger.info(f"Isolation Forest detected {len(potential_frauds)} potential frauds ({len(potential_frauds)/len(data):.2%} of transactions)")
    
    return data, potential_frauds, iso_forest

def apply_local_outlier_factor(X, data, feature_names, n_neighbors=20, contamination=0.05):
    """
    Apply Local Outlier Factor for anomaly detection.
    
    Parameters:
    -----------
    X : numpy.ndarray
        Scaled feature matrix
    data : pandas.DataFrame
        Original DataFrame
    feature_names : list
        List of feature names used
    n_neighbors : int, optional
        Number of neighbors to use
    contamination : float, optional
        The expected proportion of outliers in the data
    
    Returns:
    --------
    data : pandas.DataFrame
        DataFrame with added columns for LOF score and prediction
    potential_frauds : pandas.DataFrame
        Subset of data containing potential fraudulent transactions
    """
    logger.info(f"Applying Local Outlier Factor with contamination={contamination}...")
    
    # Define outlier mapping
    outlier_mapping = {1: 'Normal', -1: 'Potential Fraud'}
    
    # Apply LOF
    lof = LocalOutlierFactor(
        n_neighbors=n_neighbors,
        contamination=contamination
    )
    
    # Predict anomalies
    y_pred = lof.fit_predict(X)
    
    # Calculate negative outlier factor (higher = more likely to be an outlier)
    # Note: We negate to make it consistent with other scores (higher = more anomalous)
    negative_lof = -lof.negative_outlier_factor_
    
    # Add results to DataFrame
    data['LOF_Score'] = negative_lof
    data['LOF_IsAnomaly'] = y_pred
    data['LOF_AnomalyLabel'] = data['LOF_IsAnomaly'].map(outlier_mapping)
    
    # Identify potential frauds
    potential_frauds = data[data['LOF_IsAnomaly'] == -1].copy()
    
    logger.info(f"LOF detected {len(potential_frauds)} potential frauds ({len(potential_frauds)/len(data):.2%} of transactions)")
    
    return data, potential_frauds

def get_ensemble_predictions(data, weight_kmeans=1, weight_dbscan=1, weight_iforest=1.5, weight_lof=1, threshold=0.6):
    """
    Create an ensemble of anomaly detection methods.
    
    Parameters:
    -----------
    data : pandas.DataFrame
        DataFrame containing results from multiple anomaly detection methods
    weight_kmeans : float, optional
        Weight for K-means results
    weight_dbscan : float, optional
        Weight for DBSCAN results
    weight_iforest : float, optional
        Weight for Isolation Forest results
    weight_lof : float, optional
        Weight for LOF results
    threshold : float, optional
        Threshold for the weighted score to consider a transaction as fraudulent
    
    Returns:
    --------
    data : pandas.DataFrame
        DataFrame with added columns for ensemble score and prediction
    potential_frauds : pandas.DataFrame
        Subset of data containing potential fraudulent transactions
    """
    logger.info("Creating ensemble predictions...")
    
    # Initialize score
    data['Ensemble_Score'] = 0
    
    # Add K-means contribution
    if 'DistanceToCentroid' in data.columns:
        # Normalize scores to 0-1 range
        max_dist = data['DistanceToCentroid'].max()
        if max_dist > 0:
            data['Ensemble_Score'] += weight_kmeans * (data['DistanceToCentroid'] / max_dist)
    
    # Add DBSCAN contribution
    if 'DBSCAN_Cluster' in data.columns:
        # Convert to binary (1 for outliers, 0 for inliers)
        data['Ensemble_Score'] += weight_dbscan * (data['DBSCAN_Cluster'] == -1).astype(int)
    
    # Add Isolation Forest contribution
    if 'IF_AnomalyScore' in data.columns:
        # Normalize scores to 0-1 range (original scores are in range [-0.5, 0.5] approx)
        min_score = data['IF_AnomalyScore'].min()
        max_score = data['IF_AnomalyScore'].max()
        if max_score > min_score:
            normalized_score = (data['IF_AnomalyScore'] - min_score) / (max_score - min_score)
            # Invert so higher score = more anomalous
            data['Ensemble_Score'] += weight_iforest * (1 - normalized_score)
    
    # Add LOF contribution
    if 'LOF_Score' in data.columns:
        # Normalize scores to 0-1 range
        min_score = data['LOF_Score'].min()
        max_score = data['LOF_Score'].max()
        if max_score > min_score:
            data['Ensemble_Score'] += weight_lof * ((data['LOF_Score'] - min_score) / (max_score - min_score))
    
    # Normalize final score
    total_weight = weight_kmeans + weight_dbscan + weight_iforest + weight_lof
    if total_weight > 0:
        data['Ensemble_Score'] = data['Ensemble_Score'] / total_weight
    
    # Make prediction
    data['Ensemble_Prediction'] = (data['Ensemble_Score'] >= threshold).astype(int)
    data['Ensemble_Label'] = data['Ensemble_Prediction'].map({0: 'Normal', 1: 'Potential Fraud'})
    
    # Get potential frauds
    potential_frauds = data[data['Ensemble_Prediction'] == 1].copy()
    
    logger.info(f"Ensemble method detected {len(potential_frauds)} potential frauds ({len(potential_frauds)/len(data):.2%} of transactions)")
    
    return data, potential_frauds

def compare_methods(data, kmeans_frauds, dbscan_frauds, iforest_frauds, lof_frauds, ensemble_frauds):
    """
    Compare the results of different anomaly detection methods.
    
    Parameters:
    -----------
    data : pandas.DataFrame
        DataFrame containing all transactions
    kmeans_frauds : pandas.DataFrame
        Potential frauds detected by K-means
    dbscan_frauds : pandas.DataFrame
        Potential frauds detected by DBSCAN
    iforest_frauds : pandas.DataFrame
        Potential frauds detected by Isolation Forest
    lof_frauds : pandas.DataFrame
        Potential frauds detected by Local Outlier Factor
    ensemble_frauds : pandas.DataFrame
        Potential frauds detected by the ensemble method
    
    Returns:
    --------
    pandas.DataFrame
        Comparison summary of different methods
    """
    logger.info("Comparing anomaly detection methods...")
    
    # Get transaction IDs for each method
    if 'TransactionID' in data.columns:
        id_field = 'TransactionID'
        
        # Ensure all fraud DataFrames have the ID field
        for df_name, df in [('kmeans_frauds', kmeans_frauds), 
                           ('dbscan_frauds', dbscan_frauds),
                           ('iforest_frauds', iforest_frauds),
                           ('lof_frauds', lof_frauds),
                           ('ensemble_frauds', ensemble_frauds)]:
            if len(df) > 0 and id_field not in df.columns:
                logger.warning(f"{id_field} not found in {df_name}. Using index.")
    else:
        # No TransactionID column, use the index
        id_field = 'index'
        
        # Make sure all DataFrames have the index as a column
        data = data.reset_index().rename(columns={'index': id_field})
        
        # Reset index for all fraud DataFrames
        kmeans_frauds = kmeans_frauds.reset_index() if len(kmeans_frauds) > 0 else kmeans_frauds
        dbscan_frauds = dbscan_frauds.reset_index() if len(dbscan_frauds) > 0 else dbscan_frauds
        iforest_frauds = iforest_frauds.reset_index() if len(iforest_frauds) > 0 else iforest_frauds
        lof_frauds = lof_frauds.reset_index() if len(lof_frauds) > 0 else lof_frauds
        ensemble_frauds = ensemble_frauds.reset_index() if len(ensemble_frauds) > 0 else ensemble_frauds
    
    # Get sets of fraud IDs for each method
    # Use a try-except block to handle potential issues with different DataFrames
    def get_fraud_ids(df, field):
        if len(df) == 0:
            return set()
        
        try:
            if field in df.columns:
                return set(df[field])
            elif field == 'index' and 'index' not in df.columns:
                # If 'index' is not in columns but we need it, use the DataFrame index
                return set(df.index)
            else:
                logger.warning(f"Field {field} not found in fraud DataFrame. Using empty set.")
                return set()
        except Exception as e:
            logger.error(f"Error getting fraud IDs: {e}")
            return set()
    
    kmeans_ids = get_fraud_ids(kmeans_frauds, id_field)
    dbscan_ids = get_fraud_ids(dbscan_frauds, id_field)
    iforest_ids = get_fraud_ids(iforest_frauds, id_field)
    lof_ids = get_fraud_ids(lof_frauds, id_field)
    ensemble_ids = get_fraud_ids(ensemble_frauds, id_field)
    
    # Create comparison summary
    comparison = pd.DataFrame({
        'Method': ['K-means', 'DBSCAN', 'Isolation Forest', 'LOF', 'Ensemble'],
        'Detected Frauds': [
            len(kmeans_frauds), 
            len(dbscan_frauds), 
            len(iforest_frauds), 
            len(lof_frauds),
            len(ensemble_frauds)
        ],
        'Percentage': [
            f"{len(kmeans_frauds)/len(data):.2%}" if len(data) > 0 else '0%',
            f"{len(dbscan_frauds)/len(data):.2%}" if len(data) > 0 else '0%',
            f"{len(iforest_frauds)/len(data):.2%}" if len(data) > 0 else '0%',
            f"{len(lof_frauds)/len(data):.2%}" if len(data) > 0 else '0%',
            f"{len(ensemble_frauds)/len(data):.2%}" if len(data) > 0 else '0%'
        ]
    })
    
    # Calculate overlap with ensemble method
    comparison['Overlap with Ensemble'] = [
        f"{len(kmeans_ids.intersection(ensemble_ids))/len(ensemble_ids):.2%}" if len(ensemble_ids) > 0 else '0%',
        f"{len(dbscan_ids.intersection(ensemble_ids))/len(ensemble_ids):.2%}" if len(ensemble_ids) > 0 else '0%',
        f"{len(iforest_ids.intersection(ensemble_ids))/len(ensemble_ids):.2%}" if len(ensemble_ids) > 0 else '0%',
        f"{len(lof_ids.intersection(ensemble_ids))/len(ensemble_ids):.2%}" if len(ensemble_ids) > 0 else '0%',
        '100%'
    ]
    
    logger.info("Method comparison complete")
    return comparison

def plot_anomalies(data, feature_x, feature_y, method='Ensemble', figsize=(12, 6)):
    """
    Create a scatter plot visualizing the anomalies detected by a specific method.
    
    Parameters:
    -----------
    data : pandas.DataFrame
        DataFrame containing transaction data with anomaly detection results
    feature_x : str
        Name of the feature to plot on x-axis
    feature_y : str
        Name of the feature to plot on y-axis
    method : str, optional
        The anomaly detection method to visualize
        ('KMeans', 'DBSCAN', 'IF', 'LOF', or 'Ensemble')
    figsize : tuple, optional
        Size of the figure
    
    Returns:
    --------
    matplotlib.figure.Figure
        The created figure
    """
    # Set method-specific columns
    if method == 'KMeans':
        is_anomaly_col = 'KMeans_IsAnomaly'
        label_col = 'KMeans_AnomalyLabel'
    elif method == 'DBSCAN':
        is_anomaly_col = 'DBSCAN_IsAnomaly'
        label_col = 'DBSCAN_AnomalyLabel'
    elif method == 'IF':
        is_anomaly_col = 'IF_IsAnomaly'
        label_col = 'IF_AnomalyLabel'
    elif method == 'LOF':
        is_anomaly_col = 'LOF_IsAnomaly'
        label_col = 'LOF_AnomalyLabel'
    else:  # Ensemble is default
        is_anomaly_col = 'Ensemble_Prediction'
        label_col = 'Ensemble_Label'
    
    # Check if columns exist
    if is_anomaly_col not in data.columns or feature_x not in data.columns or feature_y not in data.columns:
        logger.error(f"Required columns not found: {is_anomaly_col}, {feature_x}, or {feature_y}")
        return None
    
    # Create figure
    fig, ax = plt.subplots(figsize=figsize)
    
    # Plot normal transactions
    normal = data[data[is_anomaly_col] == 0]
    ax.scatter(
        normal[feature_x], normal[feature_y], 
        c='blue', label='Normal', alpha=0.5, s=30
    )
    
    # Plot anomalies
    anomalies = data[data[is_anomaly_col] == 1]
    ax.scatter(
        anomalies[feature_x], anomalies[feature_y], 
        c='red', label='Potential Fraud', alpha=0.7, s=50, marker='X'
    )
    
    # Add labels and title
    ax.set_xlabel(feature_x)
    ax.set_ylabel(feature_y)
    ax.set_title(f'Anomaly Detection: {method}')
    ax.legend()
    plt.tight_layout()
    
    return fig

def generate_fraud_report(data, potential_frauds, output_dir=None):
    """
    Generate a report of potential fraudulent transactions.
    
    Parameters:
    -----------
    data : pandas.DataFrame
        Full DataFrame with all transactions
    potential_frauds : pandas.DataFrame
        DataFrame containing potential fraudulent transactions
    output_dir : str, optional
        Directory to save the report, if None, report is not saved
    
    Returns:
    --------
    dict
        Dictionary containing report metrics
    """
    logger.info("Generating fraud detection report...")
    
    report = {}
    report['total_transactions'] = len(data)
    report['potential_frauds'] = len(potential_frauds)
    report['fraud_percentage'] = len(potential_frauds) / len(data) if len(data) > 0 else 0
    
    # Display summary statistics for potential frauds
    if len(potential_frauds) > 0:
        # Transaction Amount
        if 'Amount' in potential_frauds.columns:
            fraud_avg = potential_frauds['Amount'].mean()
            normal_avg = data[~data.index.isin(potential_frauds.index)]['Amount'].mean()
            report['avg_amount_fraud'] = fraud_avg
            report['avg_amount_normal'] = normal_avg
            report['amount_difference_percent'] = (fraud_avg / normal_avg - 1) if normal_avg > 0 else float('inf')
        
        # Transaction Types
        if 'TransactionType' in potential_frauds.columns:
            fraud_types = potential_frauds['TransactionType'].value_counts(normalize=True) * 100
            normal_types = data[~data.index.isin(potential_frauds.index)]['TransactionType'].value_counts(normalize=True) * 100
            report['fraud_transaction_types'] = fraud_types.to_dict()
            report['normal_transaction_types'] = normal_types.to_dict()
        
        # Timestamps
        if 'TransactionDateTime' in potential_frauds.columns:
            # Time of day analysis
            potential_frauds['Hour'] = potential_frauds['TransactionDateTime'].dt.hour
            hour_dist = potential_frauds['Hour'].value_counts(normalize=True) * 100
            report['fraud_hour_distribution'] = hour_dist.to_dict()
            
            # Day of week analysis
            potential_frauds['DayOfWeek'] = potential_frauds['TransactionDateTime'].dt.dayofweek
            day_dist = potential_frauds['DayOfWeek'].value_counts(normalize=True) * 100
            report['fraud_day_distribution'] = day_dist.to_dict()
    
    # Save report to file if output_dir is provided
    if output_dir is not None:
        import os
        import json
        
        # Create directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)
        
        # Save potential frauds to CSV
        output_file_csv = os.path.join(output_dir, 'potential_frauds.csv')
        potential_frauds.to_csv(output_file_csv, index=False)
        
        # Save report to JSON
        output_file_json = os.path.join(output_dir, 'fraud_report.json')
        
        # Convert any non-serializable objects to strings
        serializable_report = {}
        for k, v in report.items():
            if isinstance(v, dict):
                serializable_report[k] = {str(dk): float(dv) for dk, dv in v.items()}
            elif hasattr(v, '__iter__') and not isinstance(v, (str, dict)):
                serializable_report[k] = list(v)
            else:
                serializable_report[k] = v
        
        with open(output_file_json, 'w') as f:
            json.dump(serializable_report, f, indent=4)
        
        logger.info(f"Fraud report saved to {output_dir}")
    
    return report

def evaluate_model(y_true, y_pred, method_name="Model"):
    """
    Evaluate an anomaly detection model if labeled data is available.
    
    Parameters:
    -----------
    y_true : array-like
        True labels (1 for fraud, 0 for normal)
    y_pred : array-like
        Predicted labels (1 for fraud, 0 for normal)
    method_name : str, optional
        Name of the method being evaluated
    
    Returns:
    --------
    dict
        Dictionary containing evaluation metrics
    """
    # Calculate confusion matrix
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    
    # Calculate metrics
    accuracy = (tp + tn) / (tp + tn + fp + fn)
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
    
    # Print report
    logger.info(f"\nEvaluation Results for {method_name}:")
    logger.info(f"Accuracy: {accuracy:.4f}")
    logger.info(f"Precision: {precision:.4f}")
    logger.info(f"Recall: {recall:.4f}")
    logger.info(f"F1-Score: {f1:.4f}")
    
    # Detailed classification report
    report = classification_report(y_true, y_pred, target_names=['Normal', 'Fraud'])
    logger.info(f"\nClassification Report:\n{report}")
    
    # Return metrics
    return {
        'method': method_name,
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1': f1,
        'true_negatives': tn,
        'false_positives': fp,
        'false_negatives': fn,
        'true_positives': tp
    }

if __name__ == "__main__":
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Example usage
    logger.info("This module provides anomaly detection functions for fraud detection.")
    logger.info("Import and use these functions in your main script.") 