"""
Visualization utilities for the fraud detection system.
"""
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import pandas as pd
import seaborn as sns
import yaml
import os

# Load configuration
def load_config():
    """Load configuration from config file"""
    config_path = os.path.join(os.path.dirname(__file__), 
                             '../config/config.yaml')
    with open(config_path, 'r') as file:
        config = yaml.safe_load(file)
    return config

# Set default visualization parameters from config
try:
    config = load_config()
    _default_style = config['visualization']['style']
    _default_palette = config['visualization']['color_palette']
    _default_figsize = tuple(config['visualization']['figsize'])
except Exception:
    # Fallback defaults if config can't be loaded
    _default_style = 'whitegrid'
    _default_palette = 'YlOrBr'
    _default_figsize = (12, 8)

def set_plot_style(style=None, palette=None):
    """
    Set the plot style and color palette.
    
    Parameters:
    -----------
    style : str, optional
        Seaborn style name (default from config)
    palette : str, optional
        Seaborn color palette name (default from config)
    """
    sns.set_style(style or _default_style)
    if palette:
        sns.set_palette(palette)
    else:
        sns.set_palette(_default_palette)

def plot_distribution(data, column, figsize=None, bins=20, kde=True, title=None):
    """
    Plot the distribution of a numeric column.
    
    Parameters:
    -----------
    data : pandas.DataFrame
        DataFrame containing the data
    column : str
        Column name to plot
    figsize : tuple, optional
        Figure size (width, height) in inches
    bins : int, optional
        Number of bins for the histogram
    kde : bool, optional
        Whether to plot a kernel density estimate
    title : str, optional
        Plot title. If None, a default title will be used.
    """
    plt.figure(figsize=figsize or _default_figsize)
    
    # Use custom palette
    custom_palette = sns.color_palette(_default_palette, 3)
    
    # Plot distribution
    ax = sns.histplot(data[column], bins=bins, kde=kde, color=custom_palette[1])
    
    # Set title and labels
    plt.title(title or f'Distribution of {column}')
    plt.xlabel(column)
    plt.ylabel('Frequency')
    
    # Add grid
    plt.grid(axis='y', color='gray', linestyle='--', linewidth=0.7)
    
    # Add statistics annotation
    stats_text = (f'Mean: {data[column].mean():.2f}\n'
                 f'Median: {data[column].median():.2f}\n'
                 f'Std Dev: {data[column].std():.2f}')
    
    # Calculate text position (upper right)
    props = dict(boxstyle='round', facecolor='white', alpha=0.7)
    plt.annotate(stats_text, xy=(0.95, 0.95), xycoords='axes fraction',
                fontsize=10, verticalalignment='top', horizontalalignment='right',
                bbox=props)
    
    plt.tight_layout()
    return ax

def plot_categorical(data, column, figsize=None, title=None):
    """
    Plot the distribution of a categorical column using a bar chart and a pie chart.
    
    Parameters:
    -----------
    data : pandas.DataFrame
        DataFrame containing the data
    column : str
        Column name to plot
    figsize : tuple, optional
        Figure size (width, height) in inches
    title : str, optional
        Plot title. If None, a default title will be used.
    """
    plt.figure(figsize=figsize or (12, 5))
    
    # Calculate value counts
    cat_counts = data[column].value_counts()
    
    # Create subplots
    plt.subplot(1, 2, 1)
    sns.barplot(x=cat_counts.index, y=cat_counts.values, palette=_default_palette)
    plt.title(title or f'Count of {column}')
    plt.xlabel(column)
    plt.ylabel('Count')
    plt.xticks(rotation=45)
    plt.grid(axis='y', color='gray', linestyle='--', linewidth=0.7)
    
    # Pie chart
    plt.subplot(1, 2, 2)
    plt.pie(cat_counts, labels=cat_counts.index, autopct='%1.1f%%', 
            startangle=90, colors=sns.color_palette(_default_palette, len(cat_counts)))
    plt.title(f'Percentage of {column}')
    plt.axis('equal')
    
    plt.tight_layout()

def plot_correlation_matrix(data, columns=None, figsize=None, title=None):
    """
    Plot a correlation matrix for numerical columns.
    
    Parameters:
    -----------
    data : pandas.DataFrame
        DataFrame containing the data
    columns : list, optional
        List of column names to include. If None, all numeric columns will be used.
    figsize : tuple, optional
        Figure size (width, height) in inches
    title : str, optional
        Plot title. If None, a default title will be used.
    """
    # Select columns
    if columns is None:
        columns = data.select_dtypes(include=['int64', 'float64']).columns
    
    # Calculate correlation matrix
    correlation_matrix = data[columns].corr()
    
    # Plot heatmap
    plt.figure(figsize=figsize or _default_figsize)
    sns.heatmap(correlation_matrix, annot=True, cmap=_default_palette, fmt=".2f")
    plt.title(title or 'Correlation Matrix for Numerical Features')
    plt.tight_layout()

def plot_anomalies(X_scaled, labels, features, method_name="Anomaly Detection", figsize=None):
    """
    Plot the results of anomaly detection in 2D.
    
    Parameters:
    -----------
    X_scaled : numpy.ndarray
        Scaled feature matrix (should be at least 2D)
    labels : numpy.ndarray
        Binary array where 1 indicates anomaly, 0 indicates normal
    features : list
        Names of the features used for anomaly detection
    method_name : str, optional
        Name of the anomaly detection method
    figsize : tuple, optional
        Figure size (width, height) in inches
    """
    if X_scaled.shape[1] < 2:
        raise ValueError("At least 2 features are required for 2D visualization")
    
    plt.figure(figsize=figsize or _default_figsize)
    
    # Create colormap
    cmap = plt.get_cmap(_default_palette)
    colors = np.array([cmap(0.9) if label == 1 else cmap(0.3) for label in labels])
    
    # Scatter plot
    plt.scatter(
        X_scaled[:, 0], X_scaled[:, 1],
        c=colors, alpha=0.7, edgecolors='k',
        s=50
    )
    
    # Create legend
    normal_patch = mpatches.Patch(color=cmap(0.3), label='Normal')
    fraud_patch = mpatches.Patch(color=cmap(0.9), label='Potential Fraud')
    plt.legend(handles=[normal_patch, fraud_patch], title='Prediction')
    
    plt.xlabel(features[0])
    plt.ylabel(features[1])
    plt.title(f'{method_name} Results for Fraud Detection')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()

def plot_anomaly_scores(anomaly_scores, threshold, method_name="Anomaly Detection", figsize=None):
    """
    Plot the distribution of anomaly scores with a threshold line.
    
    Parameters:
    -----------
    anomaly_scores : numpy.ndarray
        Array of anomaly scores
    threshold : float
        Threshold value for classifying anomalies
    method_name : str, optional
        Name of the anomaly detection method
    figsize : tuple, optional
        Figure size (width, height) in inches
    """
    plt.figure(figsize=figsize or _default_figsize)
    
    # Use custom palette
    custom_palette = sns.color_palette(_default_palette, 3)
    
    # Plot distribution
    sns.histplot(anomaly_scores, bins=30, kde=True, color=custom_palette[1])
    
    # Add threshold line
    plt.axvline(threshold, color='red', linestyle='--', 
                label=f'Threshold: {threshold:.2f}')
    
    # Set title and labels
    plt.title(f'Distribution of {method_name} Scores')
    plt.xlabel('Anomaly Score')
    plt.ylabel('Frequency')
    plt.legend()
    
    # Add grid
    plt.grid(axis='y', color='gray', linestyle='--', linewidth=0.7)
    plt.tight_layout()

def plot_feature_importance(feature_names, importance_scores, method_name="Feature Importance", figsize=None):
    """
    Plot feature importance scores.
    
    Parameters:
    -----------
    feature_names : list
        Names of the features
    importance_scores : numpy.ndarray
        Array of importance scores
    method_name : str, optional
        Name of the method used to calculate feature importance
    figsize : tuple, optional
        Figure size (width, height) in inches
    """
    # Create DataFrame for plotting
    importance_df = pd.DataFrame({
        'Feature': feature_names,
        'Importance': importance_scores
    })
    
    # Sort by importance
    importance_df = importance_df.sort_values('Importance', ascending=False)
    
    # Plot
    plt.figure(figsize=figsize or _default_figsize)
    sns.barplot(x='Importance', y='Feature', data=importance_df, palette=_default_palette)
    plt.title(f'{method_name}')
    plt.xlabel('Importance Score')
    plt.ylabel('Feature')
    plt.grid(axis='x', color='gray', linestyle='--', linewidth=0.7)
    plt.tight_layout()

if __name__ == "__main__":
    # Example usage
    import numpy as np
    
    # Set plot style
    set_plot_style()
    
    # Generate sample data
    np.random.seed(42)
    n_samples = 1000
    data = pd.DataFrame({
        'Amount': np.random.lognormal(5, 1, n_samples),
        'Duration': np.random.normal(100, 30, n_samples),
        'Age': np.random.randint(18, 80, n_samples),
        'Type': np.random.choice(['Credit', 'Debit'], n_samples, p=[0.3, 0.7])
    })
    
    # Plot distribution
    plot_distribution(data, 'Amount')
    
    # Plot categorical
    plot_categorical(data, 'Type')
    
    # Plot correlation matrix
    plot_correlation_matrix(data)
    
    # Plot anomalies
    X = data[['Amount', 'Duration']].values
    # Generate random anomalies (5% of data)
    anomalies = np.zeros(n_samples)
    anomalies[np.random.choice(n_samples, n_samples // 20)] = 1
    plot_anomalies(X, anomalies, ['Amount', 'Duration'], "Random")
    
    plt.show() 