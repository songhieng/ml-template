"""
Utility functions and helpers
""" 