"""
Logger module for the fraud detection system.
"""
import logging
import os
import sys
from datetime import datetime

def setup_logger(log_level=logging.INFO, log_file=None):
    """
    Set up a logger for the application.
    
    Parameters:
    -----------
    log_level : int, optional
        Logging level (default: logging.INFO)
    log_file : str, optional
        Path to log file. If None, logs will be written to console only.
    
    Returns:
    --------
    logger : logging.Logger
        Configured logger instance
    """
    # Create logger
    logger = logging.getLogger('fraud_detection')
    logger.setLevel(log_level)
    
    # Create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Create console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # Create file handler if log_file is provided
    if log_file:
        # Create log directory if it doesn't exist
        log_dir = os.path.dirname(log_file)
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir)
            
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    return logger

def get_default_logger():
    """
    Get a default logger with a timestamp-based log file name.
    
    Returns:
    --------
    logger : logging.Logger
        Default logger instance
    """
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = f"logs/fraud_detection_{timestamp}.log"
    return setup_logger(log_file=log_file)

if __name__ == "__main__":
    # Example usage
    logger = get_default_logger()
    logger.info("Logger initialized successfully")
    logger.warning("This is a warning message")
    logger.error("This is an error message")
    logger.debug("This is a debug message (won't be shown with default INFO level)") 