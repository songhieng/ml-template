"""
Configuration utilities for the fraud detection system.
"""
import os
import yaml

def load_config():
    """
    Load configuration from config file
    
    Returns:
    --------
    dict:
        The configuration dictionary
    """
    # Find the config file path
    config_path = os.path.join(os.path.dirname(__file__), 
                               '../config/config.yaml')
    
    # Load the configuration
    with open(config_path, 'r') as file:
        config = yaml.safe_load(file)
    
    return config 