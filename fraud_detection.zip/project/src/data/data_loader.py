"""
Data loading and preprocessing utilities for the fraud detection system.
"""
import os
import pandas as pd
import numpy as np
import yaml
from datetime import datetime, timedelta
import random
from sklearn.preprocessing import StandardScaler
import logging

# Set up logger
logger = logging.getLogger("fraud_detection.data_loader")

def load_config():
    """Load configuration from config file"""
    config_path = os.path.join(os.path.dirname(__file__), 
                             '../config/config.yaml')
    with open(config_path, 'r') as file:
        config = yaml.safe_load(file)
    return config

def load_data(filepath=None):
    """
    Load transaction data from CSV file or generate sample data if not available.
    
    Parameters:
    -----------
    filepath : str, optional
        Path to the CSV file. If None, the path from config file will be used.
        
    Returns:
    --------
    pandas.DataFrame
        DataFrame containing transaction data
    """
    config = load_config()
    
    # Use provided filepath or get from config
    if filepath is None:
        filepath = config['paths']['raw_data']
    
    # Full path handling
    if not os.path.isabs(filepath):
        filepath = os.path.join(os.path.dirname(__file__), '../..', filepath)
    
    logger.info(f"Attempting to load data from: {filepath}")
    
    try:
        # Try to load the file
        data = pd.read_csv(filepath)
        logger.info(f"Successfully loaded data with {len(data)} rows")
        return data
    except FileNotFoundError:
        logger.warning(f"File not found: {filepath}")
        logger.info("Generating sample transaction data")
        return generate_sample_data(config['preprocessing']['sample_size'])

def generate_sample_data(n_samples=1000):
    """
    Generate sample transaction data for testing.
    
    Parameters:
    -----------
    n_samples : int, optional
        Number of sample transactions to generate
        
    Returns:
    --------
    pandas.DataFrame
        DataFrame containing sample transaction data
    """
    logger.info(f"Generating {n_samples} sample transactions")
    
    # Set random seed for reproducibility
    np.random.seed(42)
    random.seed(42)
    
    # Create current date for reference
    current_date = datetime.now()
    
    # Transaction types
    transaction_types = ['Deposit', 'Withdrawal', 'Payment', 'Transfer']
    merchants = ['Online Store', 'Supermarket', 'Restaurant', 'Gas Station', 
                'Clothing Store', 'Electronics Store', 'Utility Bill', None]
    
    # Customer IDs
    customer_ids = np.random.randint(10000, 99999, n_samples)
    
    # Generate data
    data = {
        'TransactionID': range(1, n_samples + 1),
        'CustomerID': customer_ids,
        'TransactionDate': [
            (current_date - timedelta(days=random.randint(0, 365))).strftime('%Y-%m-%d')
            for _ in range(n_samples)
        ],
        'TransactionTime': [
            f"{random.randint(0, 23):02d}:{random.randint(0, 59):02d}:{random.randint(0, 59):02d}"
            for _ in range(n_samples)
        ],
        'TransactionType': np.random.choice(transaction_types, n_samples),
        'Amount': np.random.lognormal(4, 1, n_samples),  # Log-normal distribution for amounts
        'Location': [f"Location-{random.randint(1, 20)}" for _ in range(n_samples)],
        'MerchantName': np.random.choice(merchants, n_samples, p=[0.2, 0.2, 0.15, 0.15, 0.1, 0.1, 0.05, 0.05])
    }
    
    # Introduce a small number of anomalies/fraud
    # 5% of transactions will have unusual characteristics
    fraud_indices = np.random.choice(n_samples, int(n_samples * 0.05), replace=False)
    
    # Unusual amounts for fraudulent transactions
    for idx in fraud_indices:
        if idx % 3 == 0:
            # Very large transaction
            data['Amount'][idx] = np.random.uniform(5000, 10000)
        elif idx % 3 == 1:
            # Multiple transactions of the same amount
            amount = data['Amount'][idx]
            similar_indices = np.random.choice(
                [i for i in range(n_samples) if i != idx], 
                min(5, n_samples//100), 
                replace=False
            )
            for sim_idx in similar_indices:
                data['Amount'][sim_idx] = amount
                data['TransactionDate'][sim_idx] = data['TransactionDate'][idx]
    
    # Create DataFrame
    df = pd.DataFrame(data)
    
    # Add previous transaction date (for features)
    # Group by customer and sort by date
    df['TransactionDateTime'] = pd.to_datetime(
        df['TransactionDate'] + ' ' + df['TransactionTime']
    )
    
    # Sort by customer and date
    df = df.sort_values(['CustomerID', 'TransactionDateTime'])
    
    # Calculate previous transaction date
    df['PreviousTransactionDate'] = df.groupby('CustomerID')['TransactionDateTime'].shift(1)
    
    # Calculate time since last transaction
    df['TimeSinceLastTransaction'] = (
        df['TransactionDateTime'] - df['PreviousTransactionDate']
    ).dt.total_seconds() / 3600  # Convert to hours
    
    # Fill NaN values for first transactions
    df['TimeSinceLastTransaction'].fillna(24 * 30, inplace=True)  # Set to 30 days for first transaction
    
    # Reset the index
    df.reset_index(drop=True, inplace=True)
    
    logger.info(f"Generated sample data with {len(df)} rows")
    return df

def preprocess_data(data, config=None):
    """
    Preprocess transaction data.
    
    Parameters:
    -----------
    data : pandas.DataFrame
        Raw transaction data
    config : dict, optional
        Configuration parameters. If None, load from config file.
        
    Returns:
    --------
    pandas.DataFrame
        Preprocessed transaction data
    """
    if config is None:
        config = load_config()
    
    logger.info("Starting data preprocessing")
    
    # Make a copy to avoid modifying the original
    df = data.copy()
    
    # Convert date columns to datetime
    if 'TransactionDate' in df.columns and not pd.api.types.is_datetime64_any_dtype(df['TransactionDate']):
        df['TransactionDate'] = pd.to_datetime(df['TransactionDate'])
    
    if ('TransactionDate' in df.columns and 'TransactionTime' in df.columns and 
        'TransactionDateTime' not in df.columns):
        # Combine date and time if they're separate
        df['TransactionDateTime'] = pd.to_datetime(
            df['TransactionDate'].astype(str) + ' ' + df['TransactionTime'].astype(str),
            errors='coerce'
        )
    
    if 'PreviousTransactionDate' in df.columns and not pd.api.types.is_datetime64_any_dtype(df['PreviousTransactionDate']):
        df['PreviousTransactionDate'] = pd.to_datetime(df['PreviousTransactionDate'], errors='coerce')
    
    # Handle missing values
    for feature in config['preprocessing']['features_to_impute']:
        if feature in df.columns:
            if feature in config['preprocessing']['categorical_features']:
                # Use mode imputation for categorical features
                mode_value = df[feature].mode()[0]
                df[feature].fillna(mode_value, inplace=True)
            else:
                # Use mean imputation for numerical features
                mean_value = df[feature].mean()
                df[feature].fillna(mean_value, inplace=True)
    
    # Drop rows with missing values in critical columns
    critical_columns = config['preprocessing']['critical_columns']
    critical_columns = [col for col in critical_columns if col in df.columns]
    if critical_columns:
        df.dropna(subset=critical_columns, inplace=True)
    
    # Convert categorical features to one-hot encoding
    categorical_features = [
        col for col in config['preprocessing']['categorical_features']
        if col in df.columns
    ]
    
    if categorical_features:
        df = pd.get_dummies(df, columns=categorical_features, drop_first=True)
    
    logger.info(f"Preprocessing complete. Output shape: {df.shape}")
    return df

def engineer_features(data, config=None):
    """
    Engineer additional features for fraud detection.
    
    Parameters:
    -----------
    data : pandas.DataFrame
        Preprocessed transaction data
    config : dict, optional
        Configuration parameters. If None, load from config file.
        
    Returns:
    --------
    pandas.DataFrame
        Data with engineered features
    """
    if config is None:
        config = load_config()
    
    logger.info("Starting feature engineering")
    
    # Make a copy to avoid modifying the original
    df = data.copy()
    
    # Calculate time-based features if we have datetime columns
    if 'TransactionDateTime' in df.columns:
        # Hour of day
        df['Hour'] = df['TransactionDateTime'].dt.hour
        
        # Day of week
        df['DayOfWeek'] = df['TransactionDateTime'].dt.dayofweek
        
        # Is weekend
        df['IsWeekend'] = df['DayOfWeek'].apply(lambda x: 1 if x >= 5 else 0)
        
        # Is night (between 10 PM and 6 AM)
        df['IsNight'] = df['Hour'].apply(lambda x: 1 if (x >= 22 or x < 6) else 0)
    
    # Time since last transaction (if not already present)
    if ('PreviousTransactionDate' in df.columns and 
        'TransactionDateTime' in df.columns and 
        'TimeSinceLastTransaction' not in df.columns):
        
        df['TimeSinceLastTransaction'] = (
            df['TransactionDateTime'] - df['PreviousTransactionDate']
        ).dt.total_seconds() / 3600  # Convert to hours
        
        # Fill missing values (first transaction for each customer)
        df['TimeSinceLastTransaction'].fillna(24 * 30, inplace=True)  # Set to 30 days for first transaction
    
    # Customer transaction frequency features (if CustomerID is present)
    if 'CustomerID' in df.columns:
        # Group by customer
        customer_groups = df.groupby('CustomerID')
        
        # Count transactions per customer
        transaction_counts = customer_groups.size().reset_index(name='CustomerTransactionCount')
        df = df.merge(transaction_counts, on='CustomerID', how='left')
        
        # Calculate average transaction amount per customer
        avg_amounts = customer_groups['Amount'].mean().reset_index(name='CustomerAvgAmount')
        df = df.merge(avg_amounts, on='CustomerID', how='left')
        
        # Calculate standard deviation of transaction amounts per customer
        std_amounts = customer_groups['Amount'].std().reset_index(name='CustomerAmountStd')
        df = df.merge(std_amounts, on='CustomerID', how='left')
        
        # Fill missing values for customers with only one transaction
        df['CustomerAmountStd'].fillna(0, inplace=True)
        
        # Calculate amount deviation from customer average
        df['AmountDeviation'] = (df['Amount'] - df['CustomerAvgAmount']) / (df['CustomerAmountStd'] + 1)
    
    # Amount-based features
    if 'Amount' in df.columns:
        # Log of amount (to handle skewness)
        df['LogAmount'] = np.log1p(df['Amount'])
        
        # Amount binning
        amount_bins = config['feature_engineering']['amount_bins']
        if amount_bins > 0:
            df['AmountBin'] = pd.qcut(
                df['Amount'], 
                q=amount_bins, 
                labels=False, 
                duplicates='drop'
            )
    
    # Calculate location-based features if we have location information
    if 'Location' in df.columns:
        # Location frequency
        location_counts = df['Location'].value_counts()
        df['LocationFrequency'] = df['Location'].map(location_counts)
        
        # Calculate customer's common locations
        if 'CustomerID' in df.columns:
            # For each customer, find their most common location
            customer_common_locations = df.groupby('CustomerID')['Location'].agg(
                lambda x: x.value_counts().index[0] if len(x.value_counts()) > 0 else None
            )
            
            # Create a binary feature for transactions in uncommon locations
            df['CommonLocation'] = df.apply(
                lambda row: 1 if row['Location'] == customer_common_locations.get(row['CustomerID']) else 0,
                axis=1
            )
    
    # Drop features that won't be used for modeling
    features_to_drop = config['feature_engineering']['drop_columns']
    features_to_drop = [col for col in features_to_drop if col in df.columns]
    if features_to_drop:
        df.drop(columns=features_to_drop, inplace=True)
    
    logger.info(f"Feature engineering complete. Output shape: {df.shape}")
    return df

def prepare_model_data(data, config=None):
    """
    Prepare data for modeling by scaling numerical features.
    
    Parameters:
    -----------
    data : pandas.DataFrame
        Transaction data with engineered features
    config : dict, optional
        Configuration parameters. If None, load from config file.
        
    Returns:
    --------
    tuple
        (X_scaled, feature_names) where X_scaled is a numpy array of scaled features
        and feature_names is a list of feature names
    """
    if config is None:
        config = load_config()
    
    logger.info("Preparing data for modeling")
    
    # Make a copy to avoid modifying the original
    df = data.copy()
    
    # Handle datetime columns - either convert to numeric or drop
    datetime_cols = df.select_dtypes(include=['datetime64']).columns.tolist()
    for col in datetime_cols:
        # Convert datetime to timestamp (numeric representation)
        df[f'{col}_timestamp'] = df[col].astype(np.int64) // 10**9  # Convert to Unix timestamp
        # Drop the original datetime column
        df = df.drop(columns=[col])
    
    # Check for any remaining object columns that might be timestamps
    object_cols = df.select_dtypes(include=['object']).columns.tolist()
    for col in object_cols:
        try:
            # Try to convert to datetime and then to numeric
            if 'date' in col.lower() or 'time' in col.lower():
                df[f'{col}_timestamp'] = pd.to_datetime(df[col]).astype(np.int64) // 10**9
                df = df.drop(columns=[col])
                # Update the object_cols list to reflect this change
                object_cols.remove(col)
        except:
            # If conversion fails, keep the column as is (might be handled later)
            pass
    
    # Handle any remaining object/categorical columns by one-hot encoding them
    # These might have been missed in the preprocessing step
    remaining_object_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
    if remaining_object_cols:
        logger.info(f"One-hot encoding remaining categorical features: {remaining_object_cols}")
        # Use get_dummies to one-hot encode the remaining categorical columns
        df = pd.get_dummies(df, columns=remaining_object_cols, drop_first=True)
    
    # Identify numerical features to scale
    numerical_features = df.select_dtypes(include=['int64', 'float64']).columns.tolist()
    
    # Exclude certain features from scaling if needed
    features_to_exclude = config['feature_engineering'].get('exclude_from_scaling', [])
    features_to_exclude = [col for col in features_to_exclude if col in df.columns]
    numerical_features = [col for col in numerical_features if col not in features_to_exclude]
    
    # Scale numerical features
    if numerical_features:
        scaler = StandardScaler()
        df[numerical_features] = scaler.fit_transform(df[numerical_features])
    
    # Final check to make sure all columns are numeric
    non_numeric_cols = df.select_dtypes(exclude=['int64', 'float64']).columns.tolist()
    if non_numeric_cols:
        logger.warning(f"Dropping non-numeric columns that couldn't be converted: {non_numeric_cols}")
        df = df.drop(columns=non_numeric_cols)
    
    # Get feature names for later use
    feature_names = df.columns.tolist()
    
    # Convert to numpy array
    X = df.values
    
    logger.info(f"Model data prepared with {len(feature_names)} features")
    return X, feature_names

def save_processed_data(data, filepath=None):
    """
    Save processed data to CSV file.
    
    Parameters:
    -----------
    data : pandas.DataFrame
        Processed transaction data
    filepath : str, optional
        Path to save the CSV file. If None, the path from config file will be used.
    """
    config = load_config()
    
    # Use provided filepath or get from config
    if filepath is None:
        filepath = config['paths']['processed_data']
    
    # Full path handling
    if not os.path.isabs(filepath):
        filepath = os.path.join(os.path.dirname(__file__), '../..', filepath)
    
    # Create directory if it doesn't exist
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    # Save data
    data.to_csv(filepath, index=False)
    logger.info(f"Processed data saved to {filepath}")

def load_processed_data(filepath=None):
    """
    Load processed data from CSV file.
    
    Parameters:
    -----------
    filepath : str, optional
        Path to the CSV file. If None, the path from config file will be used.
        
    Returns:
    --------
    pandas.DataFrame
        DataFrame containing processed transaction data
    """
    config = load_config()
    
    # Use provided filepath or get from config
    if filepath is None:
        filepath = config['paths']['processed_data']
    
    # Full path handling
    if not os.path.isabs(filepath):
        filepath = os.path.join(os.path.dirname(__file__), '../..', filepath)
    
    try:
        # Try to load the file
        data = pd.read_csv(filepath)
        logger.info(f"Successfully loaded processed data with {len(data)} rows")
        return data
    except FileNotFoundError:
        logger.warning(f"Processed data file not found: {filepath}")
        return None

if __name__ == "__main__":
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Example usage
    # Load configuration
    config = load_config()
    
    # Load raw data
    raw_data = load_data()
    
    # Preprocess data
    preprocessed_data = preprocess_data(raw_data, config)
    
    # Engineer features
    featured_data = engineer_features(preprocessed_data, config)
    
    # Save processed data
    save_processed_data(featured_data)
    
    # Prepare for modeling
    X, feature_names = prepare_model_data(featured_data, config)
    
    logger.info(f"Final data shape: {X.shape}")
    logger.info(f"Features: {feature_names}") 