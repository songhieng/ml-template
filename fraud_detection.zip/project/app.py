"""
Fraud Detection System - Streamlit App
This application provides a user interface for the fraud detection system.
"""

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
import sys
import logging
from datetime import datetime
import time

# Add the project directory to the path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import project modules
from src.data.data_loader import load_data, preprocess_data, engineer_features, prepare_model_data
from src.models.anomaly_detection import (
    apply_kmeans, apply_dbscan, apply_isolation_forest, 
    apply_local_outlier_factor, get_ensemble_predictions, 
    compare_methods, generate_fraud_report
)
from src.utils.visualization import set_plot_style
from src.utils.logger import setup_logger
from src.utils.config import load_config

# Set up logger
logger = setup_logger()

# Set page configuration
st.set_page_config(
    page_title="Fraud Detection System",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Application title and description
st.title("🔍 Transaction Fraud Detection System")
st.markdown("""
This application detects potential fraudulent transactions using multiple anomaly detection techniques:
- **K-means Clustering**: Identifies outliers based on distance from cluster centroids
- **DBSCAN**: Density-based spatial clustering that identifies outliers in low-density regions
- **Isolation Forest**: Ensemble method that detects anomalies by isolating observations
- **Local Outlier Factor**: Identifies outliers by measuring local deviation of density
- **Ensemble Method**: Combines results from multiple methods for more robust detection
""")

# Sidebar for navigation and controls
st.sidebar.title("Navigation")
page = st.sidebar.radio(
    "Select a page",
    ["Home", "Data Explorer", "Model Configuration", "Fraud Detection", "Results Analysis"]
)

# Initialize session state to store data and results across pages
if 'data' not in st.session_state:
    st.session_state.data = None
if 'preprocessed_data' not in st.session_state:
    st.session_state.preprocessed_data = None
if 'featured_data' not in st.session_state:
    st.session_state.featured_data = None
if 'X_scaled' not in st.session_state:
    st.session_state.X_scaled = None
if 'feature_names' not in st.session_state:
    st.session_state.feature_names = None
if 'detection_results' not in st.session_state:
    st.session_state.detection_results = {}
if 'potential_frauds' not in st.session_state:
    st.session_state.potential_frauds = {}
if 'model_config' not in st.session_state:
    # Initialize model configuration from config.yaml
    config = load_config()
    st.session_state.model_config = {
        "kmeans": {
            "enabled": config['anomaly_detection']['kmeans']['enabled'],
            "n_clusters": config['anomaly_detection']['kmeans']['n_clusters'],
            "threshold_percentile": config['anomaly_detection']['kmeans']['threshold_percentile']
        },
        "dbscan": {
            "enabled": config['anomaly_detection']['dbscan']['enabled'],
            "eps": config['anomaly_detection']['dbscan']['eps'],
            "min_samples": config['anomaly_detection']['dbscan']['min_samples']
        },
        "isolation_forest": {
            "enabled": config['anomaly_detection']['isolation_forest']['enabled'],
            "contamination": config['anomaly_detection']['isolation_forest']['contamination'],
            "n_estimators": config['anomaly_detection']['isolation_forest']['n_estimators']
        },
        "lof": {
            "enabled": config['anomaly_detection']['local_outlier_factor']['enabled'],
            "n_neighbors": config['anomaly_detection']['local_outlier_factor']['n_neighbors'],
            "contamination": config['anomaly_detection']['local_outlier_factor']['contamination']
        },
        "ensemble": {
            "enabled": config['anomaly_detection']['ensemble']['enabled'],
            "weight_kmeans": config['anomaly_detection']['ensemble']['weight_kmeans'],
            "weight_dbscan": config['anomaly_detection']['ensemble']['weight_dbscan'],
            "weight_iforest": config['anomaly_detection']['ensemble']['weight_iforest'],
            "weight_lof": config['anomaly_detection']['ensemble']['weight_lof'],
            "threshold": config['anomaly_detection']['ensemble']['threshold']
        }
    }

# Home page
if page == "Home":
    st.header("Welcome to the Transaction Fraud Detection System")
    
    st.subheader("Getting Started")
    st.markdown("""
    1. **Data Explorer**: Upload and explore your transaction data
    2. **Model Configuration**: Configure anomaly detection parameters
    3. **Fraud Detection**: Run detection algorithms and view results
    4. **Results Analysis**: Analyze and compare detection results
    """)
    
    st.subheader("Upload Transaction Data")
    uploaded_file = st.file_uploader("Choose a CSV file with transaction data", type="csv")
    
    if uploaded_file is not None:
        with st.spinner('Loading data...'):
            # Save the uploaded file temporarily
            with open("temp_upload.csv", "wb") as f:
                f.write(uploaded_file.getbuffer())
            
            # Load the data
            data = load_data("temp_upload.csv")
            st.session_state.data = data
            
            # Display success message
            st.success(f"Data loaded successfully! {len(data)} transactions found.")
            
            # Show a preview
            st.subheader("Data Preview")
            st.dataframe(data.head())
    
    # Option to use sample data
    if st.button("Use Sample Data"):
        with st.spinner('Generating sample data...'):
            data = load_data()  # This will generate sample data
            st.session_state.data = data
            
            st.success(f"Sample data generated successfully! {len(data)} transactions.")
            
            # Show a preview
            st.subheader("Sample Data Preview")
            st.dataframe(data.head())

# Data Explorer page
elif page == "Data Explorer":
    st.header("Data Explorer")
    
    if st.session_state.data is None:
        st.warning("No data loaded. Please go to the Home page to upload data or generate sample data.")
    else:
        # Display basic information about the data
        st.subheader("Dataset Information")
        st.write(f"Number of transactions: {len(st.session_state.data)}")
        st.write(f"Number of features: {len(st.session_state.data.columns)}")
        
        # Show column information
        st.subheader("Column Information")
        buffer = []
        for col in st.session_state.data.columns:
            dtype = str(st.session_state.data[col].dtype)
            missing = st.session_state.data[col].isnull().sum()
            missing_pct = missing / len(st.session_state.data) * 100
            buffer.append({"Column": col, "Type": dtype, "Missing Values": missing, "Missing %": f"{missing_pct:.2f}%"})
        
        st.table(pd.DataFrame(buffer))
        
        # Data preprocessing
        st.subheader("Data Preprocessing")
        if st.button("Preprocess Data"):
            with st.spinner('Preprocessing data...'):
                preprocessed_data = preprocess_data(st.session_state.data)
                featured_data = engineer_features(preprocessed_data)
                X_scaled, feature_names = prepare_model_data(featured_data)
                
                st.session_state.preprocessed_data = preprocessed_data
                st.session_state.featured_data = featured_data
                st.session_state.X_scaled = X_scaled
                st.session_state.feature_names = feature_names
                
                st.success("Data preprocessing complete!")
                st.write(f"Shape after preprocessing: {featured_data.shape}")
        
        # Data visualization
        if st.session_state.featured_data is not None:
            st.subheader("Data Visualization")
            
            # Select column for visualization
            numeric_cols = st.session_state.featured_data.select_dtypes(include=['int64', 'float64']).columns.tolist()
            categorical_cols = st.session_state.featured_data.select_dtypes(include=['object', 'category']).columns.tolist()
            
            viz_type = st.selectbox("Select visualization type", ["Distribution", "Correlation Matrix", "Box Plot"])
            
            if viz_type == "Distribution":
                col = st.selectbox("Select column for distribution plot", numeric_cols)
                fig, ax = plt.subplots(figsize=(10, 6))
                sns.histplot(st.session_state.featured_data[col], kde=True)
                plt.title(f"Distribution of {col}")
                plt.grid(True, alpha=0.3)
                st.pyplot(fig)
                
            elif viz_type == "Correlation Matrix":
                # Select columns for correlation matrix
                selected_cols = st.multiselect(
                    "Select columns for correlation matrix (max 10)", 
                    numeric_cols,
                    default=numeric_cols[:min(5, len(numeric_cols))]
                )
                
                if len(selected_cols) > 0:
                    if len(selected_cols) > 10:
                        st.warning("Too many columns selected. Using first 10.")
                        selected_cols = selected_cols[:10]
                    
                    fig, ax = plt.subplots(figsize=(10, 8))
                    corr = st.session_state.featured_data[selected_cols].corr()
                    sns.heatmap(corr, annot=True, cmap="YlOrBr", fmt=".2f")
                    plt.title("Correlation Matrix")
                    st.pyplot(fig)
                
            elif viz_type == "Box Plot":
                col = st.selectbox("Select column for box plot", numeric_cols)
                fig, ax = plt.subplots(figsize=(10, 6))
                sns.boxplot(y=st.session_state.featured_data[col])
                plt.title(f"Box Plot of {col}")
                plt.grid(True, alpha=0.3)
                st.pyplot(fig)

# Model Configuration page
elif page == "Model Configuration":
    st.header("Model Configuration")
    
    if st.session_state.featured_data is None:
        st.warning("No preprocessed data available. Please go to the Data Explorer page to preprocess your data.")
    else:
        st.subheader("Configure Anomaly Detection Parameters")
        
        with st.form("model_config_form"):
            # K-means parameters
            st.markdown("### K-means Parameters")
            kmeans_enabled = st.checkbox("Enable K-means", value=True)
            kmeans_clusters = st.slider("Number of clusters", min_value=2, max_value=10, value=3)
            kmeans_threshold = st.slider("Anomaly threshold percentile", min_value=90, max_value=99, value=95)
            
            # DBSCAN parameters
            st.markdown("### DBSCAN Parameters")
            dbscan_enabled = st.checkbox("Enable DBSCAN", value=True)
            dbscan_eps = st.slider("Epsilon (neighborhood distance)", min_value=0.1, max_value=2.0, value=0.5, step=0.1)
            dbscan_min_samples = st.slider("Minimum samples per cluster", min_value=2, max_value=20, value=5)
            
            # Isolation Forest parameters
            st.markdown("### Isolation Forest Parameters")
            iforest_enabled = st.checkbox("Enable Isolation Forest", value=True)
            iforest_contamination = st.slider("Contamination (expected fraud rate)", min_value=0.01, max_value=0.2, value=0.05, step=0.01)
            iforest_estimators = st.slider("Number of estimators", min_value=50, max_value=200, value=100, step=10)
            
            # LOF parameters
            st.markdown("### Local Outlier Factor Parameters")
            lof_enabled = st.checkbox("Enable Local Outlier Factor", value=True)
            lof_neighbors = st.slider("Number of neighbors", min_value=5, max_value=50, value=20)
            lof_contamination = st.slider("LOF Contamination", min_value=0.01, max_value=0.2, value=0.05, step=0.01)
            
            # Ensemble parameters
            st.markdown("### Ensemble Parameters")
            ensemble_enabled = st.checkbox("Enable Ensemble Method", value=True)
            weight_kmeans = st.slider("K-means weight", min_value=0.0, max_value=2.0, value=1.0, step=0.1)
            weight_dbscan = st.slider("DBSCAN weight", min_value=0.0, max_value=2.0, value=1.0, step=0.1)
            weight_iforest = st.slider("Isolation Forest weight", min_value=0.0, max_value=2.0, value=1.5, step=0.1)
            weight_lof = st.slider("LOF weight", min_value=0.0, max_value=2.0, value=1.0, step=0.1)
            ensemble_threshold = st.slider("Ensemble threshold", min_value=0.1, max_value=0.9, value=0.6, step=0.05)
            
            # Submit button
            submit_button = st.form_submit_button("Save Configuration")
        
        if submit_button:
            # Store configuration in session state
            st.session_state.model_config = {
                "kmeans": {
                    "enabled": kmeans_enabled,
                    "n_clusters": kmeans_clusters,
                    "threshold_percentile": kmeans_threshold
                },
                "dbscan": {
                    "enabled": dbscan_enabled,
                    "eps": dbscan_eps,
                    "min_samples": dbscan_min_samples
                },
                "isolation_forest": {
                    "enabled": iforest_enabled,
                    "contamination": iforest_contamination,
                    "n_estimators": iforest_estimators
                },
                "lof": {
                    "enabled": lof_enabled,
                    "n_neighbors": lof_neighbors,
                    "contamination": lof_contamination
                },
                "ensemble": {
                    "enabled": ensemble_enabled,
                    "weight_kmeans": weight_kmeans,
                    "weight_dbscan": weight_dbscan,
                    "weight_iforest": weight_iforest,
                    "weight_lof": weight_lof,
                    "threshold": ensemble_threshold
                }
            }
            
            st.success("Configuration saved successfully!")

# Fraud Detection page
elif page == "Fraud Detection":
    st.header("Fraud Detection")
    
    if st.session_state.featured_data is None or st.session_state.X_scaled is None:
        st.warning("No preprocessed data available. Please go to the Data Explorer page to preprocess your data.")
    elif 'model_config' not in st.session_state:
        st.warning("No model configuration available. Please go to the Model Configuration page to set up your models.")
    else:
        st.subheader("Run Anomaly Detection Algorithms")
        
        if st.button("Run Detection"):
            with st.spinner('Running anomaly detection algorithms...'):
                # Get data and configuration
                data = st.session_state.featured_data.copy()
                X = st.session_state.X_scaled
                feature_names = st.session_state.feature_names
                config = st.session_state.model_config
                
                # Initialize progress bar
                progress_bar = st.progress(0)
                progress_text = st.empty()
                
                # Apply K-means
                if config["kmeans"]["enabled"]:
                    progress_text.text("Running K-means clustering...")
                    data, kmeans_frauds = apply_kmeans(
                        X, data, feature_names,
                        n_clusters=config["kmeans"]["n_clusters"],
                        threshold_percentile=config["kmeans"]["threshold_percentile"]
                    )
                    st.session_state.potential_frauds["kmeans"] = kmeans_frauds
                    progress_bar.progress(20)
                
                # Apply DBSCAN
                if config["dbscan"]["enabled"]:
                    progress_text.text("Running DBSCAN clustering...")
                    data, dbscan_frauds = apply_dbscan(
                        X, data, feature_names,
                        eps=config["dbscan"]["eps"],
                        min_samples=config["dbscan"]["min_samples"]
                    )
                    st.session_state.potential_frauds["dbscan"] = dbscan_frauds
                    progress_bar.progress(40)
                
                # Apply Isolation Forest
                if config["isolation_forest"]["enabled"]:
                    progress_text.text("Running Isolation Forest...")
                    data, iforest_frauds, _ = apply_isolation_forest(
                        X, data, feature_names,
                        contamination=config["isolation_forest"]["contamination"],
                        n_estimators=config["isolation_forest"]["n_estimators"]
                    )
                    st.session_state.potential_frauds["isolation_forest"] = iforest_frauds
                    progress_bar.progress(60)
                
                # Apply LOF
                if config["lof"]["enabled"]:
                    progress_text.text("Running Local Outlier Factor...")
                    data, lof_frauds = apply_local_outlier_factor(
                        X, data, feature_names,
                        n_neighbors=config["lof"]["n_neighbors"],
                        contamination=config["lof"]["contamination"]
                    )
                    st.session_state.potential_frauds["lof"] = lof_frauds
                    progress_bar.progress(80)
                
                # Apply Ensemble Method
                if config["ensemble"]["enabled"]:
                    progress_text.text("Creating ensemble predictions...")
                    data, ensemble_frauds = get_ensemble_predictions(
                        data,
                        weight_kmeans=config["ensemble"]["weight_kmeans"],
                        weight_dbscan=config["ensemble"]["weight_dbscan"],
                        weight_iforest=config["ensemble"]["weight_iforest"],
                        weight_lof=config["ensemble"]["weight_lof"],
                        threshold=config["ensemble"]["threshold"]
                    )
                    st.session_state.potential_frauds["ensemble"] = ensemble_frauds
                
                # Store results
                st.session_state.detection_results = data
                
                # Compare methods
                progress_text.text("Comparing methods...")
                comparison = compare_methods(
                    data,
                    st.session_state.potential_frauds.get("kmeans", pd.DataFrame()),
                    st.session_state.potential_frauds.get("dbscan", pd.DataFrame()),
                    st.session_state.potential_frauds.get("isolation_forest", pd.DataFrame()),
                    st.session_state.potential_frauds.get("lof", pd.DataFrame()),
                    st.session_state.potential_frauds.get("ensemble", pd.DataFrame())
                )
                st.session_state.method_comparison = comparison
                
                progress_bar.progress(100)
                progress_text.text("Detection complete!")
                time.sleep(1)  # Give user time to see 100%
                progress_text.empty()
                
                st.success("Anomaly detection complete!")
        
        # Display results if available
        if 'detection_results' in st.session_state and len(st.session_state.detection_results) > 0:
            st.subheader("Detection Results Summary")
            
            if 'method_comparison' in st.session_state:
                st.table(st.session_state.method_comparison)
            
            # Plot results
            st.subheader("Visualization")
            
            # Select method for visualization
            methods = []
            if st.session_state.model_config["kmeans"]["enabled"]:
                methods.append("K-means")
            if st.session_state.model_config["dbscan"]["enabled"]:
                methods.append("DBSCAN")
            if st.session_state.model_config["isolation_forest"]["enabled"]:
                methods.append("Isolation Forest")
            if st.session_state.model_config["lof"]["enabled"]:
                methods.append("LOF")
            if st.session_state.model_config["ensemble"]["enabled"]:
                methods.append("Ensemble")
            
            if methods:
                selected_method = st.selectbox("Select method to visualize", methods)
                
                # Select features for scatter plot
                numeric_cols = st.session_state.featured_data.select_dtypes(include=['int64', 'float64']).columns.tolist()
                feature_x = st.selectbox("Select X-axis feature", numeric_cols, index=0)
                feature_y = st.selectbox("Select Y-axis feature", numeric_cols, index=min(1, len(numeric_cols)-1))
                
                # Map method name to column prefix
                method_prefix_map = {
                    "K-means": "KMeans",
                    "DBSCAN": "DBSCAN",
                    "Isolation Forest": "IF",
                    "LOF": "LOF",
                    "Ensemble": "Ensemble"
                }
                
                prefix = method_prefix_map[selected_method]
                
                # Create scatter plot
                fig, ax = plt.subplots(figsize=(10, 6))
                
                # Get normal and anomalous points
                results = st.session_state.detection_results
                
                if prefix == "KMeans":
                    normal = results[results["KMeans_IsAnomaly"] == 0]
                    anomaly = results[results["KMeans_IsAnomaly"] == 1]
                elif prefix == "DBSCAN":
                    normal = results[results["DBSCAN_IsAnomaly"] == 0]
                    anomaly = results[results["DBSCAN_IsAnomaly"] == 1]
                elif prefix == "IF":
                    normal = results[results["IF_IsAnomaly"] == 1]  # Note: IF uses 1 for normal
                    anomaly = results[results["IF_IsAnomaly"] == -1]  # and -1 for anomaly
                elif prefix == "LOF":
                    normal = results[results["LOF_IsAnomaly"] == 1]  # Same for LOF
                    anomaly = results[results["LOF_IsAnomaly"] == -1]
                else:  # Ensemble
                    normal = results[results["Ensemble_Prediction"] == 0]
                    anomaly = results[results["Ensemble_Prediction"] == 1]
                
                # Plot normal transactions
                ax.scatter(
                    normal[feature_x], normal[feature_y],
                    c='blue', label='Normal', alpha=0.5, s=30
                )
                
                # Plot anomalies
                ax.scatter(
                    anomaly[feature_x], anomaly[feature_y],
                    c='red', label='Potential Fraud', alpha=0.7, s=50, marker='X'
                )
                
                # Add labels and title
                ax.set_xlabel(feature_x)
                ax.set_ylabel(feature_y)
                ax.set_title(f'Anomaly Detection: {selected_method}')
                ax.legend()
                
                st.pyplot(fig)

# Results Analysis page
elif page == "Results Analysis":
    st.header("Results Analysis")
    
    if 'detection_results' not in st.session_state or len(st.session_state.detection_results) == 0:
        st.warning("No detection results available. Please go to the Fraud Detection page to run the algorithms.")
    else:
        st.subheader("Potential Fraudulent Transactions")
        
        # Method selection
        methods = []
        if "kmeans" in st.session_state.potential_frauds:
            methods.append("K-means")
        if "dbscan" in st.session_state.potential_frauds:
            methods.append("DBSCAN")
        if "isolation_forest" in st.session_state.potential_frauds:
            methods.append("Isolation Forest")
        if "lof" in st.session_state.potential_frauds:
            methods.append("LOF")
        if "ensemble" in st.session_state.potential_frauds:
            methods.append("Ensemble")
        
        method_key_map = {
            "K-means": "kmeans",
            "DBSCAN": "dbscan",
            "Isolation Forest": "isolation_forest",
            "LOF": "lof",
            "Ensemble": "ensemble"
        }
        
        if methods:
            selected_method = st.selectbox("Select method to analyze", methods)
            method_key = method_key_map[selected_method]
            
            # Display fraudulent transactions
            frauds = st.session_state.potential_frauds[method_key]
            if len(frauds) > 0:
                st.write(f"Found {len(frauds)} potential fraudulent transactions ({len(frauds)/len(st.session_state.detection_results):.2%} of total)")
                
                # Feature selection for display
                all_cols = frauds.columns.tolist()
                default_cols = [col for col in all_cols if col in ['TransactionID', 'CustomerID', 'Amount', 'TransactionType', 'TransactionDateTime']]
                if not default_cols:
                    default_cols = all_cols[:min(5, len(all_cols))]
                
                selected_cols = st.multiselect(
                    "Select columns to display",
                    all_cols,
                    default=default_cols
                )
                
                if selected_cols:
                    st.dataframe(frauds[selected_cols])
                else:
                    st.dataframe(frauds)
                
                # Download link for CSV
                @st.cache_data
                def convert_df_to_csv(df):
                    return df.to_csv(index=False).encode('utf-8')
                
                csv = convert_df_to_csv(frauds)
                st.download_button(
                    "Download as CSV",
                    csv,
                    f"fraud_detection_{method_key}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    "text/csv",
                    key=f'download_{method_key}'
                )
                
                # Generate detailed report
                if st.button("Generate Detailed Report"):
                    with st.spinner('Generating report...'):
                        report = generate_fraud_report(
                            st.session_state.detection_results,
                            frauds
                        )
                        
                        st.session_state.fraud_report = report
                
                # Display report if available
                if 'fraud_report' in st.session_state:
                    st.subheader("Fraud Detection Report")
                    
                    report = st.session_state.fraud_report
                    
                    # Basic metrics
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Total Transactions", report['total_transactions'])
                    with col2:
                        st.metric("Potential Frauds", report['potential_frauds'])
                    with col3:
                        st.metric("Fraud Percentage", f"{report['fraud_percentage']:.2%}")
                    
                    # Amount comparison
                    if 'avg_amount_fraud' in report and 'avg_amount_normal' in report:
                        st.subheader("Transaction Amount Analysis")
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric("Avg Fraud Amount", f"${report['avg_amount_fraud']:.2f}")
                        with col2:
                            st.metric("Avg Normal Amount", f"${report['avg_amount_normal']:.2f}")
                        with col3:
                            st.metric("Difference", f"{report['amount_difference_percent']:.2%}")
                    
                    # Transaction type distribution
                    if 'fraud_transaction_types' in report:
                        st.subheader("Transaction Type Distribution")
                        
                        fraud_types = report['fraud_transaction_types']
                        normal_types = report['normal_transaction_types']
                        
                        # Convert to DataFrame for plotting
                        types_df = pd.DataFrame({
                            'Type': list(fraud_types.keys()),
                            'Fraud (%)': list(fraud_types.values()),
                            'Normal (%)': [normal_types.get(t, 0) for t in fraud_types.keys()]
                        })
                        
                        fig, ax = plt.subplots(figsize=(10, 6))
                        types_df.plot(x='Type', y=['Fraud (%)', 'Normal (%)'], kind='bar', ax=ax)
                        plt.title('Transaction Type Distribution')
                        plt.ylabel('Percentage')
                        plt.grid(axis='y', alpha=0.3)
                        st.pyplot(fig)
            else:
                st.info(f"No fraudulent transactions detected by {selected_method}.")
        else:
            st.warning("No detection results available. Please run the detection algorithms first.")

# Footer
st.markdown("---")
st.markdown("Fraud Detection System | Powered by Streamlit") 