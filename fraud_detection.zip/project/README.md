# 🔍 Transaction Fraud Detection System

A comprehensive system for detecting potential fraudulent transactions in banking data using multiple anomaly detection techniques.

## 📋 Overview

This project provides a modular, extensible framework for analyzing bank transaction data and identifying potential fraudulent activities using multiple anomaly detection algorithms:

1. **K-means Clustering**: Identifies outliers based on distance from cluster centroids
2. **DBSCAN**: Density-based spatial clustering that identifies outliers in low-density regions
3. **Isolation Forest**: Ensemble method that detects anomalies by isolating observations
4. **Local Outlier Factor**: Identifies outliers by measuring local deviation of density
5. **Ensemble Method**: Combines results from multiple methods for more robust detection

## 🌟 Streamlit Interactive Interface

The project now includes a Streamlit web application that provides an intuitive interface for:

- **Data Exploration**: Upload your data and visualize distributions and correlations
- **Model Configuration**: Easily configure parameters for all anomaly detection methods
- **Fraud Detection**: Run detection algorithms and view results in real-time
- **Results Analysis**: Generate comprehensive reports and visualize potential frauds

## 🔑 Key Features

- **Comprehensive Data Preprocessing**: Handles missing values, converts dates, and creates derived features
- **Exploratory Data Analysis**: Visualizes distributions and correlations to understand the data
- **Multiple Detection Algorithms**: Implements four different anomaly detection techniques
- **Ensemble Approach**: Combines results from different algorithms for more robust detection
- **Detailed Reporting**: Generates comprehensive reports on potential fraudulent transactions
- **Visualization**: Visual representation of clusters and anomalies for better understanding
- **Sample Data Generation**: Can generate synthetic transaction data for testing when real data is unavailable

## 🚀 Getting Started

### Prerequisites

- Python 3.7+
- Required packages: pandas, numpy, matplotlib, seaborn, scikit-learn, streamlit

### Installation

1. Clone this repository:
```
git clone https://github.com/yourusername/fraud-detection.git
cd fraud-detection
```

2. Install required packages:
```
pip install -r requirements.txt
```

### Running the Streamlit App

1. Navigate to the project directory and run:
```
streamlit run app.py
```

2. The app will open in your default web browser, typically at `http://localhost:8501`

3. Use the app to:
   - Upload transaction data or generate sample data
   - Explore and preprocess the data
   - Configure anomaly detection parameters
   - Run detection algorithms
   - Analyze and visualize the results

## 📊 Data Format

The system expects a CSV file with transaction data containing some or all of these columns:

- `TransactionID`: Unique identifier for each transaction
- `AccountID` or `CustomerID`: Identifier for the account/customer
- `TransactionAmount` or `Amount`: Monetary value of the transaction
- `TransactionDate`: Date and time of the transaction
- `TransactionType`: Type of transaction (e.g., 'Credit', 'Debit')
- `Location`: Geographic location of the transaction
- `DeviceID`: Identifier for the device used
- `IP Address`: IP address used for the transaction
- `MerchantID`: Identifier for the merchant
- `Channel`: Transaction channel (e.g., 'Online', 'ATM', 'Branch')
- `AccountBalance`: Account balance after the transaction

## 🧩 Project Structure

- `app.py`: Streamlit web application for interactive fraud detection
- `fraud_detection_main.py`: Main script to run the fraud detection system from the command line
- `fraud_detection_preprocessing.py`: Functions for data loading and preprocessing
- `fraud_detection_anomaly.py`: Implementation of anomaly detection algorithms
- `project/src/`: Organized modules of the fraud detection system
  - `data/`: Data loading and processing modules
  - `models/`: Anomaly detection and supervised learning models
  - `utils/`: Visualization and utility functions
  - `config/`: Configuration files for the system

## 📝 Example Output

The system generates a comprehensive report of potential fraudulent transactions, including:

- Total number of transactions analyzed
- Number and percentage of potential frauds detected
- Comparison of transaction characteristics between normal and potentially fraudulent transactions
- Detailed CSV file with all potential frauds

## 🔧 Customization

The system is highly customizable via the Streamlit interface or by modifying the config files:

- Adjust algorithm parameters
- Modify feature selection for anomaly detection
- Change weights for the ensemble method
- Adjust threshold values for fraud classification

## 📈 Future Improvements

- Implement supervised learning algorithms using labeled data
- Add more advanced feature engineering
- Create real-time monitoring capabilities
- Integrate with alert systems
- Add user authentication for the Streamlit app

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Running with Docker

### Prerequisites

- Docker and Docker Compose installed on your system

### Quick Start

1. Clone the repository:
   ```
   git clone <your-repository-url>
   cd project
   ```

2. Build and start the container:
   ```
   docker-compose up --build
   ```

3. Access the application in your browser:
   ```
   http://localhost:8501
   ```

4. To stop the application:
   ```
   docker-compose down
   ```

### Data Persistence

The Docker configuration uses volume mounts to persist data and trained models:
- `./data:/app/data`: Persists raw and processed data
- `./models:/app/models`: Persists trained models

## Manual Setup (without Docker)

### Prerequisites

- Python 3.10 or later
- pip package manager

### Installation

1. Clone the repository:
   ```
   git clone <your-repository-url>
   cd project
   ```

2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Run the application:
   ```
   streamlit run app.py
   ```

4. Access the application in your browser:
   ```
   http://localhost:8501
   ```

## Usage Guide

1. **Home**: Upload your transaction data or use sample data
2. **Data Explorer**: Preprocess data and explore features
3. **Model Configuration**: Configure anomaly detection parameters
4. **Fraud Detection**: Run detection algorithms and view results
5. **Results Analysis**: Analyze potential fraudulent transactions

## License

[Your license information] 