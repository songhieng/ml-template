import pandas as pd
import os
import numpy as np
import time
from PIL import Image
from scipy import signal
from imageio import imread
from urllib.request import urlopen
from multiprocessing import Pool

def check_row(line):
    """
    Scan the elements on a row of image and check if they form a line.
    The return value is maximum length of line in the row.
    """
    max_length = 0
    cur_length = 0
    last_value = 0
    for v in line:
        if v > 0:
            if v == last_value:
                cur_length += 1
                max_length = max(max_length, cur_length)
            else:
                last_value = v
                cur_length = 1
        else:
            cur_length = 0
            last_value = 0
    return max_length

def check_img(arr):
    """
    Scan all rows in the image and return the indices of rows that form horizontal lines.
    A row is considered a line if check_row(row) > 1/3 of the row length.
    """
    res_index = []
    row_length = arr.shape[1]
    for idx, row in enumerate(arr):
        l = check_row(row)
        if 3 * l > row_length:
            res_index.append(idx)
    return res_index

def horizontal_filter(tuple_input):
    index, path, type_file = tuple_input
    kernel = np.array([[-1, -1, -1],
                       [ 0,  0,  0],
                       [+1, +1, +1]])
    try:
        if type_file == 'link':
            with urlopen(path) as file:
                img = imread(file, pilmode='L')
        elif type_file == 'path':
            img = imread(path, pilmode='L')
        else:
            raise ValueError('The type_file must be "link" or "path"')

        dst = signal.convolve2d(img, kernel, boundary='symm', mode='same')
        dst = np.abs(dst)
        dst2 = np.interp(dst, (dst.min(), dst.max()), (0, 10)).astype(int)
        list_index = check_img(dst2)
        return (index, path, len(list_index))
    except Exception as e:
        print(f"Error processing {path}: {e}")
        return (index, path, 0)

def detect(list_image, nprocess=4, output="output.tsv"):
    """
    Compute the number of horizontal edges in each image.

    Parameters
    ----------
    list_image : list of tuples (index, image_path, type)
        Each tuple contains:
        - index: int
        - image_path: str (local path or URL)
        - type: str ("link" or "path")
    nprocess : int, default=4
        Number of parallel processes.
    output : str, default="output.tsv"
        Output file path. Tab-separated with columns: index, image_path, line_count.
    """
    with Pool(nprocess) as p:
        data = p.map(horizontal_filter, list_image)
    df = pd.DataFrame(data, columns=["index", "image_path", "line_count"])
    df.to_csv(output, sep='\t', index=False)
