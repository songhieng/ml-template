import screenshot_detector
import os
import pandas as pd
import multiprocessing

def run_detection():
    # Test image from path
    dir_path = 'images/back_nid/'
    lfile = os.listdir(dir_path)
    input_path = [(i, os.path.join(dir_path, lfile[i]), 'path') for i in range(len(lfile))]
    screenshot_detector.detect(list_image=input_path, nprocess=4, output="output_path.tsv")

if __name__ == "__main__":
    multiprocessing.freeze_support()  # Optional but recommended on Windows
    run_detection()
