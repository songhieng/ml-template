from collections import defaultdict
from itertools import combinations
from typing import Dict, List, Set, Tuple, Union
import pandas as pd
import numpy as np
from tqdm import tqdm


class BankingPatternAnalysis:
    """
    A specialized implementation of pattern analysis for banking transactions and services
    using the Apriori algorithm to discover frequent service usage patterns and generate
    banking service association rules.
    """
    
    def __init__(
        self,
        min_usage_rate: float = 0.1,
        min_association_strength: float = 0.5,
        min_correlation_score: float = 1.0,
        max_service_combination: int = None
    ):
        """
        Initialize the Banking Pattern Analysis with customizable parameters.
        
        Args:
            min_usage_rate (float): Minimum usage rate threshold (0 to 1)
                                  Equivalent to support in traditional market basket analysis
            min_association_strength (float): Minimum association strength threshold (0 to 1)
                                           Equivalent to confidence in traditional analysis
            min_correlation_score (float): Minimum correlation score threshold
                                        Equivalent to lift in traditional analysis
            max_service_combination (int): Maximum number of services to consider in combinations
        """
        self.min_usage_rate = min_usage_rate
        self.min_association_strength = min_association_strength
        self.min_correlation_score = min_correlation_score
        self.max_service_combination = max_service_combination
        self.frequent_service_combinations = {}
        self.service_patterns = []
        self.service_counts = None
        self.total_sessions = None
        
    def _generate_service_combinations(
        self,
        prev_frequent: List[frozenset],
        k: int
    ) -> List[frozenset]:
        """
        Generate candidate service combinations of size k from frequent combinations of size k-1.
        
        Args:
            prev_frequent: List of frequent service combinations from previous iteration
            k: Size of service combinations to generate
            
        Returns:
            List of candidate service combinations
        """
        candidates = []
        for i in range(len(prev_frequent)):
            for j in range(i + 1, len(prev_frequent)):
                services1 = list(prev_frequent[i])
                services2 = list(prev_frequent[j])
                services1.sort()
                services2.sort()
                
                if services1[:k-2] == services2[:k-2]:
                    candidate = frozenset(services1) | frozenset(services2)
                    if len(candidate) == k:
                        valid = True
                        for subset in combinations(candidate, k-1):
                            if frozenset(subset) not in prev_frequent:
                                valid = False
                                break
                        if valid:
                            candidates.append(candidate)
        return candidates
    
    def _calculate_usage_rate(
        self,
        service_combination: frozenset,
        sessions: List[frozenset]
    ) -> float:
        """
        Calculate usage rate for a service combination.
        
        Args:
            service_combination: Set of services to calculate usage rate for
            sessions: List of banking sessions
            
        Returns:
            Usage rate value
        """
        count = sum(1 for session in sessions if service_combination.issubset(session))
        return count / self.total_sessions
    
    def analyze_patterns(
        self,
        sessions: Union[List[List], pd.DataFrame]
    ) -> 'BankingPatternAnalysis':
        """
        Analyze banking service usage patterns to find frequent combinations.
        
        Args:
            sessions: List of banking sessions or DataFrame with session data
            
        Returns:
            self
        """
        if isinstance(sessions, pd.DataFrame):
            sessions = sessions.values.tolist()
        
        sessions = [frozenset(session) for session in sessions]
        self.total_sessions = len(sessions)
        
        unique_services = set().union(*sessions)
        self.service_counts = defaultdict(int)
        
        # Generate frequent 1-service combinations
        L1 = []
        for service in unique_services:
            service_set = frozenset([service])
            usage_rate = self._calculate_usage_rate(service_set, sessions)
            if usage_rate >= self.min_usage_rate:
                L1.append(service_set)
                self.frequent_service_combinations[service_set] = usage_rate
        
        current_L = L1
        k = 2
        
        while current_L and (self.max_service_combination is None or k <= self.max_service_combination):
            candidates = self._generate_service_combinations(current_L, k)
            current_L = []
            
            for candidate in tqdm(candidates, desc=f"Analyzing {k}-service combinations"):
                usage_rate = self._calculate_usage_rate(candidate, sessions)
                if usage_rate >= self.min_usage_rate:
                    current_L.append(candidate)
                    self.frequent_service_combinations[candidate] = usage_rate
            
            k += 1
        
        return self
    
    def generate_service_patterns(self) -> List[Dict]:
        """
        Generate service usage patterns and their association rules.
        
        Returns:
            List of dictionaries containing patterns and their metrics
        """
        self.service_patterns = []
        
        for service_combo in self.frequent_service_combinations:
            if len(service_combo) < 2:
                continue
                
            for i in range(1, len(service_combo)):
                for precursor in combinations(service_combo, i):
                    precursor = frozenset(precursor)
                    subsequent = service_combo - precursor
                    
                    association_strength = (
                        self.frequent_service_combinations[service_combo] /
                        self.frequent_service_combinations[precursor]
                    )
                    
                    if association_strength >= self.min_association_strength:
                        correlation_score = (
                            association_strength /
                            self.frequent_service_combinations[subsequent]
                        )
                        
                        if correlation_score >= self.min_correlation_score:
                            self.service_patterns.append({
                                'precursor_services': list(precursor),
                                'subsequent_services': list(subsequent),
                                'usage_rate': self.frequent_service_combinations[service_combo],
                                'association_strength': association_strength,
                                'correlation_score': correlation_score
                            })
        
        return self.service_patterns
    
    def get_frequent_combinations(
        self,
        as_dataframe: bool = True
    ) -> Union[Dict, pd.DataFrame]:
        """
        Get the frequent service combinations and their usage rates.
        
        Args:
            as_dataframe: Whether to return results as a DataFrame
            
        Returns:
            Dictionary or DataFrame of frequent service combinations and their usage rates
        """
        if not as_dataframe:
            return self.frequent_service_combinations
        
        combinations_df = pd.DataFrame([
            {'service_combination': list(k), 'usage_rate': v}
            for k, v in self.frequent_service_combinations.items()
        ])
        return combinations_df.sort_values('usage_rate', ascending=False)
    
    def get_service_patterns(
        self,
        as_dataframe: bool = True
    ) -> Union[List[Dict], pd.DataFrame]:
        """
        Get the generated service usage patterns.
        
        Args:
            as_dataframe: Whether to return results as a DataFrame
            
        Returns:
            List of dictionaries or DataFrame containing the patterns
        """
        if not as_dataframe:
            return self.service_patterns
        
        return pd.DataFrame(self.service_patterns).sort_values('correlation_score', ascending=False) 