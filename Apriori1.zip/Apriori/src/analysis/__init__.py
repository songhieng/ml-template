"""
Analysis package for Apriori algorithm implementation
""" 