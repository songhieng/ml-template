import streamlit as st
import sys
import os

# Add the project directory to the Python path
project_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_dir)

# Set page configuration - MUST be the first Streamlit command
st.set_page_config(
    page_title="Document Search",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        'Get Help': None,
        'Report a bug': None,
        'About': None
    }
)

# Custom CSS to fix layout issues
st.markdown("""
<style>
    .block-container {
        padding-top: 1rem;
        padding-bottom: 0rem;
        padding-left: 2rem;
        padding-right: 2rem;
    }
    .stRadio > label {
        font-size: 1rem;
    }
    section[data-testid="stSidebar"] > div {
        padding-top: 1rem;
    }
    section[data-testid="stSidebar"] .block-container {
        padding-top: 0rem;
    }
    div[data-testid="stToolbar"] {
        display: none;
    }
    #MainMenu {
        display: none;
    }
    header {
        display: none;
    }
</style>
""", unsafe_allow_html=True)

def main():
    # Simple navigation using sidebar
    st.sidebar.title("Navigation")
    page = st.sidebar.radio("Select Page", ["Search", "Admin"], index=0)
    
    if page == "Admin":
        from src.admin_page import main as admin_main
        admin_main()
    else:
        from src.user_page import main as user_main
        user_main()

if __name__ == "__main__":
    main() 