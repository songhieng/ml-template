import hashlib
import os

# Function to generate salt and hash password
def hash_password(password, salt=None):
    if salt is None:
        salt = os.urandom(32)
    hash = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode('utf-8'),
        salt,
        100000  # Number of iterations
    )
    return salt + hash

# Function to verify password
def verify_password(stored_password, provided_password):
    salt = stored_password[:32]  # First 32 bytes is salt
    stored_hash = stored_password[32:]
    hash = hashlib.pbkdf2_hmac(
        'sha256',
        provided_password.encode('utf-8'),
        salt,
        100000  # Number of iterations
    )
    return hash == stored_hash

# Default admin credentials (you should change this in production)
DEFAULT_ADMIN_PASSWORD = "admin123"  # Change this!
ADMIN_PASSWORD_HASH = hash_password(DEFAULT_ADMIN_PASSWORD)

# Session configuration
SESSION_EXPIRY = 3600  # Session expires after 1 hour 