import streamlit as st
import os
import pandas as pd
from src.utils.vector_db import VectorDBManager
from src.utils.language_detector import detect_language

def display_result(result, metadata, index):
    """Display a single search result with improved UI"""
    with st.container():
        # Create a card-like container with a border
        st.markdown(f"""
        <style>
        .search-result {{
            border: 1px solid #2e303e;
            border-radius: 8px;
            padding: 1rem;
            margin: 0.5rem 0;
            background-color: #1b1c29;
        }}
        .result-title {{
            color: #ffffff;
            font-size: 1.2rem;
            margin-bottom: 0.5rem;
        }}
        .result-category {{
            color: #9ca3af;
            font-size: 0.9rem;
        }}
        .result-content {{
            margin-top: 1rem;
            color: #e5e7eb;
        }}
        </style>
        """, unsafe_allow_html=True)
        
        with st.expander(f"Result {index + 1} ({'English' if result['language'] == 'en' else 'Khmer'}, Relevance: {100 * (1 - result['distance']/2):.1f}%)", expanded=True):
            try:
                # Find the corresponding metadata
                doc = metadata[metadata['id'] == result['doc_id']].iloc[0]
                
                # Display metadata in columns
                col1, col2 = st.columns([3, 1])
                with col1:
                    st.markdown(f"<div class='result-title'>{doc['title']}</div>", unsafe_allow_html=True)
                    st.markdown(f"<div class='result-category'>{doc['category']}</div>", unsafe_allow_html=True)
                with col2:
                    st.markdown(f"<div style='text-align: right; color: #9ca3af;'>ID: {doc['id']}</div>", unsafe_allow_html=True)
                    st.markdown(f"<div style='text-align: right; color: #9ca3af;'>{doc['language'].upper()}</div>", unsafe_allow_html=True)
                
                # Display the document text
                st.markdown(f"<div class='result-content'>{doc['text']}</div>", unsafe_allow_html=True)
                
            except Exception as e:
                st.error("Error loading result metadata. Please try reloading the database.")

def main():
    # Custom CSS for better UI
    st.markdown("""
    <style>
    .main {
        padding: 0;
    }
    .search-container {
        max-width: 800px;
        margin: 0 auto;
    }
    .stTextInput > div > div > input {
        background-color: #1b1c29;
        color: white;
        border: 1px solid #2e303e;
        padding: 0.5rem 1rem;
        font-size: 1rem;
    }
    .stTextInput > div > div > input:focus {
        border-color: #4b5563;
        box-shadow: none;
    }
    .stExpander {
        border: none !important;
        box-shadow: none !important;
    }
    .streamlit-expanderHeader {
        background-color: #1b1c29 !important;
        border: 1px solid #2e303e !important;
    }
    .streamlit-expanderContent {
        background-color: #1b1c29 !important;
        border: 1px solid #2e303e !important;
        border-top: none !important;
    }
    </style>
    """, unsafe_allow_html=True)
    
    st.title("🤖 AI Chatbot")
    
    # Initialize session state
    if 'vector_db' not in st.session_state:
        st.session_state.vector_db = VectorDBManager()
    
    # List available databases
    try:
        databases = VectorDBManager.list_databases("data/processed/vector_db")
        if not databases.empty:
            # Database selection in sidebar
            st.sidebar.title("Database Selection")
            db_names = databases['name'].tolist()
            selected_db = st.sidebar.selectbox(
                "Choose a database to search",
                db_names,
                help="Select the database that best matches your search needs"
            )
            
            # Load database if not already loaded or if different database selected
            if (not st.session_state.vector_db.current_db_name or 
                st.session_state.vector_db.current_db_name != selected_db):
                with st.spinner(f"Loading database '{selected_db}'..."):
                    st.session_state.vector_db.load_index("data/processed/vector_db", selected_db)
                    metadata_path = os.path.join("data/processed/vector_db", selected_db, "metadata.csv")
                    if os.path.exists(metadata_path):
                        st.session_state.metadata = pd.read_csv(metadata_path)
                        st.success(f"Database '{selected_db}' loaded successfully!")
                    else:
                        st.error(f"Metadata file not found for database '{selected_db}'")
                        return
            
            # Search interface
            st.sidebar.title("Search Options")
            
            # Language selection
            language = st.sidebar.radio("Select language", ["Auto-detect", "English", "Khmer"])
            k = st.sidebar.slider("Number of results", min_value=1, max_value=20, value=1)
            
            # Main search area
            with st.container():
                st.markdown("<div class='search-container'>", unsafe_allow_html=True)
                st.markdown("### Enter your search query")
                query = st.text_input("", placeholder="Type your search query here...")
                st.markdown("</div>", unsafe_allow_html=True)
            
            if query:
                # Detect language if auto-detect is selected
                if language == "Auto-detect":
                    lang = detect_language(query)
                    if lang is None:
                        st.warning("Could not detect language. Please try again or select a specific language.")
                        return
                else:
                    lang = 'en' if language == "English" else 'km'
                
                with st.spinner("🔍 Searching..."):
                    results = st.session_state.vector_db.search(query, k=k)
                    
                    if not results:
                        st.warning("No results found")
                    else:
                        st.success(f"Found {len(results)} results")
                        
                        # Display results
                        for i, result in enumerate(results):
                            if hasattr(st.session_state, 'metadata'):
                                display_result(result, st.session_state.metadata, i)
                            else:
                                st.error("Metadata not found. Please try reloading the database.")
                                break
        else:
            st.warning("No vector databases found. Please contact the administrator to build one.")
            
    except Exception as e:
        st.error(f"Error: {str(e)}")
        st.info("Please try reloading the page or contact the administrator.")

# Make sure main is available when imported
__all__ = ['main'] 