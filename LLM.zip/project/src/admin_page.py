import streamlit as st
import pandas as pd
import os
from .utils.vector_db import VectorDBManager
from .utils.auth import check_auth, login_page
from .utils.language_detector import detect_language
import time

# Initialize session state for authentication if not exists
if 'auth' not in st.session_state:
    st.session_state.auth = {
        'authenticated': False,
        'last_activity': None,
        'login_attempts': 0,
        'lockout_until': None
    }

def build_database():
    st.header("Build Vector Database")
    
    # Database name input
    db_name = st.text_input("Enter database name", 
                           help="Give your database a descriptive name (e.g., 'banking_docs', 'insurance_docs')")
    
    # File upload
    uploaded_file = st.file_uploader("Upload CSV file", type=['csv'])
    
    if uploaded_file is not None and db_name:
        try:
            # Validate database name (only allow letters, numbers, underscores, and hyphens)
            if not all(c.isalnum() or c in '_-' for c in db_name):
                st.error("Database name can only contain letters, numbers, underscores, and hyphens")
                return
                
            # Read CSV
            df = pd.read_csv(uploaded_file)
            
            # Check if required columns exist
            required_columns = ['id', 'title', 'text', 'category', 'language']
            missing_columns = [col for col in required_columns if col not in df.columns]
            
            if missing_columns:
                st.error(f"Missing required columns: {', '.join(missing_columns)}")
                st.info("Required columns: id, title, text, category, language")
                return
            
            # Show data preview
            st.subheader("Data Preview")
            st.dataframe(df.head())
            
            # Show data statistics
            st.subheader("Data Statistics")
            col1, col2 = st.columns(2)
            with col1:
                st.write("Total Documents:", len(df))
                st.write("Categories:", df['category'].nunique())
            with col2:
                st.write("Languages:", df['language'].unique().tolist())
            
            if st.button("Build Vector Database"):
                with st.spinner("Building vector database..."):
                    # Create directories if they don't exist
                    os.makedirs("data/processed/vector_db", exist_ok=True)
                    
                    # Initialize VectorDB Manager
                    vector_db = VectorDBManager()
                    
                    # Save metadata
                    db_path = os.path.join("data/processed/vector_db", db_name)
                    os.makedirs(db_path, exist_ok=True)
                    df.to_csv(os.path.join(db_path, "metadata.csv"), index=False)
                    
                    # Add documents to vector database
                    vector_db.add_documents(df)
                    
                    # Save the indices
                    vector_db.save_index("data/processed/vector_db", db_name)
                    
                    # Show statistics
                    st.success(f"Vector database '{db_name}' built successfully!")
                    st.info(f"English documents: {len(vector_db.documents['en'])}")
                    st.info(f"Khmer documents: {len(vector_db.documents['km'])}")
                    st.info("Metadata saved successfully!")
                    
        except Exception as e:
            st.error(f"Error processing CSV file: {str(e)}")
    elif not db_name and uploaded_file:
        st.warning("Please enter a database name")

def manage_database():
    st.header("Manage Vector Database")
    
    # List available databases
    try:
        databases = VectorDBManager.list_databases("data/processed/vector_db")
        if not databases.empty:
            st.success("Available Vector Databases:")
            st.dataframe(databases)
            
            # Database selection
            db_names = databases['name'].tolist()
            selected_db = st.selectbox("Select Database", db_names)
            
            # Create columns for buttons
            col1, col2 = st.columns(2)
            
            with col1:
                if st.button("Load Selected Database"):
                    with st.spinner(f"Loading database '{selected_db}'..."):
                        vector_db = VectorDBManager()
                        vector_db.load_index("data/processed/vector_db", selected_db)
                        metadata_path = os.path.join("data/processed/vector_db", selected_db, "metadata.csv")
                        if os.path.exists(metadata_path):
                            st.session_state.metadata = pd.read_csv(metadata_path)
                            st.session_state.vector_db = vector_db
                        st.success(f"Database '{selected_db}' loaded successfully!")
            
            with col2:
                if st.button("🗑️ Delete Database", type="secondary"):
                    st.session_state.delete_confirm = True
                    st.session_state.db_to_delete = selected_db
            
            # Delete confirmation dialog
            if st.session_state.get('delete_confirm', False) and st.session_state.get('db_to_delete') == selected_db:
                st.warning(f"Are you sure you want to delete the database '{selected_db}'? This action cannot be undone.")
                col1, col2 = st.columns(2)
                with col1:
                    if st.button("Yes, Delete Database", type="primary"):
                        try:
                            # Delete the database directory
                            db_path = os.path.join("data/processed/vector_db", selected_db)
                            if os.path.exists(db_path):
                                import shutil
                                shutil.rmtree(db_path)
                                st.success(f"Database '{selected_db}' deleted successfully!")
                                # Reset delete confirmation state
                                st.session_state.delete_confirm = False
                                st.session_state.db_to_delete = None
                                st.rerun()  # Refresh the page to update the database list
                            else:
                                st.error(f"Database '{selected_db}' not found!")
                        except Exception as e:
                            st.error(f"Error deleting database: {str(e)}")
                with col2:
                    if st.button("Cancel", type="secondary"):
                        st.session_state.delete_confirm = False
                        st.session_state.db_to_delete = None
                        st.rerun()
            
            # Show database analysis if loaded
            if hasattr(st.session_state, 'metadata') and hasattr(st.session_state, 'vector_db'):
                metadata = st.session_state.metadata
                vector_db = st.session_state.vector_db
                
                st.subheader(f"Database Analysis: {selected_db}")
                
                # Create tabs for different analysis sections
                tab1, tab2, tab3, tab4 = st.tabs(["📊 Statistics", "📝 Document Preview", "🔍 Search Analysis", "📈 Performance"])
                
                with tab1:
                    # Database Statistics
                    st.markdown("### 📊 Database Statistics")
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Total Documents", len(metadata))
                        st.metric("Categories", metadata['category'].nunique())
                    with col2:
                        st.metric("English Documents", len(metadata[metadata['language'] == 'en']))
                        st.metric("Khmer Documents", len(metadata[metadata['language'] == 'km']))
                    with col3:
                        avg_text_length = metadata['text'].str.len().mean()
                        st.metric("Avg. Text Length", f"{avg_text_length:.0f} chars")
                    
                    # Language Distribution
                    st.markdown("### 🌐 Language Distribution")
                    lang_counts = metadata['language'].value_counts()
                    st.bar_chart(lang_counts)
                    
                    # Category Distribution
                    st.markdown("### 📑 Category Distribution")
                    category_counts = metadata['category'].value_counts()
                    st.bar_chart(category_counts)
                
                with tab2:
                    # Document Preview
                    st.markdown("### 📝 Document Preview")
                    preview_option = st.radio("Preview by", ["Random Sample", "By Category", "By Language"])
                    
                    if preview_option == "Random Sample":
                        sample_size = st.slider("Number of documents to preview", 1, 10, 3)
                        sample = metadata.sample(sample_size)
                    elif preview_option == "By Category":
                        category = st.selectbox("Select Category", metadata['category'].unique())
                        sample = metadata[metadata['category'] == category].sample(min(3, len(metadata[metadata['category'] == category])))
                    else:
                        language = st.selectbox("Select Language", metadata['language'].unique())
                        sample = metadata[metadata['language'] == language].sample(min(3, len(metadata[metadata['language'] == language])))
                    
                    for _, doc in sample.iterrows():
                        with st.expander(f"{doc['title']} ({doc['language']})"):
                            st.write(f"**Category:** {doc['category']}")
                            st.write(f"**Text:**")
                            st.write(doc['text'])
                
                with tab3:
                    # Search Analysis
                    st.markdown("### 🔍 Search Analysis")
                    query = st.text_input("Enter search query for analysis")
                    if query:
                        lang = detect_language(query)
                        st.write(f"Detected language: {'English' if lang == 'en' else 'Khmer' if lang == 'km' else 'Unknown'}")
                        
                        results = vector_db.search(query)
                        if results:
                            st.write(f"Found {len(results)} results")
                            
                            # Show top results with more details
                            for i, result in enumerate(results[:3]):
                                doc = metadata[metadata['id'] == result['doc_id']].iloc[0]
                                with st.expander(f"Result {i+1} ({'English' if result['language'] == 'en' else 'Khmer'}) - Score: {result['distance']:.4f}"):
                                    st.write(f"**Title:** {doc['title']}")
                                    st.write(f"**Category:** {doc['category']}")
                                    st.write(f"**Text:**")
                                    st.write(doc['text'])
                
                with tab4:
                    # Performance Testing
                    st.markdown("### 📈 Search Performance")
                    test_queries = [
                        "What is a savings account?",
                        "ប្រាក់កម្ចីកសិកម្ម",
                        "How to open a bank account?",
                        "របៀបបើកគណនីធនាគារ"
                    ]
                    
                    selected_query = st.selectbox("Select test query", test_queries)
                    if st.button("Run Performance Test"):
                        with st.spinner("Testing search performance..."):
                            start_time = time.time()
                            results = vector_db.search(selected_query)
                            end_time = time.time()
                            
                            st.metric("Search Time", f"{(end_time - start_time)*1000:.2f} ms")
                            st.metric("Results Found", len(results))
                            
                            if results:
                                st.write("Top Result:")
                                doc = metadata[metadata['id'] == results[0]['doc_id']].iloc[0]
                                st.write(f"**Title:** {doc['title']}")
                                st.write(f"**Score:** {results[0]['distance']:.4f}")
        else:
            st.warning("No vector databases found. Please build one first.")
    except Exception as e:
        st.error(f"Error loading databases: {str(e)}")

def show_admin_panel():
    st.title("Vector Database Admin Panel")
    
    # Sidebar for navigation
    st.sidebar.title("Navigation")
    page = st.sidebar.radio("Go to", ["Build Database", "Manage Database"])
    
    if page == "Build Database":
        build_database()
    else:
        manage_database()

    # Add logout button in sidebar
    with st.sidebar:
        st.markdown("---")
        st.markdown("### Admin Controls")
        if st.button("🚪 Logout"):
            st.session_state.auth = {
                'authenticated': False,
                'last_activity': None,
                'login_attempts': 0,
                'lockout_until': None
            }
            st.rerun()

def main():
    # Check authentication first
    if not check_auth():
        login_page()
        return

    # Show admin panel only if authenticated
    show_admin_panel()

if __name__ == "__main__":
    main() 