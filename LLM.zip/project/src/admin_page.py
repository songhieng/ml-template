import streamlit as st
import pandas as pd
import os
from src.utils.vector_db import VectorDBManager
from src.utils.language_detector import detect_language

def build_database():
    st.header("Build Vector Database")
    
    # Database name input
    db_name = st.text_input("Enter database name", 
                           help="Give your database a descriptive name (e.g., 'banking_docs', 'insurance_docs')")
    
    # File upload
    uploaded_file = st.file_uploader("Upload CSV file", type=['csv'])
    
    if uploaded_file is not None and db_name:
        try:
            # Validate database name (only allow letters, numbers, underscores, and hyphens)
            if not all(c.isalnum() or c in '_-' for c in db_name):
                st.error("Database name can only contain letters, numbers, underscores, and hyphens")
                return
                
            # Read CSV
            df = pd.read_csv(uploaded_file)
            
            # Check if required columns exist
            required_columns = ['id', 'title', 'text', 'category', 'language']
            missing_columns = [col for col in required_columns if col not in df.columns]
            
            if missing_columns:
                st.error(f"Missing required columns: {', '.join(missing_columns)}")
                st.info("Required columns: id, title, text, category, language")
                return
            
            # Show data preview
            st.subheader("Data Preview")
            st.dataframe(df.head())
            
            # Show data statistics
            st.subheader("Data Statistics")
            col1, col2 = st.columns(2)
            with col1:
                st.write("Total Documents:", len(df))
                st.write("Categories:", df['category'].nunique())
            with col2:
                st.write("Languages:", df['language'].unique().tolist())
            
            if st.button("Build Vector Database"):
                with st.spinner("Building vector database..."):
                    # Create directories if they don't exist
                    os.makedirs("data/processed/vector_db", exist_ok=True)
                    
                    # Initialize state for new database
                    st.session_state.vector_db.reset_state()
                    
                    # Save metadata
                    db_path = os.path.join("data/processed/vector_db", db_name)
                    os.makedirs(db_path, exist_ok=True)
                    df.to_csv(os.path.join(db_path, "metadata.csv"), index=False)
                    
                    # Add documents to vector database
                    st.session_state.vector_db.add_documents(df)
                    
                    # Save the indices
                    st.session_state.vector_db.save_index("data/processed/vector_db", db_name)
                    
                    # Show statistics
                    st.success(f"Vector database '{db_name}' built successfully!")
                    st.info(f"English documents: {len(st.session_state.vector_db.documents['en'])}")
                    st.info(f"Khmer documents: {len(st.session_state.vector_db.documents['km'])}")
                    st.info("Metadata saved successfully!")
                    
        except Exception as e:
            st.error(f"Error processing CSV file: {str(e)}")
    elif not db_name and uploaded_file:
        st.warning("Please enter a database name")

def manage_database():
    st.header("Manage Vector Database")
    
    # List available databases
    try:
        databases = VectorDBManager.list_databases("data/processed/vector_db")
        if not databases.empty:
            st.success("Available Vector Databases:")
            st.dataframe(databases)
            
            # Database selection
            db_names = databases['name'].tolist()
            selected_db = st.selectbox("Select Database", db_names)
            
            if st.button("Load Selected Database"):
                with st.spinner(f"Loading database '{selected_db}'..."):
                    st.session_state.vector_db.load_index("data/processed/vector_db", selected_db)
                    metadata_path = os.path.join("data/processed/vector_db", selected_db, "metadata.csv")
                    if os.path.exists(metadata_path):
                        st.session_state.metadata = pd.read_csv(metadata_path)
                    st.success(f"Database '{selected_db}' loaded successfully!")
            
            # Show statistics for currently loaded database
            if st.session_state.vector_db.current_db_name:
                st.subheader(f"Current Database: {st.session_state.vector_db.current_db_name}")
                col1, col2 = st.columns(2)
                with col1:
                    st.write("English Documents:", len(st.session_state.vector_db.documents['en']))
                with col2:
                    st.write("Khmer Documents:", len(st.session_state.vector_db.documents['km']))
                    
                # Test search
                st.subheader("Test Search")
                query = st.text_input("Enter search query")
                if query:
                    lang = detect_language(query)
                    st.write(f"Detected language: {'English' if lang == 'en' else 'Khmer' if lang == 'km' else 'Unknown'}")
                    
                    results = st.session_state.vector_db.search(query)
                    if hasattr(st.session_state, 'metadata'):
                        metadata = st.session_state.metadata
                        for i, result in enumerate(results):
                            doc = metadata[metadata['id'] == result['doc_id']].iloc[0]
                            st.write(f"Result {i+1} ({'English' if result['language'] == 'en' else 'Khmer'}):")
                            st.write(f"**ID:** {doc['id']}")
                            st.write(f"**Title:** {doc['title']}")
                            st.write(f"**Category:** {doc['category']}")
                            st.write(f"**Distance:** {result['distance']:.4f}")
                            st.write(f"**Text:**")
                            st.write(doc['text'])
                            st.write("---")
        else:
            st.warning("No vector databases found. Please build one first.")
    except Exception as e:
        st.error(f"Error loading databases: {str(e)}")

def main():
    st.title("Vector Database Admin Panel")
    
    # Initialize session state
    if 'vector_db' not in st.session_state:
        st.session_state.vector_db = VectorDBManager()
    
    # Sidebar for navigation
    st.sidebar.title("Navigation")
    page = st.sidebar.radio("Go to", ["Build Database", "Manage Database"])
    
    if page == "Build Database":
        build_database()
    else:
        manage_database()

# Make sure main is available when imported
__all__ = ['main'] 