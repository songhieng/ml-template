import streamlit as st
from ..utils.vector_db import VectorDBManager
from ..utils.auth import check_auth, login_page

# Set page config
st.set_page_config(
    page_title="Admin Panel",
    page_icon="🔒",
    layout="wide"
)

# Initialize session state for authentication if not exists
if 'auth' not in st.session_state:
    st.session_state.auth = {
        'authenticated': False,
        'last_activity': None
    }

def show_admin_panel():
    st.title("Admin Panel")
    st.markdown("### Database Management")

    # Initialize VectorDB Manager
    vector_db = VectorDBManager()

    # File upload section
    st.subheader("Upload Documents")
    uploaded_file = st.file_uploader("Choose a CSV file", type="csv")

    if uploaded_file is not None:
        if st.button("Process and Add Documents"):
            with st.spinner("Processing documents..."):
                try:
                    vector_db.add_documents_from_csv(uploaded_file)
                    st.success("Documents processed and added successfully!")
                except Exception as e:
                    st.error(f"Error processing documents: {str(e)}")

    # Database rebuild section
    st.subheader("Rebuild Database")
    if st.button("Rebuild Vector Database"):
        with st.spinner("Rebuilding database..."):
            try:
                vector_db.build_database()
                st.success("Database rebuilt successfully!")
            except Exception as e:
                st.error(f"Error rebuilding database: {str(e)}")

    # Add logout button in sidebar
    with st.sidebar:
        st.markdown("### Admin Controls")
        if st.button("🚪 Logout"):
            st.session_state.auth = {
                'authenticated': False,
                'last_activity': None
            }
            st.rerun()

def main():
    # Check authentication first
    if not check_auth():
        login_page()
        return

    # Show admin panel only if authenticated
    show_admin_panel()

if __name__ == "__main__":
    main() 