import streamlit as st
import time
from ..config.auth_config import verify_password, ADMIN_PASSWORD_HASH, SESSION_EXPIRY

def init_auth_state():
    """Initialize authentication state if not exists"""
    if 'auth' not in st.session_state:
        st.session_state.auth = {
            'authenticated': False,
            'last_activity': None,
            'login_attempts': 0,
            'lockout_until': None
        }

def check_auth():
    """Check if user is authenticated"""
    init_auth_state()
    
    # Check if user is locked out
    if st.session_state.auth.get('lockout_until'):
        if time.time() < st.session_state.auth['lockout_until']:
            return False
        # Reset lockout if time has passed
        st.session_state.auth['lockout_until'] = None
        st.session_state.auth['login_attempts'] = 0
    
    # Check session expiry
    if st.session_state.auth['authenticated']:
        if (st.session_state.auth['last_activity'] and 
            time.time() - st.session_state.auth['last_activity'] > SESSION_EXPIRY):
            st.session_state.auth['authenticated'] = False
            st.session_state.auth['last_activity'] = None
            return False
        st.session_state.auth['last_activity'] = time.time()
        return True
    return False

def login_page():
    """Display login page and handle authentication"""
    init_auth_state()
    
    st.title("Admin Login")
    
    # Check if user is locked out
    if st.session_state.auth.get('lockout_until'):
        if time.time() < st.session_state.auth['lockout_until']:
            remaining_time = int(st.session_state.auth['lockout_until'] - time.time())
            st.error(f"Too many failed attempts. Please try again in {remaining_time} seconds.")
            return
    
    # Custom CSS for login form
    st.markdown("""
    <style>
    .stTextInput > div > div > input {
        background-color: #1b1c29;
        color: white;
        border: 1px solid #2e303e;
        padding: 0.5rem 1rem;
        font-size: 1rem;
    }
    .stTextInput > div > div > input:focus {
        border-color: #4b5563;
        box-shadow: none;
    }
    div[data-testid="stToolbar"] {
        display: none;
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Center the login form
    col1, col2, col3 = st.columns([1,2,1])
    with col2:
        st.markdown("### 🔐 Admin Access Required")
        password = st.text_input("Enter admin password", type="password")
        
        if st.button("Login"):
            if verify_password(ADMIN_PASSWORD_HASH, password):
                st.session_state.auth = {
                    'authenticated': True,
                    'last_activity': time.time(),
                    'login_attempts': 0,
                    'lockout_until': None
                }
                st.rerun()
            else:
                st.session_state.auth['login_attempts'] += 1
                if st.session_state.auth['login_attempts'] >= 3:
                    st.session_state.auth['lockout_until'] = time.time() + 300  # 5 minutes lockout
                    st.error("Too many failed attempts. Please try again in 5 minutes.")
                else:
                    st.error(f"Invalid password. {3 - st.session_state.auth['login_attempts']} attempts remaining.")
        
        st.markdown("---")
        st.markdown("Return to [Search Page](/)") 