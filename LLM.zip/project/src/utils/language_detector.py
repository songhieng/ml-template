from langdetect import detect
from langdetect.lang_detect_exception import LangDetectException
import re

def contains_khmer_chars(text):
    """Check if text contains Khmer Unicode characters"""
    # Khmer Unicode range: \u1780-\u17FF
    khmer_pattern = re.compile(r'[\u1780-\u17FF]')
    return bool(khmer_pattern.search(text))

def detect_language(text):
    """
    Detect the language of the given text.
    Returns 'en' for English, 'km' for Khmer, or None if detection fails.
    Uses both Unicode range checking and language detection.
    """
    if not text or not isinstance(text, str):
        return None
        
    # First check for Khmer characters
    if contains_khmer_chars(text):
        return 'km'
        
    try:
        # For non-Khmer text, use langdetect
        lang = detect(text.strip())
        if lang == 'en':
            return 'en'
        # If it's not English and we didn't detect Khmer earlier,
        # check if it might be Khmer that wasn't detected properly
        if any(ord(char) > 127 for char in text):
            return 'km'
        return 'en'
    except LangDetectException:
        # If detection fails but text contains non-ASCII chars, assume Khmer
        if any(ord(char) > 127 for char in text):
            return 'km'
        return None 