import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
import pandas as pd
import os
import glob
from .language_detector import detect_language

class VectorDBManager:
    def __init__(self):
        # Get the absolute path to the models directory
        current_dir = os.path.dirname(os.path.abspath(__file__))
        models_dir = os.path.abspath(os.path.join(current_dir, '..', 'models'))
        
        # Define the snapshot paths for each model
        english_snapshot = os.path.join(
            models_dir, 
            'english', 
            'models--sentence-transformers--all-mpnet-base-v2',
            'snapshots',
            '12e86a3c702fc3c50205a8db88f0ec7c0b6b94a0'
        )
        
        khmer_snapshot = os.path.join(
            models_dir, 
            'khmer', 
            'models--sentence-transformers--paraphrase-multilingual-MiniLM-L12-v2',
            'snapshots',
            '86741b4e3f5cb7765a600d3a3d55a0f6a6cb443d'
        )
        
        # Initialize models for different languages using snapshot paths
        self.models = {
            'en': SentenceTransformer(english_snapshot),
            'km': SentenceTransformer(khmer_snapshot)
        }
        self.dimensions = {
            'en': self.models['en'].get_sentence_embedding_dimension(),
            'km': self.models['km'].get_sentence_embedding_dimension()
        }
        
        # Initialize state
        self.indices = {
            'en': None,
            'km': None
        }
        self.documents = {
            'en': [],
            'km': []
        }
        self.doc_ids = {
            'en': [],
            'km': []
        }
        self.current_db_name = None
        
    def reset_state(self):
        """Reset the internal state of the vector database"""
        self.indices = {
            'en': None,
            'km': None
        }
        self.documents = {
            'en': [],
            'km': []
        }
        self.doc_ids = {
            'en': [],
            'km': []
        }
        self.current_db_name = None
        
    def create_index(self, language):
        """Create a new FAISS index for a specific language"""
        self.indices[language] = faiss.IndexFlatL2(self.dimensions[language])
        
    def add_documents(self, documents_df):
        """Add documents to the vector database with language detection"""
        for _, row in documents_df.iterrows():
            text = str(row['text']).strip()
            doc_id = row['id']
            
            # Skip if document is empty
            if not text:
                continue
                
            # Use the language from metadata if available, otherwise detect
            lang = row.get('language', detect_language(text))
            if lang not in ['en', 'km']:
                continue
                
            if not self.indices[lang]:
                self.create_index(lang)
                
            try:
                # Convert document to embedding
                embedding = self.models[lang].encode([text])[0]
                
                # Add to FAISS index
                self.indices[lang].add(np.array([embedding]))
                self.documents[lang].append(text)
                self.doc_ids[lang].append(doc_id)
            except Exception as e:
                print(f"Error processing document {doc_id}: {str(e)}")
                continue
        
    def search(self, query, k=5):
        """Search for similar documents with language detection"""
        # Clean the query
        query = query.strip()
        if not query:
            return []
            
        # Detect query language
        lang = detect_language(query)
        if lang not in ['en', 'km']:
            return []
            
        if not self.indices[lang]:
            raise ValueError(f"Index not created for language {lang}. Please add documents first.")
            
        try:
            # Convert query to embedding
            query_embedding = self.models[lang].encode([query])[0]
            
            # Search in FAISS
            distances, indices = self.indices[lang].search(np.array([query_embedding]), k)
            
            # Return results
            results = []
            for i, idx in enumerate(indices[0]):
                if idx != -1:  # FAISS returns -1 for empty slots
                    results.append({
                        'document': self.documents[lang][idx],
                        'doc_id': self.doc_ids[lang][idx],
                        'distance': float(distances[0][i]),
                        'language': lang
                    })
            return results
        except Exception as e:
            print(f"Error searching: {str(e)}")
            return []
    
    def save_index(self, path, db_name):
        """Save the FAISS indices and documents for all languages"""
        # Create database directory
        db_path = os.path.join(path, db_name)
        os.makedirs(db_path, exist_ok=True)
        
        # Save database info with timestamp
        pd.DataFrame({
            'name': [db_name],
            'created_at': [pd.Timestamp.now()],
            'en_docs': [len(self.documents['en'])],
            'km_docs': [len(self.documents['km'])]
        }).to_csv(os.path.join(db_path, 'info.csv'), index=False)
        
        for lang in ['en', 'km']:
            if self.indices[lang] is not None and len(self.documents[lang]) > 0:
                # Save FAISS index
                faiss.write_index(self.indices[lang], os.path.join(db_path, f"index_{lang}.faiss"))
                
                # Save documents and their IDs
                pd.DataFrame({
                    'documents': self.documents[lang],
                    'doc_ids': self.doc_ids[lang]
                }).to_csv(os.path.join(db_path, f"documents_{lang}.csv"), index=False)
        
        self.current_db_name = db_name
        
    def load_index(self, path, db_name):
        """Load the FAISS indices and documents for all languages"""
        # Reset current state
        self.reset_state()
        
        db_path = os.path.join(path, db_name)
        if not os.path.exists(db_path):
            raise ValueError(f"Database '{db_name}' not found")
            
        # Verify metadata exists
        metadata_path = os.path.join(db_path, "metadata.csv")
        if not os.path.exists(metadata_path):
            raise ValueError(f"Metadata file not found for database '{db_name}'")
            
        for lang in ['en', 'km']:
            index_path = os.path.join(db_path, f"index_{lang}.faiss")
            docs_path = os.path.join(db_path, f"documents_{lang}.csv")
            
            if os.path.exists(index_path) and os.path.exists(docs_path):
                # Load FAISS index
                self.indices[lang] = faiss.read_index(index_path)
                
                # Load documents and their IDs
                df = pd.read_csv(docs_path)
                self.documents[lang] = df['documents'].tolist()
                self.doc_ids[lang] = df['doc_ids'].tolist()
        
        self.current_db_name = db_name
        
    @staticmethod
    def list_databases(path):
        """List all available vector databases"""
        databases = []
        for db_path in glob.glob(os.path.join(path, "*")):
            if os.path.isdir(db_path) and os.path.exists(os.path.join(db_path, 'info.csv')):
                info_df = pd.read_csv(os.path.join(db_path, 'info.csv'))
                databases.append({
                    'name': info_df['name'].iloc[0],
                    'created_at': info_df['created_at'].iloc[0]
                })
        return pd.DataFrame(databases)